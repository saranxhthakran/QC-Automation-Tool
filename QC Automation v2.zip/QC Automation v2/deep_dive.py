"""Product deep dive: builds everything the page (and the PDF) shows for one product and filter selection.

The engine runs on all of the product's rows in the history window (so calibration and persistence use
every account); filters only choose which accounts are summarised. Pure functions, no Streamlit.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

import numpy as np
import pandas as pd

import config
import field_actions as FA
import fiscal_calendar as fc
import forecast as F
import metrics as M
import product_engine as pe

Q = config.QTY_COLUMN
STEPS = ["Building cycle events", "Classifying accounts", "Finding treatment courses", "Calculating persistence",
         "Predicting next orders", "Running the 13-week forecast", "Ranking field actions"]
MIN_COURSES_FOR_SELECTION_CURVE = 15


@dataclass
class DeepDive:
    product: str
    as_of: pd.Timestamp
    load_date: date | None
    history_start: pd.Timestamp
    res: pe.EngineResult
    settings: dict
    keys: set
    rows: int
    history_months: float
    product_history_months: float
    snapshot: dict = field(default_factory=dict)
    demand: dict = field(default_factory=dict)
    rhythm: dict = field(default_factory=dict)
    accounts: dict = field(default_factory=dict)
    forecast: dict = field(default_factory=dict)
    actions: dict = field(default_factory=dict)
    takeaways: dict = field(default_factory=dict)
    notices: list = field(default_factory=list)


def run_product_engine(df_product: pd.DataFrame, product: str, as_of, overrides: dict, history_start,
                       steps=None) -> pe.EngineResult:
    d = df_product[df_product["Invoice_Date"] >= pd.Timestamp(history_start)]
    return pe.run_engine(d, product, as_of, overrides, history_start, steps)


def make_backtest_engine(df_all: pd.DataFrame, product: str, overrides: dict | None, history_start=None,
                         cache: dict | None = None, lookback_days: int = 730):
    """cutoff -> (EngineResult, next_orders) using only orders up to the cutoff (for the bottom-up backtest)."""
    pdf = df_all[df_all["Product"] == product]
    hs = pd.Timestamp(history_start) if history_start is not None else pdf["Invoice_Date"].min()
    ph = pdf[pdf["Invoice_Date"] >= hs]

    def run(cut):
        cut = pd.Timestamp(cut)
        if cache is not None and cut in cache:
            return cache[cut]
        lo = max(hs, cut - pd.Timedelta(days=lookback_days))
        d = ph[(ph["Invoice_Date"] <= cut) & (ph["Invoice_Date"] >= lo)]
        r = pe.run_engine(d, product, cut, overrides, lo)
        out = (r, F.next_orders(r, d))
        if cache is not None:
            cache[cut] = out
        return out

    return run


def build(df_all: pd.DataFrame, product: str, overrides: dict | None, history_start=None, regions=(), territories=(),
          parents=(), accounts=(), people=None, steps=None, engine=None, backtest_engine=None) -> DeepDive:
    """df_all: enriched sales (all products). engine: a precomputed EngineResult for this product/settings/history.
    backtest_engine(cutoff) -> (EngineResult, next_orders) for the bottom-up backtest."""
    step = steps or (lambda name: None)
    overrides = overrides or {}
    pdf = df_all[df_all["Product"] == product]
    as_of = pd.Timestamp(pdf["Invoice_Date"].max())
    first = pdf["Invoice_Date"].min()
    hs = max(pd.Timestamp(history_start), first) if history_start is not None else first
    ph = pdf[pdf["Invoice_Date"] >= hs]
    res = engine or run_product_engine(pdf, product, as_of, overrides, hs, step)
    if engine is not None:
        for name in STEPS[:4]:
            step(name)
    s = res.settings
    sel = M.filter_data(ph, None, list(regions), list(territories), list(parents), list(accounts))
    keys = set(sel["account_key"].unique())
    load = M.product_load_date(df_all, product)
    dd = DeepDive(product, as_of, load, hs, res, s, keys, len(sel), (as_of - hs).days / 30.44,
                  (as_of - first).days / 30.44)

    step("Predicting next orders")
    nxt_all = F.next_orders(res, ph)
    nxt = nxt_all[nxt_all["account_key"].isin(keys)]
    step("Running the 13-week forecast")
    fcst = F.forecast_13w(sel, res, nxt_all, keys, backtest_engine)
    landing = F.quarter_landing(sel, fcst, as_of)
    step("Ranking field actions")
    actions, trade = FA.build_actions(res, nxt_all, ph, people, keys)

    ev = res.events[res.events["account_key"].isin(keys)]
    reg = res.regimes[res.regimes["account_key"].isin(keys)]
    courses = res.courses[res.courses["account_key"].isin(keys)]
    _notices(dd, product)
    dd.snapshot = _snapshot(sel, ev, courses, res, as_of, landing)
    dd.demand = _demand(sel, ev, res, as_of)
    dd.rhythm = _rhythm(sel, ev, reg, courses, res, as_of)
    dd.accounts = _accounts(sel, ev, reg, res, as_of, people)
    dd.forecast = _forecast(sel, nxt, fcst, landing, res, as_of, people)
    rr_share = dd.rhythm.get("runrate_unit_share")
    dd.actions = {"actions": actions, "trade": trade, "region_summary": FA.region_summary(actions),
                  "narrative": FA.narrative(product, dd.snapshot, res, actions, landing, rr_share),
                  "new_owners": _new_owners(people, actions)}
    dd.takeaways = _takeaways(dd)
    return dd


# =============================================================================
# Sections
# =============================================================================
def _notices(dd: DeepDive, product: str) -> None:
    need = float(dd.settings["min_history_months"])
    if dd.history_months < need:
        dd.notices.append(f"Course, cohort and persistence views need at least {need:.0f} months of history; this "
                          f"window has {dd.history_months:.0f}. Choose “Full history” on Connect & load for steadier "
                          "numbers.")
    if product == "RYZNEUTA" and dd.product_history_months < 24:
        dd.notices.append(f"RYZNEUTA's own history is short ({dd.product_history_months:.0f} months of orders), so "
                          "persistence and cohort views are early reads, not settled patterns.")


def _snapshot(sel, ev, courses, res, as_of, landing) -> dict:
    s = res.settings
    kpis = M.period_kpis(sel, as_of.date())
    q = kpis[2] if len(kpis) == 3 else None
    upc = float(s["units_per_cycle"])
    pts = pe.active_patients(sel, as_of, s)
    a90 = sel[(sel["Invoice_Date"] > as_of - pd.Timedelta(days=90)) & (~sel["is_return"])]
    qs = pd.Timestamp(fc.quarter_start(as_of))
    ps = pd.Timestamp(fc.shift_quarter(qs, -1))
    pe_ = ps + (as_of - qs)
    known = courses[~courses["left_censored"]]
    return {
        "qtd_kpi": q,
        "cycles_qtd": (q.current / upc) if q else 0.0,
        "cycles_qtd_avg": (q.average / upc) if q else 0.0,
        "patients": pts,
        "active_children": int(a90["account_key"].nunique()),
        "total_children": int(sel["account_key"].nunique()),
        "active_parents": int(a90["parent_name"].nunique()),
        "total_parents": int(sel["parent_name"].nunique()),
        "starts_qtd": int((known["start"] >= qs).sum()),
        "starts_prev": int(((known["start"] >= ps) & (known["start"] <= pe_)).sum()),
        "landing": landing,
        "quarter": fc.quarter_label(as_of),
    }


def _demand(sel, ev, res, as_of) -> dict:
    s = res.settings
    out = {
        "weekly": pe.weekly_units_cycles(sel, as_of, s, 52),
        "hist": pe.order_size_hist(ev, s),
        "style_mix": pe.monthly_mix(ev, "buying_style", 12, as_of),
        "no_charge": pe.no_charge_summary(sel),
    }
    if not s.get("fixed_units_per_cycle"):
        dm = ev[ev["dose_level"].isin(list(pe.DOSE_LABELS))]
        out["dose_mix"] = pe.monthly_mix(dm.assign(dose_level=dm["dose_level"].map(pe.DOSE_LABELS)), "dose_level", 12, as_of)
    return out


def _rhythm(sel, ev, reg, courses, res, as_of) -> dict:
    s = res.settings
    iv = pe.interval_table(ev, reg, s)
    terr = sel.sort_values("Invoice_Date").groupby("account_key")["Territory_Name"].last()
    iv["Territory_Name"] = iv["account_key"].map(terr)
    by_terr = (iv.groupby("Territory_Name").agg(gaps=("gap", "size"), on_schedule=("on_schedule", "mean"))
               .reset_index().sort_values("on_schedule")) if len(iv) else pd.DataFrame()
    known = courses[~courses["left_censored"]]
    pers_sel = pe.persistence(courses) if len(known) >= MIN_COURSES_FOR_SELECTION_CURVE else None
    ended = courses[courses["status"] == pe.ENDED]
    yr = sel[sel["Invoice_Date"] > as_of - pd.Timedelta(days=365)]
    u = yr.groupby("account_key")[Q].sum()
    rr = set(reg.loc[reg["regime"] == pe.RUNRATE, "account_key"])
    tot = u.clip(lower=0).sum()
    return {
        "intervals": iv, "by_territory": by_terr, "bands": pe.schedule_bands(s),
        "pct_on_schedule": float(iv["on_schedule"].mean() * 100) if len(iv) else None,
        "starts": pe.starts_by_month(courses, as_of, s, 18),
        "persistence": pers_sel or res.persistence, "persistence_is_product": pers_sel is None,
        "persistence_product": res.persistence,
        "persistence_is_all": pers_sel is None or pers_sel.n_courses == res.persistence.n_courses,
        "course_lengths": ended.groupby("cycles").size() if len(ended) else pd.Series(dtype=int),
        "dose_paths": (courses.loc[courses["dose_path"].str.contains("→"), "dose_path"].value_counts()
                       if len(courses) and not s.get("fixed_units_per_cycle") else pd.Series(dtype=int)),
        "n_runrate": len(rr), "n_cadence": int((reg["regime"] == pe.CADENCE).sum()),
        "runrate_unit_share": float(u[u.index.isin(rr)].clip(lower=0).sum() / tot) if tot else None,
        "regimes": reg, "calibration": res.calibration, "new_start": res.new_start,
        "courses": courses,
    }


def _accounts(sel, ev, reg, res, as_of, people) -> dict:
    s = res.settings
    md = as_of.date()
    window = (fc.quarter_start(md), md)
    am = M.account_metrics(sel, md, window) if len(sel) else pd.DataFrame()
    out: dict = {"children": pd.DataFrame(), "parents": pd.DataFrame()}
    if am.empty:
        return out
    pts = pe.account_active_patients(sel, as_of, s)
    yr = sel[sel["Invoice_Date"] > as_of - pd.Timedelta(days=365)].groupby("account_key")[Q].sum()
    r = reg.set_index("account_key")
    kids = pd.DataFrame({
        "account_key": am["account_key"], "Account": am["account_label"], "account_name": am["account_name"],
        "Parent": am["parent_name"], "parent_key": am["parent_key"], "Territory": am["Territory_Name"],
        "Status": am["status"], "Units QTD": am["net_units"],
        "Units 12 mo": am["account_key"].map(yr).fillna(0.0),
        "Patients low": am["account_key"].map(pts["patients_low"]).fillna(0.0),
        "Patients high": am["account_key"].map(pts["patients_high"]).fillna(0.0),
        "Regime": am["account_key"].map(r["regime"]).fillna("—"),
        "Regime reason": am["account_key"].map(r["reason"]).fillna(""),
        "Days since last order": am["days_since_last"],
    })
    tot = kids["Units 12 mo"].clip(lower=0).sum()
    kids["Share"] = kids["Units 12 mo"].clip(lower=0) / tot if tot else 0.0
    kids["Active"] = kids["Days since last order"] <= 90
    par = (kids.groupby(["parent_key", "Parent"]).agg(
        **{"Units QTD": ("Units QTD", "sum"), "Units 12 mo": ("Units 12 mo", "sum"),
           "Patients low": ("Patients low", "sum"), "Patients high": ("Patients high", "sum"),
           "Active": ("Active", "sum"), "Children": ("account_key", "size"),
           "Run-rate children": ("Regime", lambda x: int((x == pe.RUNRATE).sum())), "Share": ("Share", "sum")})
           .reset_index())
    pm = M.parent_metrics(sel, am, md, window)
    par["Status"] = par["parent_key"].map(pm.set_index("parent_key")["status"]).fillna("Stable")
    par["Decline pattern"] = par["parent_key"].map(pm.set_index("parent_key")["decline_pattern"]).fillna("")
    out["children"] = kids.sort_values("Units 12 mo", ascending=False).reset_index(drop=True)
    out["parents"] = par.sort_values("Units 12 mo", ascending=False).reset_index(drop=True)
    out["concentration"] = pe.concentration(sel, as_of)
    steps, per_acct, prior = pe.growth_bridge(sel, as_of)
    out["bridge"], out["bridge_accounts"], out["bridge_prior"] = steps, per_acct, prior
    out["cohorts"] = pe.cohorts(ev, as_of, s)
    sales = sel[~sel["is_return"]]
    ev2 = sales.assign(_c=sales["Contract"].astype("string").fillna("—"),
                       _w=sales["Shipper_Name"].astype("string"),
                       _b=np.where(pe.is_340b(sales["Contract"], sales["Ship_To_Name"]), "340B", "Non-340B"))
    out["contract_mix"] = _monthly_share(ev2, "_c", as_of)
    out["wholesaler_mix"] = _monthly_share(ev2, "_w", as_of)
    out["b340_mix"] = _monthly_share(ev2, "_b", as_of)
    out["returns"] = pe.returns_rate_monthly(sel, as_of)
    out["duplicates"] = pe.likely_duplicates(sel)
    return out


def _monthly_share(d: pd.DataFrame, col: str, as_of, months: int = 12, top: int = 6) -> pd.DataFrame:
    if d.empty:
        return pd.DataFrame()
    last = pd.Timestamp(fc.month_start(fc.to_date(as_of)))
    idx = pd.date_range(last - pd.DateOffset(months=months - 1), last, freq="MS")
    m = d.assign(_m=d["Invoice_Date"].dt.to_period("M").dt.to_timestamp())
    m = m[m["_m"] >= idx[0]]
    keep = m.groupby(col)[Q].sum().sort_values(ascending=False).head(top).index
    m = m.assign(**{col: m[col].where(m[col].isin(keep), "Other")})
    p = m.pivot_table(index="_m", columns=col, values=Q, aggfunc="sum", fill_value=0.0).reindex(idx, fill_value=0.0)
    p = p.div(p.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0) * 100
    p.index.name = "month"
    return p


def _forecast(sel, nxt, fcst, landing, res, as_of, people) -> dict:
    daily = F.expected_daily(res, nxt, 60)
    owners = _owner_map(people)
    info = (sel.sort_values("Invoice_Date").groupby("account_key")
            .agg(Account=("account_name", "last"), Parent=("parent_name", "last"),
                 Territory_ID=("Territory_ID", "last"), Territory=("Territory_Name", "last")))
    n = nxt.merge(info, left_on="account_key", right_index=True, how="left")
    n["Owner"] = n["Territory_ID"].map(owners) if owners is not None else pd.NA
    cad = n[(n["regime"] == pe.CADENCE) & n["expected_date"].notna() & (n["probability"] > 0)]
    soon = cad[(cad["expected_date"] > as_of) & (cad["expected_date"] <= as_of + pd.Timedelta(days=21))].copy()
    soon["Window"] = np.select([soon["expected_date"] <= as_of + pd.Timedelta(days=7),
                                soon["expected_date"] <= as_of + pd.Timedelta(days=14)],
                               ["Next 7 days", "8–14 days"], "15–21 days")
    over = n[n["is_overdue"]].copy()
    over["units_at_stake"] = over["expected_units"] * over["probability"]
    return {"table": fcst.table, "history": fcst.history, "fc": fcst, "landing": landing,
            "calendar": F.calendar_6w(daily, as_of), "soon": soon.sort_values("expected_date"),
            "overdue": over.sort_values("units_at_stake", ascending=False),
            "runrate": n[n["regime"] == pe.RUNRATE].sort_values("weekly_rate", ascending=False),
            "next": n}


def _owner_map(people):
    if people is None or not getattr(people, "available", False) or people.owners.empty:
        return None
    return people.owners.set_index("Territory_ID")["owner_name"]


def _new_owners(people, actions) -> pd.DataFrame:
    if people is None or not getattr(people, "available", False) or people.owners.empty:
        return pd.DataFrame()
    o = people.owners[people.owners["new_to_territory"]]
    return o[["Territory_ID", "Territory_Name", "owner_name", "owner_start_date"]]


# =============================================================================
# One-sentence takeaways (built from the numbers)
# =============================================================================
def _takeaways(dd: DeepDive) -> dict:
    p = config.PRODUCT_PROFILES[dd.product]
    unit = p["units"]
    sn = dd.snapshot
    t = {}
    k = sn.get("qtd_kpi")
    pts = sn["patients"]
    if k is not None:
        cmp = "" if k.pct is None else f", {abs(k.pct):.0f}% {'above' if k.pct >= 0 else 'below'} the same days of the last 3 quarters"
        t["snapshot"] = (f"{k.current:,.0f} {unit} so far in {sn['quarter']}{cmp}, about "
                         f"{pe.fmt_patients(pts['low'], pts['high'])} estimated patients on treatment now.")
    w = dd.demand["weekly"]
    last13, prev13 = w["units"].tail(13).sum(), w["units"].iloc[-26:-13].sum()
    trend = "up" if last13 > prev13 * 1.05 else "down" if last13 < prev13 * 0.95 else "flat"
    nc = dd.demand["no_charge"]
    t["demand"] = (f"The last 13 weeks shipped {last13:,.0f} {unit} (≈{last13 / dd.settings['units_per_cycle']:,.0f} "
                   f"cycles), {trend} on the 13 before" + (f"; {nc['share']:.0%} were no-charge." if nc["units"] else "."))
    r = dd.rhythm
    pers = r["persistence"]
    if pers.n_courses:
        med = f"half of courses end by cycle {int(pers.median_cycles)}" if pers.median_cycles else \
            "more than half of courses are still going"
        t["rhythm"] = (f"{r['pct_on_schedule']:.0f}% of reorders land on schedule; {med}"
                       + (f", and {pers.drop_after_1:.0%} stop after cycle 1." if pers.drop_after_1 is not None else ".")) \
            if r["pct_on_schedule"] is not None else f"{med.capitalize()}."
    else:
        t["rhythm"] = "Too few single-patient (cadence) courses in this selection to measure treatment rhythm."
    a = dd.accounts
    if len(a.get("parents", [])):
        c = a["concentration"]
        top5 = c["top5"].iloc[0] if len(c) else np.nan
        b = a["bridge"].set_index("step")["value"]
        t["accounts"] = (f"{sn['active_children']} of {sn['total_children']} accounts ordered in the last 90 days"
                         + (f"; the top 5 parents take {top5:.0f}% of this quarter's units" if top5 == top5 else "")
                         + f"; new and reactivated accounts added {b.get('New', 0) + b.get('Reactivated', 0):,.0f} {unit} "
                           f"vs last quarter.")
    else:
        t["accounts"] = "No accounts in this selection."
    land = dd.forecast["landing"]
    if land.get("avg_last3"):
        t["forecast"] = (f"{land['quarter']} is projected to land near {land['projected']:,.0f} {unit} "
                         f"({land['lo']:,.0f}–{land['hi']:,.0f}), "
                         f"{abs(land['vs_avg_pct']):.0f}% {'above' if land['vs_avg_pct'] >= 0 else 'below'} the last "
                         f"{land['n_past']} quarters' average; {len(dd.forecast['overdue'])} accounts are overdue.")
    else:
        t["forecast"] = (f"{land['quarter']} is projected to land near {land['projected']:,.0f} {unit}; "
                         f"{len(dd.forecast['overdue'])} accounts are overdue.")
    acts = dd.actions["actions"]
    chase = acts[acts["action"] != "Course likely completed"] if len(acts) else acts
    t["actions"] = (f"{len(acts)} field actions; {len(chase)} to act on carry {chase['units_at_stake'].sum():,.0f} "
                    f"{unit} at stake, plus {len(dd.actions['trade'])} items for trade/operations.") if len(acts) else \
        f"No field actions for this selection; {len(dd.actions['trade'])} items for trade/operations."
    return t
