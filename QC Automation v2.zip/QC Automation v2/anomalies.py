"""Anomaly rules: spike, drop, lapsed, suspicious. Every flag carries a plain-English reason."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

import config
import fiscal_calendar as fc
from metrics import geo_change, order_table, rolling_month_buckets, bucket_units, weekly_series

Q = config.QTY_COLUMN  # analysis quantity (Factored_QTY), returns negative

FLAG_COLUMNS = ["account_key", "flag", "severity", "date", "reason"]


def _fmt(v: float) -> str:
    return f"{v:,.0f}" if abs(v - round(v)) < 1e-9 else f"{v:,.1f}"


# =============================================================================
# Series anomalies (Overview charts and account drill-down)
# =============================================================================
def series_anomalies(series: pd.DataFrame, value_col: str = "units", date_col: str = "week_start",
                     n_roll: int = 13, k: float = 2.0, consecutive: int = 3,
                     period_word: str = "week", skip_partial: bool = True) -> pd.DataFrame:
    """Spike / drop markers on a regular series (zero-filled)."""
    s = series.reset_index(drop=True).copy()
    vals = s[value_col].astype(float)
    base = vals.shift(1).rolling(n_roll, min_periods=max(4, n_roll // 2))
    mean, sd = base.mean(), base.std(ddof=0)
    out = []
    declines = 0
    for i in range(len(s)):
        partial = bool(s.get("partial", pd.Series(False, index=s.index)).iloc[i]) if skip_partial else False
        v = vals.iloc[i]
        if i > 0:
            declines = declines + 1 if v < vals.iloc[i - 1] else 0
        if partial or np.isnan(mean.iloc[i]):
            continue
        mu, sig = mean.iloc[i], sd.iloc[i]
        when = fc.fmt_date(s[date_col].iloc[i])
        if sig > 0 and v > mu + k * sig:
            out.append({"date": s[date_col].iloc[i], "value": v, "kind": "spike",
                        "reason": f"{period_word.capitalize()} of {when}: {_fmt(v)} units, above the {n_roll}-{period_word} "
                                  f"average of {_fmt(mu)} by more than {k:g} SD"})
        elif sig > 0 and v < mu - k * sig:
            out.append({"date": s[date_col].iloc[i], "value": v, "kind": "drop",
                        "reason": f"{period_word.capitalize()} of {when}: {_fmt(v)} units, below the {n_roll}-{period_word} "
                                  f"average of {_fmt(mu)} by more than {k:g} SD"})
        elif declines >= consecutive:
            out.append({"date": s[date_col].iloc[i], "value": v, "kind": "drop",
                        "reason": f"{period_word.capitalize()} of {when}: {declines} consecutive {period_word}ly declines"})
    return pd.DataFrame(out, columns=["date", "value", "kind", "reason"])


# =============================================================================
# Account flags
# =============================================================================
def account_flags(df: pd.DataFrame, metrics_df: pd.DataFrame, as_of, window, th: dict | None = None) -> pd.DataFrame:
    """Flags for each account, evaluated on events inside `window`, baselines from full history."""
    th = {**config.DEFAULT_THRESHOLDS, **(th or {})}
    if df.empty or metrics_df.empty:
        return pd.DataFrame(columns=FLAG_COLUMNS)
    as_of_ts = pd.Timestamp(fc.to_date(as_of))
    ws, we = pd.Timestamp(window[0]), pd.Timestamp(window[1])
    hist = df[df["Invoice_Date"] <= as_of_ts]
    m = metrics_df.set_index("account_key")
    typical = m["typical_order_size"]
    flags: list[dict] = []
    k = th["sd_multiplier"]

    # --- Orders: spike (>200% typical) and suspicious large orders --------------------
    orders = order_table(hist)
    orders = orders.merge(typical.rename("typ"), left_on="account_key", right_index=True, how="left")
    n_orders = orders.groupby("account_key")["units"].transform("size")
    win_orders = orders[(orders["Invoice_Date"] >= ws) & (orders["Invoice_Date"] <= we) & (n_orders >= 3)]
    win_orders = win_orders.sort_values("Invoice_Date", ascending=False)
    order_spikes: dict = {}
    for r in win_orders.itertuples():
        if r.typ and r.typ > 0:
            ratio = r.units / r.typ
            if ratio > th["large_order_ratio"]:
                flags.append({"account_key": r.account_key, "flag": "Suspicious", "severity": "watch",
                              "date": r.Invoice_Date,
                              "reason": f"Unusually large order on {fc.fmt_date(r.Invoice_Date)}: {_fmt(r.units)} units, "
                                        f"{ratio:.1f}× the typical order of {_fmt(r.typ)}"})
            elif ratio > th["spike_order_ratio"]:
                order_spikes[r.account_key] = order_spikes.get(r.account_key, 0) + 1
                if order_spikes[r.account_key] > 3:   # keep the three most recent per account
                    continue
                flags.append({"account_key": r.account_key, "flag": "Spike", "severity": "up", "date": r.Invoice_Date,
                              "reason": f"Order on {fc.fmt_date(r.Invoice_Date)}: {_fmt(r.units)} units, "
                                        f"{ratio:.1f}× the typical order of {_fmt(r.typ)}"})

    # --- Spike / drop: rolling one-month periods vs the previous 6 ---------------------
    # Monthly periods (ending at as_of) suit oncology ordering, which is lumpy week to week.
    n_base = 6
    months_in_window = max(1, min(12, int(np.ceil((we - ws).days / 30.4))))
    buckets = rolling_month_buckets(as_of_ts, n_base + months_in_window)
    bm = bucket_units(hist, "account_key", buckets)
    if len(bm):
        vals = bm.values.astype(float)
        cons = int(th["consecutive_declines"])
        for j in range(n_base, vals.shape[1]):
            b_start, b_end = buckets[j]
            if b_end < ws:
                continue
            base = vals[:, j - n_base:j]
            mu, sd = base.mean(axis=1), base.std(axis=1)
            label = f"{fc.fmt_date(b_start)} – {fc.fmt_date(b_end)}"
            big = np.abs(vals[:, j] - mu) >= (th["min_change_pct"] / 100.0) * np.maximum(mu, 1e-9)
            for i in np.where((sd > 0) & (vals[:, j] > mu + k * sd) & (mu > 0) & big)[0]:
                flags.append({"account_key": bm.index[i], "flag": "Spike", "severity": "up", "date": b_end,
                              "reason": f"Month {label}: {_fmt(vals[i, j])} units vs a 6-month average of "
                                        f"{_fmt(mu[i])} (more than {k:g} SD above)"})
            for i in np.where((sd > 0) & (vals[:, j] < mu - k * sd) & big)[0]:
                flags.append({"account_key": bm.index[i], "flag": "Drop", "severity": "down", "date": b_end,
                              "reason": f"Month {label}: {_fmt(vals[i, j])} units vs a 6-month average of "
                                        f"{_fmt(mu[i])} (more than {k:g} SD below)"})
        # N consecutive declining months ending with the latest
        for i, key in enumerate(bm.index):
            seq = vals[i, -(cons + 1):]
            if len(seq) == cons + 1 and np.all(np.diff(seq) < 0):
                flags.append({"account_key": key, "flag": "Drop", "severity": "down", "date": as_of_ts,
                              "reason": f"{cons} consecutive monthly declines: "
                                        + " → ".join(_fmt(v) for v in seq) + " units"})

    # --- Lapsed ------------------------------------------------------------------------------
    for key, r in m[m["is_lapsed"]].iterrows():
        if r["orders_history"] >= 2 and pd.notna(r["typical_interval"]):
            why = (f"No order in {int(r['days_since_last'])} days; it usually orders every "
                   f"{_fmt(r['typical_interval'])} days")
        else:
            why = f"No order in {int(r['days_since_last'])} days (only one order on record)"
        flags.append({"account_key": key, "flag": "Lapsed", "severity": "watch", "date": r["last_invoice"], "reason": why})

    win = hist[(hist["Invoice_Date"] >= ws) & (hist["Invoice_Date"] <= we)]

    # --- Suspicious: large returns ------------------------------------------------------------
    rets = win[win["is_return"]].merge(typical.rename("typ"), left_on="account_key", right_index=True, how="left")
    for r in rets.itertuples():
        size = abs(getattr(r, Q))
        if r.typ and r.typ > 0 and size > th["large_return_ratio"] * r.typ:
            flags.append({"account_key": r.account_key, "flag": "Suspicious", "severity": "watch", "date": r.Invoice_Date,
                          "reason": f"Large return on {fc.fmt_date(r.Invoice_Date)}: {_fmt(size)} units, "
                                    f"{size / r.typ:.1f}× the typical order"})

    # --- Suspicious: returns exceed purchases in a month ---------------------------------------
    if len(win):
        mon = win.assign(_m=win["Invoice_Date"].dt.to_period("M"))
        g = mon.groupby(["account_key", "_m", "is_return"])[Q].sum().unstack(fill_value=0.0)
        if True in g.columns:
            sales_ = g[False] if False in g.columns else 0.0
            bad = g[(-g[True]) > sales_]
            for (key, per), r in bad.iterrows():
                flags.append({"account_key": key, "flag": "Suspicious", "severity": "watch",
                              "date": per.to_timestamp(),
                              "reason": f"Returns exceeded purchases in {per.strftime('%b %Y')}: "
                                        f"{_fmt(-r[True])} returned vs {_fmt(r.get(False, 0.0))} bought"})

    # --- Suspicious: likely duplicates ----------------------------------------------------------
    if len(win):
        dkeys = ["Wholesaler_Invoice_ID", "account_key", "Invoice_Date", Q]
        dd = win[win["Wholesaler_Invoice_ID"].notna()]
        dup = dd[dd.duplicated(dkeys, keep=False)]
        for (wiid, key, d, q), grp in dup.groupby(dkeys):
            flags.append({"account_key": key, "flag": "Suspicious", "severity": "watch", "date": d,
                          "reason": f"Likely duplicate: invoice {wiid} appears {len(grp)} times on "
                                    f"{fc.fmt_date(d)} with {_fmt(q)} units"})

    # --- Suspicious: wholesaler switch ------------------------------------------------------------
    # Recent orders (last 45 days) all via wholesalers other than the one that carried
    # at least 80% of the account's units over the previous 12 months.
    recent_start = as_of_ts - pd.Timedelta(days=45)
    o = order_table(hist)
    if len(o) and recent_start <= we:
        recent = o[o["Invoice_Date"] >= max(recent_start, ws)]
        prior = o[(o["Invoice_Date"] < recent_start) & (o["Invoice_Date"] >= recent_start - pd.Timedelta(days=365))]
        pm = prior.groupby(["account_key", "Shipper_Name"])["units"].sum().reset_index()
        pm["share"] = pm["units"] / pm.groupby("account_key")["units"].transform("sum")
        pcount = prior.groupby("account_key").size()
        main_prior = pm.sort_values("share", ascending=False).drop_duplicates("account_key").set_index("account_key")
        for key, grp in recent.groupby("account_key"):
            if key not in main_prior.index or pcount.get(key, 0) < 3:
                continue
            old = main_prior.loc[key]
            if old["share"] < 0.8:
                continue
            new = set(grp["Shipper_Name"].astype(str))
            if old["Shipper_Name"] not in new:
                flags.append({"account_key": key, "flag": "Suspicious", "severity": "watch",
                              "date": grp["Invoice_Date"].max(),
                              "reason": f"Switched wholesaler: orders since {fc.fmt_date(recent_start)} via "
                                        f"{', '.join(sorted(new))}; previously {old['share']:.0%} via {old['Shipper_Name']}"})

    out = pd.DataFrame(flags, columns=FLAG_COLUMNS)
    return out.sort_values(["account_key", "date"], ascending=[True, False]).reset_index(drop=True)


def flags_summary(flags: pd.DataFrame) -> pd.Series:
    """account_key -> short text like 'Spike, Suspicious ×2'."""
    if flags.empty:
        return pd.Series(dtype="string")

    def short(g):
        vc = g["flag"].value_counts()
        return ", ".join(f"{f}" + (f" ×{n}" if n > 1 else "") for f, n in vc.items())

    return flags.groupby("account_key").apply(short, include_groups=False)


# =============================================================================
# Overview alerts
# =============================================================================
@dataclass
class Alert:
    severity: str        # "up" | "down" | "watch"
    entity: str          # bold lead, e.g. "BOSTON, MA"
    rest: str            # "is down 42% vs its 13-week average"
    chips: tuple         # ("Territory", "Week to date")
    level: str           # "Region" | "Territory" | "Account" | "Product" | "Data quality"
    name: str | None     # filter value for Region / Territory alerts
    magnitude: float

    @property
    def sentence(self) -> str:
        return f"{self.entity} {self.rest}"

    @property
    def scope(self) -> str:
        return ", ".join(self.chips)


def account_alerts(df: pd.DataFrame, max_date, th: dict | None = None, limit_each: int = 3) -> list[Alert]:
    """Account-level alerts for the Overview: order gaps, large recent returns, weekly spikes."""
    from metrics import entity_metrics, order_table

    th = {**config.DEFAULT_THRESHOLDS, **(th or {})}
    if df.empty:
        return []
    md = pd.Timestamp(fc.to_date(max_date))
    names = df.sort_values("Invoice_Date").groupby("account_key")["account_name"].last()
    out: list[Alert] = []
    m = entity_metrics(df, "account_key", md, None, th)
    if m.empty:
        return out
    m = m.set_index("account_key")
    m["vol6"] = m["last3"] + m["prior3"]

    # Order gaps: lapsed against the account's own cadence, biggest accounts first
    lap = m[m["is_lapsed"] & (m["orders_history"] >= 3) & m["typical_interval"].notna() & (m["vol6"] > 0)]
    for key, r in lap.sort_values("vol6", ascending=False).head(limit_each).iterrows():
        ratio = r["days_since_last"] / max(1.0, r["typical_interval"])
        out.append(Alert("watch", str(names.get(key, key)),
                         f"hasn't ordered in {int(r['days_since_last'])} days, about {ratio:.0f}× its usual interval",
                         ("Account", "Order gap"), "Account", None, 50 + ratio))

    # Large returns in the last 14 days
    recent = df[(df["Invoice_Date"] > md - pd.Timedelta(days=14)) & df["is_return"]]
    if len(recent):
        rr = recent.merge(m["typical_order_size"].rename("typ"), left_on="account_key", right_index=True, how="left")
        rr["size"] = rr[Q].abs()
        rr = rr[(rr["typ"].notna()) & (rr["size"] > th["large_return_ratio"] * rr["typ"])]
        for r in rr.sort_values("size", ascending=False).drop_duplicates("account_key").head(limit_each).itertuples():
            out.append(Alert("watch", str(names.get(r.account_key, r.account_key)),
                             f"had a large return of {_fmt(r.size)} units",
                             ("Account", f"Return, {r.Invoice_Date:%b} {r.Invoice_Date.day}"), "Account", None, 40))

    # Week-to-date spikes vs the account's 13-week weekly average
    ws = md - pd.Timedelta(days=md.weekday())
    cur = df[(df["Invoice_Date"] >= ws) & (df["Invoice_Date"] <= md)].groupby("account_key")[Q].sum()
    base = df[(df["Invoice_Date"] >= ws - pd.Timedelta(weeks=13)) & (df["Invoice_Date"] < ws)]
    avg = base.groupby("account_key")[Q].sum() / 13.0
    both = pd.DataFrame({"cur": cur, "avg": avg}).dropna()
    both = both[(both["avg"] > 0) & (both["cur"] >= 5)]
    both["ratio"] = both["cur"] / both["avg"]
    for key, r in both[both["ratio"] >= th["spike_order_ratio"]].sort_values("ratio", ascending=False).head(limit_each).iterrows():
        out.append(Alert("up", str(names.get(key, key)),
                         f"ordered {_fmt(r['cur'])} units, {r['ratio']:.1f}× its weekly average",
                         ("Account", "Week to date"), "Account", None, r["ratio"] * 10))
    return out


def overview_alerts(df: pd.DataFrame, product: str, max_date, same_weekdays: bool = True,
                    th: dict | None = None, min_avg_units: float = 3.0) -> list[Alert]:
    th = {**config.DEFAULT_THRESHOLDS, **(th or {})}
    alert_pct = th["alert_pct"]
    geo: list[Alert] = []
    period_words = {"week": ("Week to date", "13-week average"), "month": ("Month to date", "3-month average")}
    for pk in ["week", "month"]:
        for level in ["Territory", "Region"]:
            gc = geo_change(df, level, max_date, pk, same_weekdays)
            for r in gc.itertuples():
                if r.pct is None or pd.isna(r.pct) or r.average < min_avg_units or abs(r.pct) < alert_pct:
                    continue
                if r.name == config.UNALIGNED:
                    continue
                up = r.pct > 0
                pw, avgw = period_words[pk]
                shown = str(r.name) if level == "Territory" else str(r.name).title()
                geo.append(Alert("up" if up else "down", shown,
                                 f"is {'up' if up else 'down'} {abs(r.pct):.1f}% vs its {avgw}".replace(".0%", "%"),
                                 (level, pw), level, r.name, abs(r.pct)))
    # one alert per geography (week wins over month)
    seen, geo_u = set(), []
    for a in geo:
        if (a.level, a.name) in seen:
            continue
        seen.add((a.level, a.name))
        geo_u.append(a)

    prod: list[Alert] = []
    ws = weekly_series(df, max_date, 26)
    an = series_anomalies(ws, n_roll=int(th["rolling_periods"]), k=th["sd_multiplier"],
                          consecutive=int(th["consecutive_declines"]))
    recent = pd.Timestamp(fc.week_start(max_date)) - pd.Timedelta(weeks=3)
    for r in an[an["date"] >= recent].itertuples():
        prod.append(Alert("up" if r.kind == "spike" else "down", product,
                          r.reason[0].lower() + r.reason[1:], ("Product", "Weekly trend"), "Product", None, 30))

    dq: list[Alert] = []
    cur = df[(df["Invoice_Date"] >= pd.Timestamp(fc.quarter_start(max_date))) &
             (df["Invoice_Date"] <= pd.Timestamp(max_date))]
    if len(cur):
        un = cur.loc[cur["Territory_Name"] == config.UNALIGNED, Q].sum()
        tot = cur[Q].sum()
        if tot > 0 and un / tot >= 0.05:
            dq.append(Alert("watch", "Unaligned zips", f"hold {un / tot:.0%} of quarter-to-date units",
                            ("Data quality", "Quarter to date"), "Territory", config.UNALIGNED, un / tot * 100))

    acct = account_alerts(df, max_date, th)
    downs = sorted([a for a in geo_u + prod if a.severity == "down"], key=lambda a: -a.magnitude)
    ups = sorted([a for a in geo_u + prod if a.severity == "up"], key=lambda a: -a.magnitude)
    watch = sorted([a for a in acct if a.severity == "watch"], key=lambda a: -a.magnitude)
    acct_up = [a for a in acct if a.severity == "up"]
    # Interleave so the first five show a mix, as in the design: biggest drop, then account issues, then gains.
    head = downs[:1] + watch[:2] + acct_up[:1] + ups[:1]
    rest = [a for a in downs + watch + acct_up + ups + dq if a not in head]
    return head + rest
