"""Fiscal calendar and comparison windows. Pure functions, no I/O.

Conventions
- Fiscal year starts April 1. Q1 = Apr–Jun, Q2 = Jul–Sep, Q3 = Oct–Dec, Q4 = Jan–Mar.
- Apr 2026 – Mar 2027 is labelled "FY 2026-27".
- Weeks run Monday–Sunday.
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from datetime import date, timedelta

import pandas as pd

FY_START_MONTH = 4


def to_date(d) -> date:
    if isinstance(d, pd.Timestamp):
        return d.date()
    if hasattr(d, "date") and not isinstance(d, date):
        return d.date()
    if isinstance(d, date):
        return d if type(d) is date else date(d.year, d.month, d.day)
    return pd.Timestamp(d).date()


# --- Fiscal year / quarter ---------------------------------------------------
def fiscal_year_start(d) -> date:
    d = to_date(d)
    y = d.year if d.month >= FY_START_MONTH else d.year - 1
    return date(y, FY_START_MONTH, 1)


def fiscal_year_end_year(d) -> int:
    """Calendar year in which the fiscal year containing d ends (2027 for Oct 2026)."""
    return fiscal_year_start(d).year + 1


def fiscal_year_label(d) -> str:
    start = fiscal_year_start(d).year
    return f"FY {start}-{str(start + 1)[-2:]}"


def fiscal_quarter(d) -> int:
    d = to_date(d)
    return ((d.month - FY_START_MONTH) % 12) // 3 + 1


def quarter_start(d) -> date:
    d = to_date(d)
    month_offset = (d.month - FY_START_MONTH) % 3
    m = d.month - month_offset
    y = d.year
    if m <= 0:
        m += 12
        y -= 1
    return date(y, m, 1)


def add_months(d, n: int) -> date:
    d = to_date(d)
    m0 = d.month - 1 + n
    y = d.year + m0 // 12
    m = m0 % 12 + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def quarter_end(d) -> date:
    qs = quarter_start(d)
    return add_months(qs, 3) - timedelta(days=1)


def shift_quarter(d, n: int) -> date:
    """Start of the fiscal quarter n quarters away from the one containing d."""
    return add_months(quarter_start(d), 3 * n)


def quarter_label(d) -> str:
    return f"Q{fiscal_quarter(d)} {fiscal_year_label(d)}"


# --- Weeks / months --------------------------------------------------------
def week_start(d) -> date:
    d = to_date(d)
    return d - timedelta(days=d.weekday())


def week_end(d) -> date:
    return week_start(d) + timedelta(days=6)


def month_start(d) -> date:
    d = to_date(d)
    return date(d.year, d.month, 1)


def month_end(d) -> date:
    d = to_date(d)
    return date(d.year, d.month, calendar.monthrange(d.year, d.month)[1])


# --- Comparison windows ------------------------------------------------------
Window = tuple[date, date]  # inclusive start and end


@dataclass
class PeriodWindows:
    key: str                       # "week" | "month" | "quarter"
    title: str                     # "Week to date", "Q3 FY 2026-27 to date"
    current: Window
    comparisons: list[Window] = field(default_factory=list)
    comparison_note: str = ""


def week_windows(max_date, n_weeks: int = 13, same_weekdays: bool = True) -> PeriodWindows:
    md = to_date(max_date)
    ws = week_start(md)
    days_in = (md - ws).days  # 0 = Monday
    partial = days_in < 6
    comps: list[Window] = []
    for i in range(1, n_weeks + 1):
        s = ws - timedelta(weeks=i)
        e = s + timedelta(days=days_in) if (same_weekdays and partial) else s + timedelta(days=6)
        comps.append((s, e))
    if partial and same_weekdays:
        first = ws.strftime("%a")
        last = md.strftime("%a")
        note = f"Compared with {first}–{last} of each of the previous {n_weeks} weeks"
    else:
        note = f"Compared with the full Mon–Sun weeks of the previous {n_weeks} weeks"
    return PeriodWindows("week", "Week to date", (ws, md), comps, note)


def month_windows(max_date, n_months: int = 3) -> PeriodWindows:
    md = to_date(max_date)
    ms = month_start(md)
    day = md.day
    comps: list[Window] = []
    for i in range(1, n_months + 1):
        s = add_months(ms, -i)
        e = min(date(s.year, s.month, min(day, calendar.monthrange(s.year, s.month)[1])), month_end(s))
        comps.append((s, e))
    note = f"Compared with days 1–{day} of each of the previous {n_months} months (capped at month end)"
    return PeriodWindows("month", "Month to date", (ms, md), comps, note)


def quarter_windows(max_date, n_quarters: int = 3) -> PeriodWindows:
    md = to_date(max_date)
    qs = quarter_start(md)
    n_days = (md - qs).days + 1
    comps: list[Window] = []
    for i in range(1, n_quarters + 1):
        s = shift_quarter(qs, -i)
        e = min(s + timedelta(days=n_days - 1), quarter_end(s))
        comps.append((s, e))
    note = f"Compared with the first {n_days} days of each of the previous {n_quarters} fiscal quarters"
    return PeriodWindows("quarter", f"{quarter_label(md)} to date", (qs, md), comps, note)


def all_period_windows(max_date, same_weekdays: bool = True) -> list[PeriodWindows]:
    return [week_windows(max_date, same_weekdays=same_weekdays), month_windows(max_date), quarter_windows(max_date)]


# --- Timeframe presets -------------------------------------------------------
def minimum_analysis_start(anchor) -> date:
    """Start of the fiscal quarter three quarters before the anchor's quarter."""
    return shift_quarter(anchor, -3)


def required_start(anchor) -> date:
    """Earliest date any Overview metric needs (13 prior weeks, 3 months, 3 quarters)."""
    a = to_date(anchor)
    return min(
        week_start(a) - timedelta(weeks=13),
        add_months(month_start(a), -3),
        shift_quarter(a, -3),
    )


def preset_range(preset: str, anchor, today=None, history_start_year: int = 2018) -> Window:
    a = to_date(anchor)
    t = to_date(today) if today is not None else a
    end = max(a, t) if preset.startswith("Full") else a
    if preset == "Minimum for analysis":
        return minimum_analysis_start(a), a
    if preset == "Last 12 months":
        return add_months(a, -12) + timedelta(days=1), a
    if preset == "Last 2 years":
        return add_months(a, -24) + timedelta(days=1), a
    if preset.startswith("Full history"):
        return date(history_start_year, 1, 1), end
    raise ValueError(f"Unknown preset '{preset}'")


def range_warnings(start, end, anchor) -> list[str]:
    """Plain-English warnings for ranges too short for some metrics."""
    s, a = to_date(start), to_date(anchor)
    out: list[str] = []
    wk = week_windows(a)
    if s > wk.comparisons[-1][0]:
        out.append("Week to date comparison needs the previous 13 weeks; some will be missing.")
    if s > month_windows(a).comparisons[-1][0]:
        out.append("Month to date comparison needs the previous 3 months; some will be missing.")
    if s > quarter_windows(a).comparisons[-1][0]:
        out.append("Quarter to date comparison needs the previous 3 fiscal quarters; some will be missing.")
    if s > add_months(a, -6):
        out.append("Account trend status and slope need 6 months of history.")
    if s > week_start(a) - timedelta(weeks=26):
        out.append("The 26-week trend chart and sparklines will be partly empty.")
    return out


def week_starts_between(start, end) -> list[date]:
    s, e = week_start(start), week_start(end)
    out = []
    while s <= e:
        out.append(s)
        s += timedelta(weeks=1)
    return out


def fmt_date(d) -> str:
    d = to_date(d)
    return f"{d.strftime('%b')} {d.day}, {d.year}"


def fmt_range(w: Window) -> str:
    s, e = w
    if s.year == e.year:
        if s.month == e.month:
            return f"{s.strftime('%b')} {s.day}–{e.day}, {e.year}" if s != e else fmt_date(s)
        return f"{s.strftime('%b')} {s.day} – {e.strftime('%b')} {e.day}, {e.year}"
    return f"{fmt_date(s)} – {fmt_date(e)}"
