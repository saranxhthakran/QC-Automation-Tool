"""Field action plan: ranked, evidence-backed actions per territory, a trade/operations list, and the
templated narrative. Pure functions, no Streamlit.

Compliance: recommendations stay within the approved labels, never suggest dosing or other indications,
and never identify a patient. Clinical or dosing questions go to Medical Affairs; inventory, returns,
contract and wholesaler matters go to trade/operations, not field sales.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import config
import fiscal_calendar as fc
import forecast as F
import metrics as M
import product_engine as pe

Q = config.QTY_COLUMN

ACTION_TYPES = [
    "Continuation check", "New start follow-through", "Course likely completed", "Concentrated decline",
    "Lapsed high-value account", "RYZNEUTA adoption", "Run-rate slowdown",
]
TRADE = "Route to trade or operations"
NEXT_STEP = {
    "Continuation check": "Check in with the site on reorder timing and any access or reimbursement support.",
    "New start follow-through": "Make sure the next cycle's order is set up with the site.",
    "Course likely completed": ("Don't chase this order. Shift to education on the approved indication "
                                "for future patients."),
    "Concentrated decline": "Visit this account: most of the parent's decline sits here.",
    "Lapsed high-value account": "Plan a re-engagement visit.",
    "RYZNEUTA adoption": "Follow up on reordering: one order so far and no reorder.",
    "Run-rate slowdown": "Ask the site about its recent ordering; weekly volume is well below its usual level.",
}
CONF_P = {F.HIGH: 0.9, F.MEDIUM: 0.7, F.LOW: 0.5}
ACTION_COLUMNS = ["Territory_ID", "Territory_Name", "Region_Name", "owner", "new_to_territory", "account_key",
                  "account_name", "parent_name", "action", "next_step", "evidence", "units_at_stake",
                  "probability", "urgency", "due_by", "confidence", "priority"]


def units_text(n: float, product: str) -> str:
    """'1 syringe', '3 syringes', '20 vials'."""
    p = config.PRODUCT_PROFILES[product]
    return f"{n:,.0f} {p['unit'] if round(float(n)) == 1 else p['units']}"


def _d(x) -> str:
    x = pd.Timestamp(x)
    return f"{x:%b} {x.day}"


def build_actions(res: pe.EngineResult, nxt: pd.DataFrame, df: pd.DataFrame, people=None,
                  keys: set | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """(field actions, trade/ops items). `df` = product rows (history window); keys limits to a selection."""
    s, as_of = res.settings, res.as_of
    unit = config.PRODUCT_PROFILES[res.product]["units"]
    cyc_days = int(s["cycle_days"])
    tol = int(s["overdue_tolerance_days"])
    sel = df if keys is None else df[df["account_key"].isin(keys)]
    n = nxt if keys is None else nxt[nxt["account_key"].isin(keys)]
    courses = res.courses if keys is None else res.courses[res.courses["account_key"].isin(keys)]
    ev = res.events if keys is None else res.events[res.events["account_key"].isin(keys)]
    acts = []

    def add(key, action, evidence, units, prob, urgency, due, conf):
        acts.append({"account_key": key, "action": action, "next_step": NEXT_STEP[action], "evidence": evidence,
                     "units_at_stake": float(max(0.0, units)), "probability": float(prob),
                     "urgency": float(urgency), "due_by": pd.Timestamp(due), "confidence": conf})

    # 1. Continuation check: an ongoing course is overdue
    for r in n[n["is_overdue"]].itertuples():
        nxt_cycle = int(r.current_cycle) + 1 if r.current_cycle == r.current_cycle else None
        lead = f"Cycle {nxt_cycle} expected {_d(r.expected_date)}" if nxt_cycle else f"Order expected {_d(r.expected_date)}"
        evid = (f"{lead}; no order in {(as_of - r.last_event).days} days; usually orders every "
                f"{r.interval:.0f} days. {r.explanation}")
        urg = 1 + min(2.0, r.days_overdue / cyc_days)
        add(r.account_key, "Continuation check", evid, r.expected_units, r.probability or CONF_P[r.confidence],
            urg, as_of + pd.Timedelta(days=7), r.confidence)

    # 2. New start follow-through: a course started in the last N days
    drop1 = res.persistence.drop_after_1 or 0.0
    recent = courses[(courses["start"] > as_of - pd.Timedelta(days=int(s["new_start_days"]))) & ~courses["left_censored"]]
    nx = n.set_index("account_key")
    for c in recent.itertuples():
        exp = nx.loc[c.account_key, "expected_date"] if c.account_key in nx.index else c.last_event + pd.Timedelta(days=cyc_days)
        units = nx.loc[c.account_key, "expected_units"] if c.account_key in nx.index else s["units_per_cycle"]
        evid = (f"Course started {_d(c.start)} ({int(c.cycles)} cycle{'s' if c.cycles > 1 else ''} so far); next "
                f"cycle expected around {_d(exp)}.")
        if not s.get("fixed_units_per_cycle") and drop1 > 0:
            evid += f" {drop1:.0%} of courses stop after cycle 1."
        urg = 1.0 + (drop1 if not s.get("fixed_units_per_cycle") else 0.0)
        add(c.account_key, "New start follow-through", evid, units, 1 - drop1 if drop1 else 0.8, urg,
            max(as_of + pd.Timedelta(days=1), min(exp, as_of + pd.Timedelta(days=14))) if pd.notna(exp)
            else as_of + pd.Timedelta(days=14), F.MEDIUM)

    # 3. Course likely completed: ended within the lookback
    lb = int(s["completed_lookback_days"])
    max_gap = int(s["max_course_gap_days"])
    done = courses[(courses["status"] == pe.ENDED)
                   & (courses["last_event"] + pd.Timedelta(days=max_gap) > as_of - pd.Timedelta(days=lb))]
    for c in done.itertuples():
        evid = (f"Last order {_d(c.last_event)} after {int(c.cycles)} cycles; no order since ({c.days_since_last} days, "
                f"more than the {max_gap}-day course gap).")
        add(c.account_key, "Course likely completed", evid, c.units / max(1, c.cycles), 0.2, 0.5,
            as_of + pd.Timedelta(days=30), F.MEDIUM)

    # 4–5. Concentrated decline and lapsed high-value accounts (reuse the Accounts page metrics)
    am = M.account_metrics(sel, as_of.date(), None) if len(sel) else pd.DataFrame()
    if len(am):
        pm = M.parent_metrics(sel, am, as_of.date(), None)
        for p in pm.itertuples():
            if not str(p.decline_pattern).startswith("Concentrated") or p.parent_key == config.UNMAPPED \
                    or p.delta_3v3 >= 0:
                continue
            kids = am[(am["parent_key"] == p.parent_key) & (am["delta_3v3"] < 0)].sort_values("delta_3v3")
            if kids.empty:
                continue
            k = kids.iloc[0]
            share = k["delta_3v3"] / kids["delta_3v3"].sum()
            evid = (f"{p.parent_name} is down {units_text(abs(p.delta_3v3), res.product)} (last 3 months vs prior 3); "
                    f"{k['account_name']} is down {units_text(abs(k['delta_3v3']), res.product)}, {share:.0%} of the "
                    f"drop across its declining ship-tos.")
            add(k["account_key"], "Concentrated decline", evid, abs(k["delta_3v3"]) / 3, 0.6, 1.0,
                as_of + pd.Timedelta(days=14), F.MEDIUM)
        yr = sel[sel["Invoice_Date"] > as_of - pd.Timedelta(days=365)].groupby("account_key")[Q].sum()
        if len(yr):
            cut = np.percentile(yr.values, float(s["lapsed_high_value_pct"]))
            for a in am[am["status"] == "Lapsed"].itertuples():
                u = float(yr.get(a.account_key, 0.0))
                if u <= 0 or u < cut:
                    continue
                evid = (f"No order in {int(a.days_since_last)} days (usually every {a.typical_interval:.0f}); "
                        f"{u:,.0f} {unit} in the last 12 months.") if a.typical_interval == a.typical_interval else \
                       f"No order in {int(a.days_since_last)} days; {u:,.0f} {unit} in the last 12 months."
                add(a.account_key, "Lapsed high-value account", evid, u / 12, 0.4, 1.0, as_of + pd.Timedelta(days=14),
                    F.MEDIUM)

    # 6. RYZNEUTA adoption: one order and no reorder (target/decile part needs customer-master fields; deferred)
    if res.product == "RYZNEUTA":
        cnt = ev[ev["net_units"] > 0].groupby("account_key").agg(n=("start", "size"), first=("start", "min"),
                                                                 units=("net_units", "sum"))
        one = cnt[(cnt["n"] == 1) & (cnt["first"] < as_of - pd.Timedelta(days=cyc_days + tol))
                  & (cnt["first"] > as_of - pd.Timedelta(days=180))]
        for key, r in one.iterrows():
            evid = (f"First and only order {_d(r['first'])} ({units_text(r['units'], res.product)}); "
                    f"no reorder in {(as_of - r['first']).days} days.")
            add(key, "RYZNEUTA adoption", evid, s["units_per_cycle"], 0.4, 1.0, as_of + pd.Timedelta(days=21), F.LOW)

    # 7. Run-rate slowdown
    thr = 1 - float(s["runrate_slowdown_pct"]) / 100
    for r in n[(n["regime"] == pe.RUNRATE) & (n["w13"] > 0)].itertuples():
        if r.w4 < thr * r.w13:
            evid = (f"{r.w4:,.1f} {unit} a week over the last 4 weeks vs {r.w13:,.1f} over 13 weeks "
                    f"({(r.w4 / r.w13 - 1):+.0%}).")
            add(r.account_key, "Run-rate slowdown", evid, (r.w13 - r.w4) * 4, 0.6, 1.0, as_of + pd.Timedelta(days=7),
                r.confidence)

    out = pd.DataFrame(acts)
    out = _decorate(out, sel, people, s)
    trade = trade_items(res, sel, ev, people)
    return out, trade


def priority(units, prob, urgency, s: dict):
    u = np.maximum(np.asarray(units, dtype=float), 0.0)
    return (u ** float(s["w_units"])) * (np.asarray(prob, dtype=float) ** float(s["w_probability"])) * \
           (np.asarray(urgency, dtype=float) ** float(s["w_urgency"]))


def _decorate(out: pd.DataFrame, sel: pd.DataFrame, people, s: dict) -> pd.DataFrame:
    if out.empty:
        return pd.DataFrame(columns=ACTION_COLUMNS)
    info = (sel.sort_values("Invoice_Date").groupby("account_key")
            .agg(account_name=("account_name", "last"), parent_name=("parent_name", "last"),
                 Territory_ID=("Territory_ID", "last"), Territory_Name=("Territory_Name", "last"),
                 Region_Name=("Region_Name", "last")))
    out = out.merge(info, left_on="account_key", right_index=True, how="left")
    owners = people.owners.set_index("Territory_ID") if people is not None and getattr(people, "available", False) \
        and len(people.owners) else None
    out["owner"] = out["Territory_ID"].map(owners["owner_name"]) if owners is not None else pd.NA
    out["new_to_territory"] = (out["Territory_ID"].map(owners["new_to_territory"].astype(bool)).eq(True)
                               if owners is not None else False)
    out["priority"] = priority(out["units_at_stake"], out["probability"], out["urgency"], s)
    out = out.sort_values("priority", ascending=False).drop_duplicates(["account_key", "action"])
    return out[ACTION_COLUMNS].reset_index(drop=True)


def trade_items(res: pe.EngineResult, sel: pd.DataFrame, ev: pd.DataFrame, people=None) -> pd.DataFrame:
    """Stocking spikes, unusual returns, contract or 340B shifts, wholesaler switches, no-charge spikes
    in the last 13 weeks. Routed to trade/operations, never to field sales."""
    s, as_of = res.settings, res.as_of
    unit = config.PRODUCT_PROFILES[res.product]["units"]
    cut = as_of - pd.Timedelta(weeks=13)
    prev = cut - pd.Timedelta(weeks=13)
    rows = []
    e = ev[ev["net_units"] > 0]
    typ = e[e["start"] <= cut].groupby("account_key")["net_units"].median()
    for r in e[e["start"] > cut].itertuples():
        t = typ.get(r.account_key)
        if t and t > 0 and r.net_units > float(s["trade_stock_multiple"]) * t and r.net_units >= 2 * s["units_per_cycle"]:
            rows.append((r.account_key, "Stocking spike",
                         f"{r.net_units:,.0f} {unit} ordered {_d(r.start)}, {r.net_units / t:.1f}× its typical order."))
    cur = sel[sel["Invoice_Date"] > cut]
    old = sel[(sel["Invoice_Date"] > prev) & (sel["Invoice_Date"] <= cut)]
    for key, g in cur.groupby("account_key"):
        bought = g.loc[~g["is_return"], Q].sum()
        ret = -g.loc[g["is_return"], Q].sum()
        if ret > 0 and bought > 0 and ret / bought * 100 >= float(s["trade_return_share_pct"]):
            rows.append((key, "Unusual returns", f"{units_text(ret, res.product)} returned vs {bought:,.0f} bought in "
                                                 "the last 13 weeks."))
        elif ret > 0 and bought <= 0:
            rows.append((key, "Unusual returns", f"{units_text(ret, res.product)} returned and nothing bought in the "
                                                 "last 13 weeks."))
        o = old[old["account_key"] == key]
        if len(o) and bought > 0:
            for col, label in [("Shipper_Name", "Wholesaler switch"), ("Contract", "Contract shift")]:
                a = _main(o, col)
                b = _main(g, col)
                if a and b and a != b:
                    rows.append((key, label, f"Main {('wholesaler' if col == 'Shipper_Name' else 'contract')} moved "
                                            f"from {a} to {b} (last 13 weeks vs the 13 before)."))
            was = pe.is_340b(o.loc[~o["is_return"], "Contract"]).mean() if (~o["is_return"]).any() else 0
            now = pe.is_340b(g.loc[~g["is_return"], "Contract"]).mean() if (~g["is_return"]).any() else 0
            if abs(now - was) >= 0.5:
                rows.append((key, "340B shift", f"340B share of orders moved from {was:.0%} to {now:.0%}."))
        amt = pd.to_numeric(g["Extended_Amount"], errors="coerce") if "Extended_Amount" in g else pd.Series(dtype=float)
        nc = g.loc[(~g["is_return"]) & amt.eq(0).fillna(False), Q].sum()
        if bought > 0 and nc >= 2 and nc / bought * 100 >= float(s["trade_no_charge_share_pct"]):
            rows.append((key, "No-charge units", f"{nc:,.0f} of {bought:,.0f} {unit} were no-charge in the last 13 weeks."))
    t = pd.DataFrame(rows, columns=["account_key", "issue", "evidence"])
    if t.empty:
        return pd.DataFrame(columns=["Territory_Name", "account_name", "parent_name", "issue", "evidence", "route_to"])
    info = (sel.sort_values("Invoice_Date").groupby("account_key")
            .agg(account_name=("account_name", "last"), parent_name=("parent_name", "last"),
                 Territory_Name=("Territory_Name", "last")))
    t = t.merge(info, left_on="account_key", right_index=True, how="left")
    t["route_to"] = "Trade / operations"
    return t[["Territory_Name", "account_name", "parent_name", "issue", "evidence", "route_to", "account_key"]]


def _main(g: pd.DataFrame, col: str):
    s = g[~g["is_return"]]
    if s.empty or col not in s:
        return None
    v = s.assign(_v=s[col].astype("string").fillna("—")).groupby("_v")[Q].sum().sort_values(ascending=False)
    if v.empty or v.iloc[0] <= 0 or v.iloc[0] / max(v.sum(), 1e-9) < 0.6:
        return None                                  # no clear main value
    return v.index[0]


def region_summary(actions: pd.DataFrame) -> pd.DataFrame:
    if actions.empty:
        return pd.DataFrame(columns=["Region_Name", "action", "actions", "units_at_stake"])
    return (actions.groupby(["Region_Name", "action"]).agg(actions=("action", "size"),
                                                           units_at_stake=("units_at_stake", "sum"))
            .reset_index().sort_values(["Region_Name", "units_at_stake"], ascending=[True, False]))


def top_per_territory(actions: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    if actions.empty:
        return actions
    return actions.sort_values("priority", ascending=False).groupby("Territory_Name", dropna=False).head(n)


# =============================================================================
# Narrative (templated from the numbers)
# =============================================================================
def narrative(product: str, snap: dict, res: pe.EngineResult, actions: pd.DataFrame, landing: dict | None,
              runrate_share: float | None) -> list[str]:
    unit = config.PRODUCT_PROFILES[product]["units"]
    out = []
    k = snap.get("qtd_kpi")
    if k is not None:
        if k.pct is None:
            out.append(f"{product} has {k.current:,.0f} {unit} so far this quarter.")
        else:
            out.append(f"{product} has {k.current:,.0f} {unit} so far this quarter, {abs(k.pct):.0f}% "
                       f"{'above' if k.pct >= 0 else 'below'} the same days of the last three quarters.")
    ap = snap.get("patients")
    if ap:
        out.append(f"That is about {pe.fmt_patients(ap['low'], ap['high'])} patients on treatment in the last 21 days "
                   f"(estimate from shipped volume).")
    p = res.persistence
    starts = snap.get("starts_qtd")
    if starts is not None and snap.get("starts_prev") is not None:
        diff = starts - snap["starts_prev"]
        out.append(f"{starts} new course starts this quarter vs {snap['starts_prev']} in the same days last quarter"
                   + (f" ({diff:+d})." if diff else "."))
    if p.n_courses >= 10 and p.drop_after_1 is not None and not product == "RYZNEUTA":
        out.append(f"{p.drop_after_1:.0%} of courses stop after the first cycle"
                   + (f"; half have ended by cycle {int(p.median_cycles)}." if p.median_cycles else "."))
    if runrate_share is not None and runrate_share > 0.3:
        out.append(f"Multi-patient (run-rate) accounts take {runrate_share:.0%} of units, so watch their weekly "
                   f"volume as closely as individual courses.")
    if landing and landing.get("avg_last3"):
        out.append(f"The quarter is projected to land near {landing['projected']:,.0f} {unit} "
                   f"({landing['lo']:,.0f}–{landing['hi']:,.0f}) vs a {landing['avg_last3']:,.0f} average for the last "
                   f"{landing['n_past']} quarters.")
    chase = actions[actions["action"] != "Course likely completed"] if len(actions) else actions
    if len(chase):
        top = chase.groupby("action")["priority"].sum().sort_values(ascending=False)
        a0 = top.index[0]
        n0 = int((chase["action"] == a0).sum())
        u0 = chase.loc[chase["action"] == a0, "units_at_stake"].sum()
        out.append(f"This week: {n0} “{a0}” action{'s rank' if n0 > 1 else ' ranks'} highest ({u0:,.0f} {unit} at "
                   f"stake); start with the top of each territory's list.")
    return out[:6]
