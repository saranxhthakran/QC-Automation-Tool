"""Acrotech QC Workspace: entry point, navigation, sidebar and theme injection.

Run with:  streamlit run app.py
"""
from __future__ import annotations

import html

import streamlit as st

import config
import local_store as ls
import metrics as M
from ui import components as ui
from ui import state, theme

st.set_page_config(page_title=config.APP_NAME, page_icon=":material/monitoring:", layout="wide",
                   initial_sidebar_state="expanded")

state.keep_widget_state()

PAGES = [
    st.Page("app_pages/1_Connect_and_load.py", title="Connect & load", url_path="connect"),
    st.Page("app_pages/2_Overview.py", title="Overview", url_path="overview", default=True),
    st.Page("app_pages/3_Accounts.py", title="Accounts", url_path="accounts"),
    st.Page("app_pages/5_Product_deep_dive.py", title="Product deep dive", url_path="deep-dive"),
    st.Page("app_pages/4_Report.py", title="Report", url_path="report"),
]
current = st.navigation(PAGES, position="hidden")

with st.sidebar:
    st.markdown(f'<div class="sb-brand"><div class="name">{html.escape(config.APP_NAME)}</div></div>'
                '<div class="sb-label">Product</div>',
                unsafe_allow_html=True)
    product = ui.product_switcher()
    st.markdown('<div class="sb-label">Pages</div>', unsafe_allow_html=True)
    for i, page in enumerate(PAGES):
        with st.container(key="nav-active" if page.url_path == current.url_path else f"nav-{i}"):
            st.page_link(page, label=page.title, width="stretch")

    # Footer pinned to the bottom: connection and data freshness
    with st.container(key="side-footer"):
        if state.connected():
            p = st.session_state["conn_params"]
            l1, dot = f"{p.database} connected", "dot"
        elif state.has_data():
            l1, dot = "Data loaded, not connected", "dot"
        else:
            l1, dot = "Not connected", "dot off"
        if state.has_data():
            ld = M.product_load_date(state.data().sales, product)
            l2 = f"Loaded {ui.fmt_md(ld)}, {ld.year}" if ld else "Data loaded"
        else:
            l2 = "No data loaded"
        l3 = ""
        oldest = ls.oldest(st.session_state.get("ref_store_meta", {}))
        if oldest and ls.is_stale(oldest[1], config.ALIGNMENT_STORE_MAX_AGE_DAYS):
            l3 = (f'<span class="l2 watch">Stored tables {int(ls.age_days(oldest[1]))} days old. '
                  'Update on Connect &amp; load.</span>')
        st.markdown(f'<div class="sb-foot"><span class="{dot}"></span><span class="l1">{html.escape(l1)}</span>'
                    f'<span class="l2">{html.escape(l2)}</span>{l3}</div>', unsafe_allow_html=True)

theme.inject(product)
current.run()
