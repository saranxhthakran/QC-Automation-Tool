"""Period KPIs, geography change tables, account / parent metrics and trend status.

All sales numbers are net units (config.QTY_COLUMN = Factored_QTY summed; returns are negative).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

import numpy as np
import pandas as pd

import config
import fiscal_calendar as fc

Q = config.QTY_COLUMN  # analysis quantity (Factored_QTY), returns negative


# =============================================================================
# Filtering
# =============================================================================
def filter_data(df: pd.DataFrame, product: str | None = None, regions=None, territories=None,
                parents=None, accounts=None, start=None, end=None) -> pd.DataFrame:
    m = pd.Series(True, index=df.index)
    if product:
        m &= df["Product"] == product
    if regions:
        m &= df["Region_Name"].isin(regions)
    if territories:
        m &= df["Territory_Name"].isin(territories)
    if parents:
        m &= df["parent_name"].isin(parents)
    if accounts:
        m &= df["account_key"].isin(accounts)
    if start is not None:
        m &= df["Invoice_Date"] >= pd.Timestamp(start)
    if end is not None:
        m &= df["Invoice_Date"] <= pd.Timestamp(end)
    return df[m]


def product_max_date(df: pd.DataFrame, product: str) -> date | None:
    """Latest invoice for the product, ignoring geography filters."""
    s = df.loc[df["Product"] == product, "Invoice_Date"]
    return None if s.empty else s.max().date()


def product_load_date(df: pd.DataFrame, product: str) -> date | None:
    s = df.loc[df["Product"] == product, "Load_Date"].dropna()
    return None if s.empty else s.max().date()


# =============================================================================
# Period KPIs
# =============================================================================
def daily_units(df: pd.DataFrame) -> pd.Series:
    if df.empty:
        return pd.Series(dtype=float)
    return df.groupby("Invoice_Date")[Q].sum().sort_index()


def window_sum(daily: pd.Series, window) -> float:
    s, e = pd.Timestamp(window[0]), pd.Timestamp(window[1])
    if daily.empty:
        return 0.0
    return float(daily.loc[(daily.index >= s) & (daily.index <= e)].sum())


def pct_change(current: float, average: float) -> float | None:
    if average is None or abs(average) < 1e-9:
        return None
    return 100.0 * (current - average) / abs(average)


@dataclass
class PeriodKPI:
    key: str
    title: str
    date_range: str
    current: float
    average: float
    diff: float
    pct: float | None
    comparison_note: str
    comparison_values: list[float]
    windows: fc.PeriodWindows


def period_kpis(df: pd.DataFrame, max_date, same_weekdays: bool = True) -> list[PeriodKPI]:
    daily = daily_units(df)
    out = []
    for w in fc.all_period_windows(max_date, same_weekdays):
        cur = window_sum(daily, w.current)
        comps = [window_sum(daily, c) for c in w.comparisons]   # zero-sales windows count as 0
        avg = float(np.mean(comps)) if comps else 0.0
        out.append(PeriodKPI(w.key, w.title, fc.fmt_range(w.current), cur, avg, cur - avg,
                             pct_change(cur, avg), w.comparison_note, comps, w))
    return out


def weekly_series(df: pd.DataFrame, max_date, n_weeks: int = 26) -> pd.DataFrame:
    """Net units per Mon–Sun week for the last n_weeks (current week included, zero-filled)."""
    md = fc.to_date(max_date)
    cur = fc.week_start(md)
    weeks = [cur - timedelta(weeks=i) for i in range(n_weeks - 1, -1, -1)]
    if df.empty:
        units = pd.Series(0.0, index=pd.to_datetime(weeks))
    else:
        ws = df["Invoice_Date"] - pd.to_timedelta(df["Invoice_Date"].dt.weekday, unit="D")
        units = df.groupby(ws)[Q].sum().reindex(pd.to_datetime(weeks), fill_value=0.0)
    out = pd.DataFrame({"week_start": pd.to_datetime(weeks), "units": units.values.astype(float)})
    out["is_current"] = out["week_start"] == pd.Timestamp(cur)
    out["partial"] = out["is_current"] & (md.weekday() < 6)
    return out


def geo_change(df: pd.DataFrame, level: str, max_date, period_key: str = "week",
               same_weekdays: bool = True) -> pd.DataFrame:
    """Current period vs comparison average by Region or Territory."""
    name_col = {"Region": "Region_Name", "Territory": "Territory_Name"}[level]
    w = {p.key: p for p in fc.all_period_windows(max_date, same_weekdays)}[period_key]
    if df.empty:
        return pd.DataFrame(columns=["name", "current", "average", "diff", "pct"])
    rows = []
    starts = min(c[0] for c in w.comparisons)
    d = df[(df["Invoice_Date"] >= pd.Timestamp(starts)) & (df["Invoice_Date"] <= pd.Timestamp(w.current[1]))]
    for name, g in d.groupby(name_col):
        daily = daily_units(g)
        cur = window_sum(daily, w.current)
        avg = float(np.mean([window_sum(daily, c) for c in w.comparisons]))
        rows.append({"name": name, "current": cur, "average": avg, "diff": cur - avg, "pct": pct_change(cur, avg)})
    out = pd.DataFrame(rows)
    if out.empty:
        return pd.DataFrame(columns=["name", "current", "average", "diff", "pct"])
    return out.sort_values("pct", na_position="last").reset_index(drop=True)


# =============================================================================
# Account metrics
# =============================================================================
def order_table(df: pd.DataFrame, key: str = "account_key") -> pd.DataFrame:
    """One row per order: distinct key + invoice date + wholesaler invoice ID, sales rows only."""
    s = df[~df["is_return"]]
    if s.empty:
        return pd.DataFrame(columns=[key, "Invoice_Date", "Wholesaler_Invoice_ID", "units", "Shipper_Name"])
    g = (s.assign(_wiid=s["Wholesaler_Invoice_ID"].fillna("?"))
         .groupby([key, "Invoice_Date", "_wiid"], dropna=False)
         .agg(units=(Q, "sum"), Shipper_Name=("Shipper_Name", "first"))
         .reset_index().rename(columns={"_wiid": "Wholesaler_Invoice_ID"}))
    return g[g["units"] > 0]


def rolling_month_buckets(as_of, n: int = 6) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    """n consecutive one-month windows ending at as_of (oldest first), each (start, end] inclusive of end."""
    a = fc.to_date(as_of)
    edges = [fc.add_months(a, -i) for i in range(n, -1, -1)]
    return [(pd.Timestamp(edges[i]) + pd.Timedelta(days=1), pd.Timestamp(edges[i + 1])) for i in range(n)]


def bucket_units(df: pd.DataFrame, key: str, buckets) -> pd.DataFrame:
    """entity × bucket matrix of net units."""
    if df.empty:
        return pd.DataFrame(columns=list(range(len(buckets))))
    lo, hi = buckets[0][0], buckets[-1][1]
    d = df[(df["Invoice_Date"] >= lo) & (df["Invoice_Date"] <= hi)]
    edges = [b[0] for b in buckets] + [buckets[-1][1] + pd.Timedelta(days=1)]
    idx = np.searchsorted(np.array(edges, dtype="datetime64[ns]"), d["Invoice_Date"].values, side="right") - 1
    m = d.assign(_b=idx).pivot_table(index=key, columns="_b", values=Q, aggfunc="sum", fill_value=0.0)
    return m.reindex(columns=range(len(buckets)), fill_value=0.0)


def _slope(values: np.ndarray) -> float:
    if len(values) < 2 or np.allclose(values, values[0]):
        return 0.0
    return float(np.polyfit(np.arange(len(values)), values, 1)[0])


def main_wholesalers(df: pd.DataFrame, key: str) -> pd.Series:
    if df.empty:
        return pd.Series(dtype="string")
    s = df[~df["is_return"]].groupby([key, "Shipper_Name"])[Q].sum().reset_index()
    s["share"] = s[Q] / s.groupby(key)[Q].transform("sum")
    s = s[(s["share"] >= 0.25)].sort_values([key, "share"], ascending=[True, False])
    return s.groupby(key)["Shipper_Name"].agg(lambda x: ", ".join(x.astype(str)))


def weekly_matrix(df: pd.DataFrame, key: str, max_date, n_weeks: int = 26) -> pd.Series:
    """key -> list of weekly net units (last n_weeks) for sparklines."""
    md = fc.to_date(max_date)
    cur = fc.week_start(md)
    weeks = pd.to_datetime([cur - timedelta(weeks=i) for i in range(n_weeks - 1, -1, -1)])
    d = df[df["Invoice_Date"] >= weeks[0]]
    if d.empty:
        return pd.Series(dtype=object)
    ws = d["Invoice_Date"] - pd.to_timedelta(d["Invoice_Date"].dt.weekday, unit="D")
    m = d.assign(_w=ws).pivot_table(index=key, columns="_w", values=Q, aggfunc="sum", fill_value=0.0)
    m = m.reindex(columns=weeks, fill_value=0.0)
    return pd.Series({k: [float(v) for v in row] for k, row in zip(m.index, m.values)})


def classify_status(row, th: dict) -> str:
    if row["days_since_first"] is not None and row["days_since_first"] < th["new_account_days"]:
        return "New"
    if row["is_lapsed"]:
        return "Lapsed"
    if row["cv_6m"] is not None and row["cv_6m"] > th["erratic_cv"] and row["orders_6m"] >= 3:
        return "Erratic"
    pct = row["pct_3v3"]
    if pct is not None and not np.isnan(pct):
        if pct >= th["trend_change_pct"] and row["slope_6m"] > 0:
            return "Growing"
        if pct <= -th["trend_change_pct"] and row["slope_6m"] < 0:
            return "Declining"
    elif row["last3"] == 0 and row["prior3"] == 0:
        return "Stable"
    return "Stable"


def entity_metrics(df: pd.DataFrame, key: str, as_of, window=None, th: dict | None = None,
                   n_spark_weeks: int = 26) -> pd.DataFrame:
    """Metrics per account (key='account_key') or parent (key='parent_key').

    `df` should be the full pulled history for the product and geography; `window`
    (start, end) only controls the windowed columns (net units, orders, returns).
    """
    th = {**config.DEFAULT_THRESHOLDS, **(th or {})}
    as_of_ts = pd.Timestamp(fc.to_date(as_of))
    if df.empty:
        return pd.DataFrame()
    hist = df[df["Invoice_Date"] <= as_of_ts]
    orders = order_table(hist, key)

    g = hist.groupby(key)
    m = pd.DataFrame({
        "first_invoice": g["Invoice_Date"].min(),
        "net_units_history": g[Q].sum(),
    })
    sales_dates = hist[~hist["is_return"]].groupby(key)["Invoice_Date"].max()
    m["last_invoice"] = sales_dates.reindex(m.index)
    m["last_invoice"] = m["last_invoice"].fillna(g["Invoice_Date"].max())

    og = orders.groupby(key)
    m["orders_history"] = og.size().reindex(m.index, fill_value=0)
    m["avg_order_size"] = og["units"].mean().reindex(m.index)
    m["typical_order_size"] = og["units"].median().reindex(m.index)
    od = orders.drop_duplicates([key, "Invoice_Date"]).sort_values([key, "Invoice_Date"])
    od = od.assign(_gap=od.groupby(key)["Invoice_Date"].diff().dt.days)
    m["avg_days_between"] = od.groupby(key)["_gap"].mean().reindex(m.index)
    m["typical_interval"] = od.groupby(key)["_gap"].median().reindex(m.index)

    m["days_since_last"] = (as_of_ts - m["last_invoice"]).dt.days
    m["days_since_first"] = (as_of_ts - m["first_invoice"]).dt.days

    # windowed columns
    if window is not None:
        ws, we = pd.Timestamp(window[0]), pd.Timestamp(window[1])
        wdf = hist[(hist["Invoice_Date"] >= ws) & (hist["Invoice_Date"] <= we)]
        wo = orders[(orders["Invoice_Date"] >= ws) & (orders["Invoice_Date"] <= we)]
    else:
        wdf, wo = hist, orders
    wg = wdf.groupby(key)
    m["net_units"] = wg[Q].sum().reindex(m.index, fill_value=0.0)
    m["orders"] = wo.groupby(key).size().reindex(m.index, fill_value=0)
    m["returns"] = wdf[wdf["is_return"]].groupby(key)[Q].sum().reindex(m.index, fill_value=0.0)
    mw = main_wholesalers(wdf if len(wdf) else hist, key)
    m["main_wholesalers"] = mw.reindex(m.index).fillna(main_wholesalers(hist, key).reindex(m.index)).fillna("—")

    # trend over six rolling months
    buckets = rolling_month_buckets(as_of_ts, 6)
    bm = bucket_units(hist, key, buckets).reindex(m.index, fill_value=0.0)
    vals = bm.values.astype(float)
    m["last3"] = vals[:, 3:].sum(axis=1)
    m["prior3"] = vals[:, :3].sum(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        pct = np.where(m["prior3"] > 0, 100 * (m["last3"] - m["prior3"]) / m["prior3"], np.nan)
    m["pct_3v3"] = pct
    m["delta_3v3"] = m["last3"] - m["prior3"]
    m["slope_6m"] = [_slope(v) for v in vals]
    means = vals.mean(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        m["cv_6m"] = np.where(means > 0, vals.std(axis=1) / means, np.nan)
    six_mo_start = buckets[0][0]
    m["orders_6m"] = orders[orders["Invoice_Date"] >= six_mo_start].groupby(key).size().reindex(m.index, fill_value=0)

    # lapsed vs own cadence
    has_cadence = m["orders_history"] >= 2
    limit = np.where(has_cadence, th["lapsed_interval_multiple"] * m["typical_interval"].fillna(0),
                     th["lapsed_fallback_days"])
    limit = np.maximum(limit, 14)  # never call an account lapsed within two weeks
    m["lapse_limit_days"] = limit
    m["is_lapsed"] = m["days_since_last"] > limit

    m = m.astype({"cv_6m": float, "pct_3v3": float})
    m["status"] = [
        classify_status({**r, "cv_6m": None if np.isnan(r["cv_6m"]) else r["cv_6m"],
                         "pct_3v3": r["pct_3v3"]}, th)
        for r in m[["days_since_first", "is_lapsed", "cv_6m", "orders_6m", "pct_3v3", "slope_6m", "last3",
                    "prior3"]].to_dict("records")
    ]
    spark = weekly_matrix(hist, key, as_of_ts, n_spark_weeks)
    m["spark"] = [spark.get(k, [0.0] * n_spark_weeks) for k in m.index]
    return m.reset_index().rename(columns={"index": key})


def attach_account_info(m: pd.DataFrame, df: pd.DataFrame) -> pd.DataFrame:
    info = (df.sort_values("Invoice_Date")
            .groupby("account_key")
            .agg(account_label=("account_label", "last"), account_name=("account_name", "last"),
                 account_city=("account_city", "last"), account_state=("account_state", "last"),
                 parent_key=("parent_key", "last"), parent_name=("parent_name", "last"),
                 Territory_Name=("Territory_Name", "last"), Region_Name=("Region_Name", "last"),
                 match_method=("match_method", "last")))
    return m.merge(info, left_on="account_key", right_index=True, how="left")


def account_metrics(df: pd.DataFrame, as_of, window=None, th=None) -> pd.DataFrame:
    m = entity_metrics(df, "account_key", as_of, window, th)
    return attach_account_info(m, df) if len(m) else m


def parent_metrics(df: pd.DataFrame, accounts: pd.DataFrame, as_of, window=None, th=None) -> pd.DataFrame:
    """Parent roll-up with active vs lapsed ship-tos and decline concentration."""
    th = {**config.DEFAULT_THRESHOLDS, **(th or {})}
    m = entity_metrics(df, "parent_key", as_of, window, th)
    if m.empty:
        return m
    names = df.groupby("parent_key")["parent_name"].last()
    m["parent_name"] = m["parent_key"].map(names)
    a = accounts
    counts = a.groupby("parent_key").agg(
        shiptos=("account_key", "size"),
        lapsed_shiptos=("status", lambda s: int((s == "Lapsed").sum())),
    )
    m = m.merge(counts, left_on="parent_key", right_index=True, how="left")
    m["active_shiptos"] = m["shiptos"].fillna(0) - m["lapsed_shiptos"].fillna(0)

    def concentration(pk):
        sub = a[(a["parent_key"] == pk)]
        dec = sub[sub["delta_3v3"] < 0]
        total_drop = -dec["delta_3v3"].sum()
        if total_drop <= 0:
            return "No decline"
        top = dec.sort_values("delta_3v3").iloc[0]
        share = -top["delta_3v3"] / total_drop
        if share >= th["concentration_share"] or len(dec) == 1:
            return f"Concentrated in {top['account_name']} ({share:.0%} of the drop)"
        return f"Spread across {len(dec)} ship-tos"

    m["decline_pattern"] = [concentration(pk) for pk in m["parent_key"]]
    return m


def top_movers(m: pd.DataFrame, label_col: str, n: int = 10) -> tuple[pd.DataFrame, pd.DataFrame]:
    if m.empty:
        return m, m
    cols = [label_col, "last3", "prior3", "delta_3v3", "pct_3v3", "status"]
    grow = m[m["delta_3v3"] > 0].sort_values("delta_3v3", ascending=False).head(n)[cols]
    decl = m[m["delta_3v3"] < 0].sort_values("delta_3v3").head(n)[cols]
    return grow.reset_index(drop=True), decl.reset_index(drop=True)


def month_heatmap(df: pd.DataFrame, key: str, label_map: pd.Series, window, top_n: int = 30) -> pd.DataFrame:
    """entity × calendar month net units for the display window (top_n entities by units)."""
    ws, we = pd.Timestamp(window[0]), pd.Timestamp(window[1])
    d = df[(df["Invoice_Date"] >= ws) & (df["Invoice_Date"] <= we)]
    if d.empty:
        return pd.DataFrame()
    month = d["Invoice_Date"].dt.to_period("M")
    p = d.assign(_m=month).pivot_table(index=key, columns="_m", values=Q, aggfunc="sum", fill_value=0.0)
    allm = pd.period_range(ws.to_period("M"), we.to_period("M"), freq="M")
    p = p.reindex(columns=allm, fill_value=0.0)
    p = p.loc[p.sum(axis=1).sort_values(ascending=False).index[:top_n]]
    p.index = [label_map.get(k, k) for k in p.index]
    p.columns = [c.strftime("%b %Y") for c in p.columns]
    return p


def monthly_series(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=["month", "sales", "returns", "net"])
    d = df.assign(_m=df["Invoice_Date"].dt.to_period("M").dt.to_timestamp())
    g = d.groupby(["_m", "is_return"])[Q].sum().unstack(fill_value=0.0)
    out = pd.DataFrame({"month": g.index,
                        "sales": g.get(False, pd.Series(0.0, index=g.index)).values,
                        "returns": g.get(True, pd.Series(0.0, index=g.index)).values})
    full = pd.date_range(out["month"].min(), out["month"].max(), freq="MS")
    out = out.set_index("month").reindex(full, fill_value=0.0).rename_axis("month").reset_index()
    out["net"] = out["sales"] + out["returns"]
    return out


def status_counts(m: pd.DataFrame) -> dict[str, int]:
    vc = m["status"].value_counts() if len(m) else pd.Series(dtype=int)
    return {s: int(vc.get(s, 0)) for s in config.TREND_STATUSES}
