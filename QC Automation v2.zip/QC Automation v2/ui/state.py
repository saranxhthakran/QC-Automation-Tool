"""Session-state helpers. Credentials live only here, in memory, for the browser session."""
from __future__ import annotations

import streamlit as st

import config

# Widget keys on individual pages that should survive page switches.
PERSISTENT_KEYS = [
    "ov_regions", "ov_territories", "same_weekdays", "ov_change_period",
    "ac_regions", "ac_territories", "ac_parents", "ac_accounts", "ac_window", "ac_view", "ac_status",
    "rep_scope", "rep_sections",
    "cl_server", "cl_database", "cl_auth", "cl_username", "cl_driver", "cl_trust", "cl_encrypt",
    "tf_preset", "tf_custom", "load_mode", "ac_search",
    "pdd_regions", "pdd_territories", "pdd_parents", "pdd_accounts", "pdd_window", "pdd_section",
    "pdd_owner", "pdd_act_view",
] + [f"th_{k}" for k in config.DEFAULT_THRESHOLDS]


def keep_widget_state() -> None:
    """Streamlit drops a widget's state when the widget isn't rendered; re-assigning keeps it."""
    for k in PERSISTENT_KEYS:
        if k in st.session_state:
            st.session_state[k] = st.session_state[k]


def has_data() -> bool:
    return st.session_state.get("data") is not None


def data():
    return st.session_state.get("data")


def meta() -> dict:
    return st.session_state.get("data_meta", {})


def version() -> str:
    return st.session_state.get("data_version", "")


def thresholds() -> dict:
    th = dict(config.DEFAULT_THRESHOLDS)
    th.update(st.session_state.get("thresholds", {}))
    return th


def product() -> str:
    p = st.session_state.get("product")
    return p if p in config.ACTIVE_PRODUCTS else config.DEFAULT_PRODUCT


def connected() -> bool:
    return bool(st.session_state.get("connected"))


def connection_label() -> str:
    p = st.session_state.get("conn_params")
    return p.describe() if p else ""
