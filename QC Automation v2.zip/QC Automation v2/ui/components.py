"""UI components (Part B5), styled to match the Claude Design mockups.

HTML is escaped with html.escape and rendered via st.markdown; interactive pieces
wrap native Streamlit widgets inside keyed containers that assets/styles.css styles.
"""
from __future__ import annotations

import html
import io
from datetime import date
from typing import Callable, Iterable

import pandas as pd
import streamlit as st

import config

E = html.escape

ICONS = {
    "up": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 2.5l4.5 5H9.3V13.5H6.7V7.5H3.5z" fill="currentColor"/></svg>',
    "down": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 13.5L3.5 8.5h3.2V2.5h2.6v6h3.2z" fill="currentColor"/></svg>',
    "flat": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 7h10v2H3z" fill="currentColor"/></svg>',
    "check": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6.2 11.6L2.6 8l1.2-1.2 2.4 2.4 6-6L13.4 4.4z" fill="currentColor"/></svg>',
    "x": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.2 3L8 6.8 11.8 3 13 4.2 9.2 8l3.8 3.8-1.2 1.2L8 9.2 4.2 13 3 11.8 6.8 8 3 4.2z" fill="currentColor"/></svg>',
    "watch": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M7 3h2v6.5H7zm0 8h2v2H7z" fill="currentColor"/></svg>',
    "info": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5a6.5 6.5 0 110 13 6.5 6.5 0 010-13zM7.2 7v4.6h1.6V7zm0-2.6v1.6h1.6V4.4z" fill="currentColor"/></svg>',
    "alert": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5a6.5 6.5 0 110 13 6.5 6.5 0 010-13zM7.2 4.4v4.6h1.6V4.4zm0 6v1.6h1.6v-1.6z" fill="currentColor"/></svg>',
    "pause": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 3h3v10H4zm5 0h3v10H9z" fill="currentColor"/></svg>',
    "wave": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1 9l3-5 3 8 3-6 2 3h3v2h-4l-1-1.5-3 6-3-8-1.6 2.7z" fill="currentColor"/></svg>',
    "spark": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1l1.8 5.2L15 8l-5.2 1.8L8 15l-1.8-5.2L1 8l5.2-1.8z" fill="currentColor"/></svg>',
    "chart": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2 13h12v1.5H2zM3 8h2.2v4H3zm3.9-4h2.2v8H6.9zm3.9 2h2.2v6h-2.2z" fill="currentColor"/></svg>',
    "search": '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M7 2a5 5 0 014 8l3 3-1 1-3-3A5 5 0 117 2zm0 1.6a3.4 3.4 0 100 6.8 3.4 3.4 0 000-6.8z" fill="currentColor"/></svg>',
}


def _md(htm: str, container=None) -> None:
    (container or st).markdown(htm, unsafe_allow_html=True)


def init(key: str, default):
    """Seed a widget's state once, so widgets never get both a default and a Session State value."""
    if key not in st.session_state:
        st.session_state[key] = default


# --- Formatting ---------------------------------------------------------------------------
def _d(d) -> date:
    return pd.Timestamp(d).date()


def fmt_wd(d) -> str:
    d = _d(d)
    return f"{d:%a}, {d:%b} {d.day}, {d.year}"


def fmt_wd_short(d) -> str:
    d = _d(d)
    return f"{d:%a}, {d:%b} {d.day}"


def fmt_md(d) -> str:
    d = _d(d)
    return f"{d:%b} {d.day}"


def fmt_units(v: float | None, signed: bool = False) -> str:
    if v is None:
        return "—"
    r = round(float(v))
    s = f"{abs(r):,}"
    if signed:
        return ("+" if r > 0 else "−" if r < 0 else "±") + s
    return ("−" + s) if r < 0 else s


def fmt_pct(p: float | None, signed: bool = True, decimals: int = 0) -> str:
    if p is None or p != p:
        return "—"
    s = f"{abs(p):.{decimals}f}%"
    if not signed:
        return s
    return ("+" if p > 0.05 else "−" if p < -0.05 else "±") + s


# --- Headers ------------------------------------------------------------------------------
def page_header(title: str, subtitle: str = "", container=None) -> None:
    sub = f'<div class="sub">{E(subtitle)}</div>' if subtitle else ""
    _md(f'<div class="page-header"><h1 class="t-page">{E(title)}</h1>{sub}</div>', container)


def freshness_badge(label: str, value: str) -> str:
    return f'<span class="badge"><span class="dot"></span>{E(label)} <b>{E(value)}</b></span>'


def card_head(title: str, sub: str = "", right: str = "", count: int | None = None, container=None) -> None:
    """Card title (18px) with an optional subtitle, count badge and right-hand HTML."""
    cnt = f'<span class="count-badge">{count}</span>' if count is not None else ""
    s = f'<div class="t-sub">{E(sub)}</div>' if sub else ""
    r = f'<div class="right">{right}</div>' if right else ""
    _md(f'<div class="card-head"><div><h3 class="t-card">{E(title)}{cnt}</h3>{s}</div>{r}</div>', container)


def section_title(title: str, sub: str = "", container=None) -> None:
    s = f'<div class="t-sub">{E(sub)}</div>' if sub else ""
    _md(f'<div style="margin:28px 0 10px 0"><h2 class="t-section">{E(title)}</h2>{s}</div>', container)


# --- Product switcher ---------------------------------------------------------------------
def product_switcher() -> str:
    if st.session_state.get("product") not in config.ACTIVE_PRODUCTS:
        st.session_state["product"] = config.DEFAULT_PRODUCT
    with st.container(key="product-switcher"):
        st.segmented_control("Product", config.ACTIVE_PRODUCTS, key="product", required=True,
                             label_visibility="collapsed", width="stretch")
    return st.session_state["product"]


# --- Active filters ------------------------------------------------------------------------
def active_filters(filters: dict[str, str], key_prefix: str) -> None:
    """'Active filters' row of removable pills plus Clear all. filters: {session key: label}."""
    active = [(k, v) for k in filters for v in (st.session_state.get(k) or [])]
    if not active:
        return

    def remove(k, v):
        st.session_state[k] = [x for x in st.session_state.get(k, []) if x != v]

    def clear():
        for k in filters:
            st.session_state[k] = []

    with st.container(key=f"active-{key_prefix}", horizontal=True, gap="small", vertical_alignment="center"):
        st.markdown('<span class="t-label">Active filters</span>', unsafe_allow_html=True)
        for i, (k, v) in enumerate(active):
            st.button(f"{filters[k]} **{v}**", key=f"rm-{key_prefix}-{i}-{k}", on_click=remove, args=(k, v),
                      icon=":material/close:", icon_position="right", type="secondary",
                      help=f"Remove the {filters[k]} filter")
        st.button("Clear all", key=f"clear-{key_prefix}", on_click=clear, type="tertiary")


# --- Pills and badges ----------------------------------------------------------------------
def delta_pill(diff: float | None, pct: float | None,
               neutral_pct: float = config.DEFAULT_THRESHOLDS["neutral_pct"]) -> str:
    if diff is None:
        return '<span class="pill na">No comparison</span>'
    if pct is None:
        cls = "up" if diff > 0 else "down" if diff < 0 else "flat"
        return f'<span class="pill {cls}">{ICONS[cls]}{fmt_units(diff, True)} units, no prior sales</span>'
    cls = "flat" if abs(pct) < neutral_pct else "up" if pct > 0 else "down"
    return (f'<span class="pill {cls}">{ICONS[cls]}{fmt_units(diff, True)} units&nbsp;&nbsp;'
            f'{fmt_pct(pct, decimals=1)}</span>')


STATUS_ICON = {"Growing": "up", "Declining": "down", "Stable": "flat", "Erratic": "wave", "New": "spark", "Lapsed": "pause"}


def status_badge(status: str) -> str:
    s = status if status in STATUS_ICON else "Stable"
    return f'<span class="status {s}">{ICONS[STATUS_ICON[s]]}{E(status)}</span>'


# --- KPI period card ---------------------------------------------------------------------------
def kpi_card_html(title: str, date_range: str, current: float, average: float, diff: float, pct: float | None,
                  cur_label: str, avg_label: str, note: str, enter: bool = False, delay_ms: int = 0,
                  xfade: bool = False) -> str:
    scale = max(abs(current), abs(average), 1e-9)
    w_cur = max(0.0, current) / scale * 100
    w_avg = max(0.0, average) / scale * 100
    cls = "kpi" + (" enter" if enter else "")
    style = f' style="animation-delay:{delay_ms}ms"' if enter else ""
    vx = " xfade" if xfade and not enter else ""
    has_comp = abs(average) > 1e-9 or pct is not None
    avg_txt = f"{average:,.1f}" if abs(average - round(average)) > 0.05 else fmt_units(average)
    return (
        f'<div class="{cls}"{style} role="group" aria-label="{E(title)}">'
        f'<div class="k-title">{E(title)}</div><div class="k-range">{E(date_range)}</div>'
        f'<div class="k-row{vx}"><div class="kpi-value num">{fmt_units(current)}<span class="k-unit">units</span></div>'
        f'{delta_pill(diff if has_comp else None, pct)}</div>'
        f'<div class="k-bar{vx}"><div class="k-bar-head"><span>{E(cur_label)}</span><b class="num">{fmt_units(current)}</b></div>'
        f'<div class="k-track"><div class="bar cur" style="width:{w_cur:.1f}%"></div></div></div>'
        f'<div class="k-bar{vx}"><div class="k-bar-head"><span>{E(avg_label)}</span><span class="num">{avg_txt}</span></div>'
        f'<div class="k-track"><div class="bar avg" style="width:{w_avg:.1f}%"></div></div></div>'
        f'<div class="k-note">{E(note)}</div></div>'
    )


# --- Overview lists --------------------------------------------------------------------------
def change_list_html(gc: pd.DataFrame, max_rows: int = 14) -> str:
    """Region / territory change: name, diverging bar around zero, signed % with arrow."""
    d = gc.dropna(subset=["pct"]).sort_values("pct", ascending=False)
    if d.empty:
        return '<div class="cl-empty">No comparison available for this selection.</div>'
    if len(d) > max_rows:
        half = max_rows // 2
        d = pd.concat([d.head(half), d.tail(max_rows - half)])
    span = max(10.0, float(d["pct"].abs().max()))
    rows = []
    for r in d.itertuples():
        cls = "flat" if abs(r.pct) < 0.5 else "up" if r.pct > 0 else "down"
        w = min(50.0, abs(r.pct) / span * 50)
        arrow = {"up": "↑", "down": "↓", "flat": "→"}[cls]
        bar = f'<span class="{cls}" style="width:{w:.1f}%"></span>' if cls != "flat" else ""
        tip = f"{r.name}: {fmt_units(r.current)} vs average {r.average:,.1f}"
        rows.append(f'<div class="cl-row" title="{E(tip)}"><span class="cl-name">{E(str(r.name))}</span>'
                    f'<span class="cl-bar">{bar}</span><span class="cl-val {cls}">{arrow} {fmt_pct(r.pct, decimals=1)}</span></div>')
    return f'<div class="cl">{"".join(rows)}</div>'


def alert_html(severity: str, entity: str, rest: str, chips: Iterable[str]) -> str:
    icon = {"up": ICONS["up"], "down": ICONS["down"]}.get(severity, ICONS["watch"])
    tags = "".join(f'<span class="tag">{E(c)}</span>' for c in chips if c)
    return (f'<div class="al"><div class="al-ic {E(severity)}">{icon}</div><div><div class="al-text">'
            f'<b>{E(entity)}</b> {E(rest)}</div><div class="al-chips">{tags}</div></div></div>')


def legend_html(items: list[tuple[str, str]]) -> str:
    return '<div class="legend">' + "".join(f'<span><i class="{c}"></i>{E(t)}</span>' for c, t in items) + "</div>"


# --- Status filter chips --------------------------------------------------------------------
STATUS_DOT = {"Growing": ":green[●]", "Stable": ":gray[●]", "Declining": ":red[●]", "Erratic": ":orange[●]",
              "New": ":blue[●]", "Lapsed": ":gray[○]"}


def status_filter(counts: dict[str, int], key: str) -> str:
    """Single-select chips 'All 127', '● Growing 34', … Returns 'All' or a status."""
    total = sum(counts.values())
    opts = ["All"] + list(config.TREND_STATUSES)
    init(key, "All")

    def fmt(s):
        return f":blue[●] All {total:,}" if s == "All" else f"{STATUS_DOT[s]} {s} {counts.get(s, 0):,}"

    sel = st.pills("Trend status", opts, key=key, format_func=fmt, label_visibility="collapsed", required=True)
    return sel or "All"


# --- Notes ----------------------------------------------------------------------------------
def note(text: str, kind: str = "info", container=None, raw_html: bool = False) -> None:
    icon = {"watch": ICONS["alert"], "down": ICONS["alert"], "up": ICONS["check"]}.get(kind, ICONS["info"])
    body = text if raw_html else E(text)
    _md(f'<div class="note {E(kind)}" role="{"alert" if kind in ("watch", "down") else "note"}">{icon}<div>{body}</div></div>',
        container)


def error_state(what_happened: str, how_to_fix: str = "", container=None) -> None:
    note(f"<b>{E(what_happened)}</b>" + (f" {E(how_to_fix)}" if how_to_fix else ""), "down", container, raw_html=True)


# --- Empty / not-loaded states ------------------------------------------------------------------
def state_card(title: str, sub: str = "", actions: list[dict] | None = None, icon: str = "chart", key: str = "state") -> None:
    """Centered state card. actions: [{label, type, on_click|page, args}]."""
    with st.container(key=f"card-{key}"):
        _md(f'<div class="state-ic">{ICONS.get(icon, ICONS["info"])}</div><div class="state-t">{E(title)}</div>'
            + (f'<div class="state-s">{E(sub)}</div>' if sub else ""))
        if actions:
            with st.container(key=f"{key}-actions", horizontal=True, horizontal_alignment="center", gap="small"):
                for i, a in enumerate(actions):
                    if "page" in a:
                        if st.button(a["label"], key=f"{key}-act-{i}", type=a.get("type", "primary")):
                            st.switch_page(a["page"])
                    else:
                        st.button(a["label"], key=f"{key}-act-{i}", type=a.get("type", "secondary"),
                                  on_click=a.get("on_click"), args=a.get("args", ()))


def no_data_state(page_key: str, page_title: str) -> None:
    page_header(page_title)
    st.write("")
    state_card("No data loaded yet.", "Go to Connect & load to pull sales data.",
               [{"label": "Go to Connect & load", "type": "primary", "page": "app_pages/1_Connect_and_load.py"}],
               icon="chart", key=f"state-{page_key}")


# --- Skeletons ------------------------------------------------------------------------------------
def _bar(w, h=10, extra=""):
    return f'<div class="sk" style="width:{w};height:{h}px;{extra}"></div>'


def skeleton_html(kind: str, height: int = 320, rows: int = 8) -> str:
    if kind == "kpi":
        return ('<div class="sk-card" style="min-height:248px" aria-busy="true" aria-label="Loading">'
                + _bar("40%", 12) + _bar("55%", 9)
                + '<div style="display:flex;justify-content:space-between;align-items:center;margin:14px 0 8px 0">'
                + _bar("38%", 36) + _bar("34%", 22, "border-radius:999px") + "</div>"
                + _bar("100%", 6, "border-radius:999px") + _bar("100%", 6, "border-radius:999px;margin-top:10px")
                + '<div style="margin-top:auto">' + _bar("85%", 9) + _bar("60%", 9, "margin-top:6px") + "</div></div>")
    if kind == "chart":
        lines = "".join('<div class="gl"></div>' for _ in range(5))
        return (f'<div class="sk-card" aria-busy="true" aria-label="Loading chart">'
                + _bar("28%", 16) + _bar("20%", 9)
                + f'<div class="sk-area" style="height:{height}px;display:flex;flex-direction:column;justify-content:space-between;padding:8px 0">'
                + lines + f'<div class="sk" style="position:absolute;left:0;right:0;bottom:8px;height:42%;opacity:.8"></div></div></div>')
    if kind == "alerts":
        items = "".join(
            '<div style="display:grid;grid-template-columns:28px 1fr;gap:10px;padding:12px 0;border-bottom:1px solid var(--border)">'
            + _bar("26px", 26, "border-radius:999px") + "<div>" + _bar(f"{w}%", 10)
            + '<div style="display:flex;gap:6px;margin-top:8px">' + _bar("60px", 16) + _bar("80px", 16) + "</div></div></div>"
            for w in (80, 92, 70, 85, 64))
        return f'<div class="sk-card" aria-busy="true" aria-label="Loading alerts">{_bar("22%", 16)}{items}</div>'
    if kind == "change":
        items = "".join(
            '<div style="display:grid;grid-template-columns:1fr 60px 50px;gap:10px;padding:8px 0">'
            + _bar(f"{w}%", 9) + _bar("100%", 8) + _bar("100%", 9) + "</div>" for w in (70, 55, 80, 62, 75, 50, 66))
        return (f'<div class="sk-card" style="min-height:{height}px" aria-busy="true" aria-label="Loading">'
                + _bar("60%", 16) + _bar("80%", 9) + items + "</div>")
    if kind == "table":
        widths = [70, 55, 80, 45, 62, 50, 75, 58, 66, 52, 71, 60]
        body = "".join('<div class="sk-row">' + "".join(
            _bar(f"{(w + j * 7) % 55 + 40}%", 10) for j in range(9)) + "</div>" for w in widths[:rows])
        head = '<div class="sk-row">' + "".join(_bar("60%", 10) for _ in range(9)) + "</div>"
        return (f'<div class="sk-card" aria-busy="true" aria-label="Loading table">'
                f'<div style="display:flex;justify-content:space-between">{_bar("18%", 16)}{_bar("26%", 30)}</div>'
                f'{head}{body}</div>')
    if kind == "chips":
        return ('<div style="display:flex;gap:8px;margin:4px 0" aria-busy="true">'
                + "".join(_bar(f"{w}px", 30, "border-radius:999px") for w in (72, 96, 84, 104, 80, 64, 84)) + "</div>")
    raise ValueError(kind)


def skeleton(kind: str, container=None, height: int = 320, rows: int = 8) -> None:
    _md(skeleton_html(kind, height, rows), container)


# --- Stepper, done cards and progress ------------------------------------------------------------
def stepper_html(steps: list[tuple[str, str, str]]) -> str:
    """steps: (title, subtitle, state in done|current|todo)."""
    parts = []
    for i, (t, s, state) in enumerate(steps):
        c = ICONS["check"] if state == "done" else str(i + 1)
        parts.append(f'<div class="stp {state}"><div class="c">{c}</div><div><div class="t1">{E(t)}</div>'
                     f'<div class="t2">{E(s)}</div></div></div>')
        if i < len(steps) - 1:
            parts.append(f'<div class="stp-line {"done" if state == "done" else ""}"></div>')
    return f'<nav class="stepper" aria-label="Progress">{"".join(parts)}</nav>'


def done_card(key: str, title: str, sub: str, on_edit: Callable) -> None:
    with st.container(key=f"card-done-{key}"):
        c1, c2 = st.columns([12, 1], vertical_alignment="center")
        c1.markdown(f'<div class="done-row"><div class="done-ic">{ICONS["check"]}</div><div><div class="t1">{E(title)}</div>'
                    f'<div class="t2">{E(sub)}</div></div></div>', unsafe_allow_html=True)
        c2.button("Edit", key=f"edit-{key}", type="tertiary", on_click=on_edit)


class ProgressCard:
    """Live step list in a card with a step-based progress bar. Progress never invents percentages."""

    def __init__(self, title: str, labels: list[str], container=None, meta: str = ""):
        self.title, self.meta = title, meta
        self.steps = [{"label": l, "state": "pending", "meta": "", "tm": ""} for l in labels]
        self.ph = (container or st).empty()
        self.render()

    def _html(self) -> str:
        done = sum(s["state"] == "done" for s in self.steps)
        pct = 100 * done / max(1, len(self.steps))
        rows = []
        for s in self.steps:
            ic = {"running": '<span class="spin" aria-label="Running"></span>', "done": ICONS["check"],
                  "error": ICONS["x"]}.get(s["state"], "")
            err = f'<div class="err">{E(s["error"])}</div>' if s.get("error") else ""
            rows.append(f'<div class="srow {s["state"]}"><span class="ic">{ic}</span><span>{E(s["label"])}</span>'
                        f'<span class="meta num">{E(s["meta"])}</span><span class="tm num">{E(s["tm"])}</span>{err}</div>')
        return (f'<div class="prog" aria-live="polite"><div class="ph"><span class="t">{E(self.title)}</span>'
                f'<span class="m">{E(self.meta or f"Step {min(done + 1, len(self.steps))} of {len(self.steps)}")}</span></div>'
                f'<div class="pbar"><span style="width:{pct:.0f}%"></span></div>{"".join(rows)}</div>')

    def render(self):
        self.ph.markdown(self._html(), unsafe_allow_html=True)

    def start(self, i: int):
        self.steps[i]["state"] = "running"
        self.render()

    def done(self, i: int, meta: str = "", seconds: float | None = None):
        self.steps[i].update(state="done", meta=meta, tm=f"{seconds:.1f}s" if seconds is not None else "")
        self.render()

    def fail(self, i: int, error: str):
        self.steps[i].update(state="error", error=error)
        self.render()

    def running_index(self) -> int | None:
        for i, s in enumerate(self.steps):
            if s["state"] == "running":
                return i
        return None

    def clear(self):
        self.ph.empty()


# --- Accounts lists ---------------------------------------------------------------------------
def top_list_html(df: pd.DataFrame, name_col: str, sub_col: str | None, kind: str) -> str:
    if df.empty:
        return '<div class="cl-empty">None in this selection.</div>'
    rows = []
    for i, r in enumerate(df.itertuples(index=False), start=1):
        d = getattr(r, "delta_3v3")
        p = getattr(r, "pct_3v3")
        name = str(getattr(r, name_col))
        sub = str(getattr(r, sub_col)) if sub_col else ""
        if p is None or p != p:
            pill = '<span class="pill up">New volume</span>' if kind == "up" else '<span class="pill na">—</span>'
        else:
            pill = f'<span class="pill {kind}">{ICONS[kind]}{fmt_pct(p, decimals=1)}</span>'
        rows.append(f'<div class="tl-row"><span class="tl-rank">{i}</span><span class="tl-name" title="{E(name)}">{E(name)}</span>'
                    f'<span class="tl-sub">{E(sub)}</span><span class="tl-val {kind}">{fmt_units(d, True)}</span>{pill}</div>')
    return f'<div class="tl">{"".join(rows)}</div>'


def _mix(c1: str, c2: str, t: float) -> str:
    a = [int(c1.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    b = [int(c2.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    m = [round(x + (y - x) * t) for x, y in zip(a, b)]
    return "#" + "".join(f"{v:02X}" for v in m)


def heatmap_html(h: pd.DataFrame, theme) -> str:
    """Accounts × months table, cells shaded from surface-sunken to the accent."""
    if h.empty:
        return '<div class="cl-empty">No sales in these months.</div>'
    vmax = max(1.0, float(h.values.max()))
    head = '<tr><th class="rowh"></th>' + "".join(f"<th>{E(c)}</th>" for c in h.columns) + "</tr>"
    body = []
    for name, row in h.iterrows():
        cells = []
        for v in row.values:
            t = max(0.0, float(v)) / vmax
            bg = _mix(theme["surface-sunken"], theme["accent"], 0.12 + 0.88 * t) if v > 0 else theme["surface-sunken"]
            fg = theme["on-accent"] if t > 0.55 else theme["ink"]
            txt = fmt_units(v) if abs(v) >= 0.5 else ""
            cells.append(f'<td style="background:{bg};color:{fg}" title="{E(str(name))}: {fmt_units(v)} units">{txt}</td>')
        body.append(f'<tr><td class="name" title="{E(str(name))}">{E(str(name))}</td>{"".join(cells)}</tr>')
    return f'<div class="hm-wrap"><table class="hm">{head}{"".join(body)}</table></div>'


def heatmap_legend_html(vmax: float, theme) -> str:
    return (f'<div class="hm-legend"><span>0</span><span class="g" style="background:linear-gradient(90deg,'
            f'{theme["surface-sunken"]},{theme["accent"]})"></span><span>{fmt_units(vmax)} units</span></div>')


# --- Downloads ---------------------------------------------------------------------------------
def csv_bytes(df) -> bytes:
    return df.to_csv(index=False).encode("utf-8-sig")


def excel_bytes(sheets: dict) -> bytes:
    """sheets: {name: DataFrame}. Excel caps sheets at 1,048,575 data rows."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        for name, df in sheets.items():
            out = df.copy()
            for c in out.columns:
                if isinstance(out[c].dtype, pd.DatetimeTZDtype):
                    out[c] = out[c].dt.tz_localize(None)
                if out[c].dtype == object and len(out) and isinstance(out[c].iloc[0], list):
                    out[c] = out[c].astype(str)
            out.head(1_048_575).to_excel(xw, sheet_name=name[:31], index=False)
    return buf.getvalue()


def download_csv(label: str, df, file_name: str, key: str, container=None) -> None:
    (container or st).download_button(label, data=lambda: csv_bytes(df), file_name=file_name, mime="text/csv",
                                      key=key, icon=":material/download:", on_click="ignore")


def download_xlsx(label: str, df, file_name: str, key: str, sheet: str = "data", container=None) -> None:
    (container or st).download_button(label, data=lambda: excel_bytes({sheet: df}), file_name=file_name, key=key,
                                      mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                      icon=":material/download:", on_click="ignore")


# --- Threshold settings -----------------------------------------------------------------------
THRESHOLD_FIELDS = {
    "sd_multiplier": ("Spike / drop: standard deviations", 0.5, 5.0, 0.5),
    "min_change_pct": ("Spike / drop: minimum change (%)", 0.0, 200.0, 5.0),
    "spike_order_ratio": ("Spike: order vs typical order (×)", 1.0, 10.0, 0.5),
    "consecutive_declines": ("Drop: consecutive declining months", 2, 6, 1),
    "lapsed_interval_multiple": ("Lapsed: × usual order interval", 1.0, 6.0, 0.5),
    "large_return_ratio": ("Suspicious: return vs typical order (×)", 1.0, 10.0, 0.5),
    "large_order_ratio": ("Suspicious: order vs typical order (×)", 2.0, 20.0, 0.5),
    "trend_change_pct": ("Growing / declining: last 3 vs prior 3 (%)", 5.0, 100.0, 5.0),
    "erratic_cv": ("Erratic: monthly variation (CV)", 0.3, 3.0, 0.1),
    "alert_pct": ("Overview alerts: change vs average (%)", 5.0, 100.0, 5.0),
}


def threshold_popover() -> None:
    """Settings panel for anomaly and trend thresholds (shared by Overview and Accounts)."""
    cur = {**config.DEFAULT_THRESHOLDS, **st.session_state.get("thresholds", {})}
    with st.popover("Alert thresholds", icon=":material/tune:"):
        st.markdown('<div class="t-sub" style="margin-bottom:6px">Every flag states which rule raised it.</div>',
                    unsafe_allow_html=True)
        new = {}
        for k, (lbl, lo, hi, step) in THRESHOLD_FIELDS.items():
            init(f"th_{k}", type(step)(cur[k]))
            if isinstance(step, int):
                new[k] = st.number_input(lbl, min_value=int(lo), max_value=int(hi), step=step, key=f"th_{k}")
            else:
                new[k] = st.number_input(lbl, min_value=float(lo), max_value=float(hi), step=float(step), key=f"th_{k}")
        st.session_state["thresholds"] = {**cur, **new}

        def reset():
            for k in THRESHOLD_FIELDS:
                st.session_state[f"th_{k}"] = type(THRESHOLD_FIELDS[k][3])(config.DEFAULT_THRESHOLDS[k])
            st.session_state["thresholds"] = dict(config.DEFAULT_THRESHOLDS)

        st.button("Reset to defaults", type="tertiary", key="th_reset", on_click=reset)
