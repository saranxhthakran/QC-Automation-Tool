"""Page-level computations: pure builders (also used by the PDF) and cached wrappers."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

import pandas as pd
import streamlit as st

import anomalies as A
import config
import fiscal_calendar as fc
import metrics as M


@dataclass
class OverviewBundle:
    product: str
    max_date: date | None
    load_date: date | None
    kpis: list = field(default_factory=list)
    weekly: pd.DataFrame = field(default_factory=pd.DataFrame)
    weekly_anomalies: pd.DataFrame = field(default_factory=pd.DataFrame)
    region_change: dict = field(default_factory=dict)      # period -> DataFrame
    territory_change: dict = field(default_factory=dict)
    alerts: list = field(default_factory=list)
    rows: int = 0


def build_overview(df: pd.DataFrame, product: str, regions=(), territories=(), same_weekdays=True,
                   th: dict | None = None) -> OverviewBundle:
    th = {**config.DEFAULT_THRESHOLDS, **(th or {})}
    md = M.product_max_date(df, product)          # anchor ignores geography
    ld = M.product_load_date(df, product)
    b = OverviewBundle(product, md, ld)
    if md is None:
        return b
    d = M.filter_data(df, product, list(regions), list(territories))
    b.rows = len(d)
    b.kpis = M.period_kpis(d, md, same_weekdays)
    b.weekly = M.weekly_series(d, md, 26)
    b.weekly_anomalies = A.series_anomalies(b.weekly, n_roll=int(th["rolling_periods"]), k=th["sd_multiplier"],
                                            consecutive=int(th["consecutive_declines"]))
    for pk in ("week", "month", "quarter"):
        b.region_change[pk] = M.geo_change(d, "Region", md, pk, same_weekdays)
        b.territory_change[pk] = M.geo_change(d, "Territory", md, pk, same_weekdays)
    b.alerts = A.overview_alerts(d, product, md, same_weekdays, th)
    return b


@dataclass
class AccountsBundle:
    product: str
    max_date: date | None
    window: tuple
    accounts: pd.DataFrame = field(default_factory=pd.DataFrame)
    parents: pd.DataFrame = field(default_factory=pd.DataFrame)
    flags: pd.DataFrame = field(default_factory=pd.DataFrame)
    rows: int = 0


def build_accounts(df: pd.DataFrame, product: str, regions=(), territories=(), parents=(), accounts=(),
                   window=None, th: dict | None = None) -> AccountsBundle:
    th = {**config.DEFAULT_THRESHOLDS, **(th or {})}
    md = M.product_max_date(df, product)
    if md is None:
        return AccountsBundle(product, None, window or (None, None))
    window = window or (fc.quarter_start(md), md)
    # Full pulled history for the selection; the window only controls displayed columns.
    d = M.filter_data(df, product, list(regions), list(territories), list(parents), list(accounts))
    b = AccountsBundle(product, md, window, rows=len(d))
    if d.empty:
        return b
    am = M.account_metrics(d, md, window, th)
    fl = A.account_flags(d, am, md, window, th)
    summ = A.flags_summary(fl)
    am["flags"] = am["account_key"].map(summ).fillna("")
    am["n_flags"] = am["account_key"].map(fl.groupby("account_key").size()).fillna(0).astype(int)
    pm = M.parent_metrics(d, am, md, window, th)
    if len(pm):
        pflags = am.groupby("parent_key")["n_flags"].sum()
        pm["n_flags"] = pm["parent_key"].map(pflags).fillna(0).astype(int)
    b.accounts, b.parents, b.flags = am, pm, fl
    return b


def _th_key(th: dict | None) -> tuple:
    return tuple(sorted((th or {}).items()))


@st.cache_data(show_spinner=False, max_entries=48)
def overview_cached(version: str, product: str, regions: tuple, territories: tuple,
                    same_weekdays: bool, th_items: tuple, _df: pd.DataFrame) -> OverviewBundle:
    return build_overview(_df, product, regions, territories, same_weekdays, dict(th_items))


@st.cache_data(show_spinner=False, max_entries=48)
def accounts_cached(version: str, product: str, regions: tuple, territories: tuple, parents: tuple,
                    accounts: tuple, window: tuple, th_items: tuple, _df: pd.DataFrame) -> AccountsBundle:
    return build_accounts(_df, product, regions, territories, parents, accounts, window, dict(th_items))


def first_time(key: tuple) -> bool:
    """True the first time this exact computation is requested in this session (cache miss → show skeletons)."""
    seen = st.session_state.setdefault("_computed_keys", set())
    if key in seen:
        return False
    seen.add(key)
    return True


# --- Query cache -------------------------------------------------------------------
@st.cache_data(show_spinner=False, max_entries=32, ttl=8 * 3600)
def cached_query(fingerprint: str, sql: str, params: tuple, _engine) -> pd.DataFrame:
    """Cached on connection fingerprint (server/database/user, never the password) + SQL + parameters."""
    import db

    return db.run_query(_engine, sql, list(params))


def fingerprint() -> str:
    p = st.session_state.get("conn_params")
    if not p:
        return ""
    return f"{p.server}|{p.database}|{p.auth}|{p.username}"
