"""Design tokens, product tinting, CSS injection and the shared Plotly template.

Tokens mirror assets/styles.css. The CSS file references tokens only through
custom properties; this module writes the :root values for the active mode and
product on every run, so switching product retints the whole app.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import plotly.graph_objects as go

ROOT = Path(__file__).resolve().parent.parent

TOKENS: dict[str, dict[str, str]] = {
    "light": {
        "bg": "#F4F6FA", "surface": "#FFFFFF", "surface-sunken": "#EEF1F6", "border": "#E1E6EE",
        "ink": "#15233B", "ink-muted": "#5B6880", "ink-faint": "#8C97AA",
        "beleodaq": "#2C5BD8", "beleodaq-tint": "#E8EEFC", "ryzneuta": "#0E8C7F", "ryzneuta-tint": "#E3F4F1",
        "up": "#1E9E6A", "up-tint": "#E4F5EC", "down": "#D2443F", "down-tint": "#FBE9E8",
        "watch": "#C98A16", "watch-tint": "#FBF1DC",
    },
    "dark": {
        "bg": "#0F1626", "surface": "#172036", "surface-sunken": "#121A2C", "border": "#263150",
        "ink": "#E8EDF6", "ink-muted": "#A3AEC4", "ink-faint": "#6F7B93",
        "beleodaq": "#6E92F2", "beleodaq-tint": "#1D2C55", "ryzneuta": "#3CC1B1", "ryzneuta-tint": "#143A3A",
        "up": "#3CC48C", "up-tint": "#163B2D", "down": "#F06A64", "down-tint": "#47201F",
        "watch": "#E7B04A", "watch-tint": "#3F3115",
    },
}

# Text-on-tint variants. In light mode the status colors are too light for 13px text on
# their tints (e.g. watch on watch-tint is 2.6:1), so text uses these darker inks (≥4.7:1).
# Fills, bars and icons keep the base tokens.
INKS = {
    "light": {"up-ink": "#157A52", "down-ink": "#B5372F", "watch-ink": "#8A5B05",
              "beleodaq-ink": "#2C5BD8", "ryzneuta-ink": "#0A6F65", "on-accent": "#FFFFFF"},
    "dark": {"up-ink": "#3CC48C", "down-ink": "#F06A64", "watch-ink": "#E7B04A",
             "beleodaq-ink": "#6E92F2", "ryzneuta-ink": "#3CC1B1", "on-accent": "#0F1626"},
}

# Categorical series (fixed order, never cycled; validated for colour-vision deficiency on adjacent pairs).
# Used for mixes (buying style, dose level, contract, wholesaler). Status colours stay reserved for status.
CATEGORICAL = {
    "light": ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"],
    "dark": ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"],
}

FONT_FAMILY = 'IBM Plex Sans, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
FONT_STACK_PLOTLY = "IBM Plex Sans, Segoe UI, Roboto, Arial, sans-serif"


def current_mode() -> str:
    try:
        import streamlit as st

        t = getattr(st.context, "theme", None)
        typ = getattr(t, "type", None) if t is not None else None
        return "dark" if typ == "dark" else "light"
    except Exception:
        return "light"


def tokens(mode: str | None = None) -> dict[str, str]:
    return TOKENS[mode or current_mode()]


def accent(product: str, mode: str | None = None) -> tuple[str, str]:
    t = tokens(mode)
    key = (product or "BELEODAQ").lower()
    key = key if key in t else "beleodaq"
    return t[key], t[f"{key}-tint"]


class Theme(dict):
    """Token dict plus resolved accent for one product and mode."""

    @classmethod
    def for_product(cls, product: str, mode: str | None = None) -> "Theme":
        mode = mode or current_mode()
        th = cls(TOKENS[mode])
        th["accent"], th["accent-tint"] = accent(product, mode)
        th["mode"] = mode
        th["product"] = product
        key = "ryzneuta" if (product or "").upper() == "RYZNEUTA" else "beleodaq"
        th.update(INKS[mode])
        th["accent-ink"] = INKS[mode][f"{key}-ink"]
        th["cat"] = CATEGORICAL[mode]
        return th


@lru_cache(maxsize=1)
def _css() -> str:
    return (ROOT / "assets" / "styles.css").read_text(encoding="utf-8")


def root_vars(product: str, mode: str | None = None) -> str:
    th = Theme.for_product(product, mode)
    pairs = [f"--{k}:{v}" for k, v in TOKENS[th["mode"]].items()]
    pairs += [f"--{k}:{v}" for k, v in INKS[th["mode"]].items()]
    pairs += [f"--accent:{th['accent']}", f"--accent-tint:{th['accent-tint']}", f"--accent-ink:{th['accent-ink']}"]
    return ":root{" + ";".join(pairs) + "}"


def inject(product: str) -> None:
    """Inject fonts, the stylesheet and the product tint. Call once at the top of every run."""
    import streamlit as st

    # The bundled copies in static/ (declared in .streamlit/config.toml) cover networks that block Google Fonts.
    st.markdown(
        "<style>@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&display=swap');\n"
        f"{root_vars(product)}\n{_css()}</style>",
        unsafe_allow_html=True,
    )


# --- Plotly ------------------------------------------------------------------------
def plotly_template(product: str, mode: str | None = None) -> go.layout.Template:
    th = Theme.for_product(product, mode)
    axis = dict(
        showgrid=False, zeroline=False, showline=False, ticks="",
        tickfont=dict(size=12, color=th["ink-muted"], family=FONT_STACK_PLOTLY),
        title=dict(font=dict(size=12, color=th["ink-muted"])),
        automargin=True,
    )
    return go.layout.Template(
        layout=go.Layout(
            font=dict(family=FONT_STACK_PLOTLY, size=12, color=th["ink"]),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            colorway=[th["accent"], th["ink-faint"], th["up"], th["down"], th["watch"]],
            xaxis=axis,
            yaxis={**axis, "showgrid": True, "gridcolor": th["border"], "gridwidth": 1},
            margin=dict(l=8, r=8, t=8, b=8),
            hoverlabel=dict(bgcolor=th["surface"], bordercolor=th["border"],
                            font=dict(family=FONT_STACK_PLOTLY, size=12, color=th["ink"])),
            legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="left", x=0,
                        font=dict(size=12, color=th["ink-muted"]), bgcolor="rgba(0,0,0,0)"),
            bargap=0.28,
            hovermode="closest",
        )
    )


PLOTLY_CONFIG = {
    "displaylogo": False,
    "modeBarButtons": [["toImage"]],
    "toImageButtonOptions": {"format": "png", "scale": 2},
    "responsive": True,
}
