"""Local copies of slow-changing reference tables: zip-to-territory, customer master, roster and users.

A table is pulled once, saved next to the app as Parquet with a small JSON metadata
file, and reused until the user asks for an update. After `max_age_days` the app
prompts for an update but keeps using the stored copy until the user clicks it.

An update writes the new copy to temporary files, reads it back and validates it,
then moves the current copy to `<name>.prev.*` and swaps the new one in. If any step
fails, the current copy is left untouched.

Pure file I/O: no Streamlit, so it is unit-tested directly.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

import pandas as pd

import config

ROOT = Path(__file__).resolve().parent


@dataclass
class StoredTable:
    df: pd.DataFrame
    meta: dict

    @property
    def pulled_at(self) -> datetime:
        return datetime.fromisoformat(self.meta["pulled_at"])

    def age_days(self, now: datetime | None = None) -> float:
        return age_days(self.meta, now)

    def is_stale(self, max_age_days: float, now: datetime | None = None) -> bool:
        return is_stale(self.meta, max_age_days, now)


class StoreError(Exception):
    """A new copy failed validation or couldn't be written; the old copy is unchanged."""


# --- Paths and identity ---------------------------------------------------------------------
def store_dir(base: Path | str | None = None) -> Path:
    return Path(base) if base is not None else ROOT / config.LOCAL_STORE_DIR


def _paths(name: str, base=None) -> dict[str, Path]:
    d = store_dir(base)
    return {
        "data": d / f"{name}.parquet", "meta": d / f"{name}.json",
        "prev_data": d / f"{name}.prev.parquet", "prev_meta": d / f"{name}.prev.json",
        "tmp_data": d / f"{name}.tmp.parquet", "tmp_meta": d / f"{name}.tmp.json",
    }


def source_id(server: str, database: str) -> str:
    """Which server/database a copy came from. A copy from another source is never used."""
    return f"{(server or '').strip().lower()}|{(database or '').strip().lower()}"


# --- Age ---------------------------------------------------------------------------------------
def age_days(meta: dict, now: datetime | None = None) -> float:
    pulled = datetime.fromisoformat(meta["pulled_at"])
    return ((now or datetime.now()) - pulled).total_seconds() / 86400.0


def is_stale(meta: dict, max_age_days: float, now: datetime | None = None) -> bool:
    return age_days(meta, now) >= max_age_days


# --- Read ------------------------------------------------------------------------------------
def read_meta(name: str, base=None) -> dict | None:
    p = _paths(name, base)["meta"]
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def load(name: str, source: str | None = None, base=None) -> StoredTable | None:
    """The stored copy, or None if there is none, it can't be read, or it came from another source."""
    p = _paths(name, base)
    meta = read_meta(name, base)
    if meta is None or not p["data"].exists():
        return None
    if source is not None and meta.get("source") != source:
        return None
    try:
        df = pd.read_parquet(p["data"])
    except Exception:  # noqa: BLE001 - a damaged file behaves like no file
        return None
    return StoredTable(df, meta)


# --- Write -----------------------------------------------------------------------------------
def _as_text(df: pd.DataFrame) -> pd.DataFrame:
    """Store every column as nullable text, so mixed ODBC types round-trip through Parquet."""
    out = df.copy()
    for c in out.columns:
        s = out[c]
        if pd.api.types.is_float_dtype(s):
            # 1500.0 -> "1500" so FileIDs and zips don't gain a decimal
            s = s.map(lambda v: None if pd.isna(v) else (str(int(v)) if float(v).is_integer() else str(v)))
        out[c] = s.astype("string")
    return out


def save(name: str, df: pd.DataFrame, source: str, extra_meta: dict | None = None,
         validate: Callable[[pd.DataFrame], list[str]] | None = None, base=None,
         now: datetime | None = None) -> StoredTable:
    """Validate, write to temp files, read back, keep the current copy as .prev, then swap in.

    Raises StoreError (and leaves the current copy untouched) if validation or the write fails.
    """
    errors = validate(df) if validate else []
    if errors:
        raise StoreError(" ".join(errors))
    p = _paths(name, base)
    p["data"].parent.mkdir(parents=True, exist_ok=True)
    data = _as_text(df)
    meta = {
        "table": name, "source": source, "pulled_at": (now or datetime.now()).isoformat(timespec="seconds"),
        "rows": int(len(data)), "columns": list(map(str, data.columns)), **(extra_meta or {}),
    }
    try:
        data.to_parquet(p["tmp_data"], index=False)
        back = pd.read_parquet(p["tmp_data"])
        if len(back) != len(data) or list(back.columns) != list(data.columns):
            raise StoreError("The new copy didn't read back correctly.")
        p["tmp_meta"].write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
        if p["data"].exists():
            os.replace(p["data"], p["prev_data"])
            if p["meta"].exists():
                os.replace(p["meta"], p["prev_meta"])
        os.replace(p["tmp_data"], p["data"])
        os.replace(p["tmp_meta"], p["meta"])
    except StoreError:
        _cleanup(p)
        raise
    except Exception as exc:  # noqa: BLE001
        _cleanup(p)
        # Put the previous copy back if it was already moved aside.
        if not p["data"].exists() and p["prev_data"].exists():
            os.replace(p["prev_data"], p["data"])
            if p["prev_meta"].exists():
                os.replace(p["prev_meta"], p["meta"])
        raise StoreError(f"Couldn't save the new copy: {exc}") from exc
    return StoredTable(back, meta)


def _cleanup(p: dict[str, Path]) -> None:
    for k in ("tmp_data", "tmp_meta"):
        try:
            p[k].unlink(missing_ok=True)
        except OSError:
            pass


# --- Reference tables kept locally ------------------------------------------------------------
@dataclass(frozen=True)
class RefTable:
    """A reference table that is pulled in full, stored locally and updated on request."""
    name: str                 # file name stem in data_cache/
    label: str                # shown in the UI
    table: str                # SQL table name
    required: bool            # False: the app works without it (with a notice)
    required_columns: tuple


ALIGNMENT = "ziptoterr"
CUSTOMER_MASTER = "customer_master"
ROSTER = "roster"
USER = "user"

REFERENCE_TABLES: dict[str, RefTable] = {
    ALIGNMENT: RefTable(ALIGNMENT, "Zip-to-territory", config.TABLE_ALIGNMENT, True, tuple(config.REQUIRED_ALIGNMENT)),
    CUSTOMER_MASTER: RefTable(CUSTOMER_MASTER, "Customer master", config.TABLE_CUSTOMER_MASTER, True,
                              tuple(c for c in config.REQUIRED_CUSTOMER_MASTER
                                    if c not in config.OPTIONAL_CUSTOMER_MASTER)),
    ROSTER: RefTable(ROSTER, "Roster", config.TABLE_ROSTER, False, tuple(config.COLUMNS_ROSTER)),
    USER: RefTable(USER, "Users", config.TABLE_USER, False, tuple(config.COLUMNS_USER)),
}


def reference_query(name: str, database: str) -> tuple[str, list]:
    if name == ALIGNMENT:
        return config.alignment_query(database), [config.TEAM]
    if name == CUSTOMER_MASTER:
        return config.customer_master_query(database), []
    if name == ROSTER:
        return config.roster_query(database), []
    if name == USER:
        return config.user_query(database), []
    raise KeyError(name)


def validate(name: str, df: pd.DataFrame, team: str = config.TEAM) -> list[str]:
    """Reasons a freshly pulled copy must not replace the stored one."""
    rt = REFERENCE_TABLES[name]
    if df is None or df.empty:
        return [f"{rt.label}: the pull returned no rows."]
    missing = [c for c in rt.required_columns if c not in df.columns]
    if missing:
        return [f"{rt.label}: these columns are missing: {', '.join(missing)}."]
    if name == CUSTOMER_MASTER:
        ids = df["SFCD_ID"].astype("string").str.strip()
        if ids.isna().all() or ids.eq("").all():
            return [f"{rt.label}: every SFCD_ID is empty."]
        return []
    teams = df["Team"].astype("string").str.strip().str.upper()
    if not teams.eq(team.upper()).any():
        return [f"{rt.label}: team {team} isn't in the pull."]
    key = "ZIPCode" if name == ALIGNMENT else "Territory_ID"
    vals = df[key].astype("string").str.strip()
    if vals.isna().all() or vals.eq("").all():
        return [f"{rt.label}: every {key} is empty."]
    return []


def validate_alignment(df: pd.DataFrame, team: str = config.TEAM) -> list[str]:
    return validate(ALIGNMENT, df, team)


def table_meta(name: str, df: pd.DataFrame, team: str = config.TEAM) -> dict:
    df = _as_text(df)      # same text form as the stored copy (FileID 1500.0 -> "1500")
    if name == ALIGNMENT:
        return alignment_meta(df, team)
    if name == CUSTOMER_MASTER:
        return {"accounts": int(df["SFCD_ID"].nunique()), "parents": int(df["Parent_SFCD"].nunique())}
    t = df[df["Team"].astype("string").str.strip().str.upper() == team.upper()]
    return {"team": team, "territories": int(t["Territory_ID"].nunique())}


def alignment_meta(df: pd.DataFrame, team: str = config.TEAM) -> dict:
    """Summary stored with the copy: FileIDs, zips and territories for the team."""
    t = df[df["Team"].astype("string").str.strip().str.upper() == team.upper()]
    ids = sorted(t["FileID"].dropna().astype(str).unique().tolist(), key=_fileid_key)
    latest = t[t["FileID"].astype(str) == ids[-1]] if ids else t
    return {
        "team": team, "file_ids": ids, "latest_file_id": ids[-1] if ids else None,
        "zips": int(latest["ZIPCode"].nunique()), "territories": int(latest["Territory_ID"].nunique()),
    }


def alignment_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Same shape as config.alignment_check_query: Team, FileID, Rows, Zips."""
    if df is None or df.empty:
        return pd.DataFrame(columns=["Team", "FileID", "Rows", "Zips"])
    return (df.groupby(["Team", "FileID"], dropna=False)
            .agg(Rows=("ZIPCode", "size"), Zips=("ZIPCode", "nunique")).reset_index())


def _fileid_key(v: str):
    try:
        return (0, float(v))
    except (TypeError, ValueError):
        return (1, str(v))


def describe(meta: dict, now: datetime | None = None) -> str:
    """'pulled Oct 14, 2026 (7 days ago), FileID 1500, 41,233 zips'."""
    pulled = datetime.fromisoformat(meta["pulled_at"])
    days = int(age_days(meta, now))
    ago = "today" if days == 0 else "yesterday" if days == 1 else f"{days} days ago"
    parts = [f"pulled {pulled:%b} {pulled.day}, {pulled.year} ({ago})"]
    if meta.get("latest_file_id"):
        parts.append(f"FileID {meta['latest_file_id']}")
    if meta.get("zips"):
        parts.append(f"{meta['zips']:,} zips")
    elif meta.get("accounts"):
        parts.append(f"{meta['accounts']:,} accounts")
    elif meta.get("territories"):
        parts.append(f"{meta['territories']} territories")
    return ", ".join(parts)


def oldest(metas: dict[str, dict | None]) -> tuple[str, dict] | None:
    """(name, meta) of the oldest stored copy, ignoring tables with no copy."""
    have = [(n, m) for n, m in metas.items() if m]
    if not have:
        return None
    return min(have, key=lambda nm: nm[1]["pulled_at"])
