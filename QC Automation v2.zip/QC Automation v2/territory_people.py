"""Roster and user tables: one owner per territory, tenure, and a check against the alignment.

POWERBI_ROSTER is the territory master (one row per territory). POWERBI_USER ("Employee" in
Power BI) gives the owner's name and start date per territory. Both are merged in pandas;
row counts are asserted after the join.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

import pandas as pd

import config
from data_prep import clean_frame, normalize_upper

OWNER_COLUMNS = ["Territory_ID", "Territory_Name", "Region_ID", "Region_Name", "region_manager_login",
                 "owner_name", "owner_start_date", "days_in_territory", "new_to_territory"]


@dataclass
class TerritoryPeople:
    owners: pd.DataFrame                                   # one row per roster territory
    warnings: list[str] = field(default_factory=list)
    roster_vs_alignment: pd.DataFrame = field(default_factory=pd.DataFrame)
    duplicate_users: pd.DataFrame = field(default_factory=pd.DataFrame)
    available: bool = True

    def owner_map(self) -> pd.Series:
        """Territory_ID -> owner name."""
        if self.owners.empty:
            return pd.Series(dtype="string")
        return self.owners.set_index("Territory_ID")["owner_name"]


def _team(df: pd.DataFrame, team: str) -> pd.DataFrame:
    return df[normalize_upper(df["Team"]) == team.upper()].copy()


def prepare_roster(raw: pd.DataFrame, team: str = config.TEAM) -> tuple[pd.DataFrame, list[str]]:
    df = _team(clean_frame(raw), team)
    df["Territory_ID"] = normalize_upper(df["Territory_ID"])
    warns = []
    dup = df["Territory_ID"].duplicated(keep="first")
    if dup.any():
        warns.append(f"The roster lists {int(dup.sum())} territories more than once; the first row is kept.")
    df = df[~dup & df["Territory_ID"].notna()].reset_index(drop=True)
    return df, warns


def prepare_users(raw: pd.DataFrame, team: str = config.TEAM) -> tuple[pd.DataFrame, pd.DataFrame]:
    """One user per territory: active first, then the latest Start_Date. Returns (users, duplicates)."""
    df = _team(clean_frame(raw), team)
    df["Territory_ID"] = normalize_upper(df["Territory_ID"])
    df["Start_Date"] = pd.to_datetime(df["Start_Date"], errors="coerce").dt.normalize()
    active = df["IsActive"].astype("string").str.strip().str.lower()
    df["_active"] = active.isin(["1", "true", "1.0"])
    df = df[df["Territory_ID"].notna()]
    counts = df.groupby("Territory_ID")["Territory_ID"].transform("size")
    dups = df[counts > 1][["Territory_ID", "NAME", "IsActive", "Start_Date"]].sort_values("Territory_ID")
    df = (df.sort_values(["Territory_ID", "_active", "Start_Date"], ascending=[True, False, False], na_position="last")
          .drop_duplicates("Territory_ID").reset_index(drop=True))
    return df, dups


def build_owners(roster_raw: pd.DataFrame | None, user_raw: pd.DataFrame | None, as_of,
                 alignment_table: pd.DataFrame | None = None, team: str = config.TEAM,
                 new_days: int = config.NEW_TO_TERRITORY_DAYS) -> TerritoryPeople:
    """Owner per territory from the roster (master) LEFT JOIN users on Territory_ID."""
    if roster_raw is None or len(roster_raw) == 0:
        return TerritoryPeople(pd.DataFrame(columns=OWNER_COLUMNS),
                               ["The roster isn't available, so owner names are hidden."], available=False)
    roster, warns = prepare_roster(roster_raw, team)
    n = len(roster)
    if user_raw is not None and len(user_raw):
        users, dups = prepare_users(user_raw, team)
        if len(dups):
            warns.append(f"{dups['Territory_ID'].nunique()} territories have more than one user; "
                         "the active user with the latest start date is used.")
    else:
        users, dups = pd.DataFrame(columns=["Territory_ID", "NAME", "Start_Date"]), pd.DataFrame()
        warns.append("The user table isn't available, so owner names are hidden.")

    out = roster.merge(users[["Territory_ID", "NAME", "Start_Date"]], on="Territory_ID", how="left",
                       validate="one_to_one")
    assert len(out) == n, f"Owner join changed the roster row count from {n} to {len(out)}"
    as_of_ts = pd.Timestamp(as_of).normalize()
    owners = pd.DataFrame({
        "Territory_ID": out["Territory_ID"],
        "Territory_Name": out["Territory_Name"],
        "Region_ID": out["Region_ID"],
        "Region_Name": out["Region_Name"],
        "region_manager_login": out["Reg"],
        "owner_name": out["NAME"].astype("string"),
        "owner_start_date": pd.to_datetime(out["Start_Date"], errors="coerce"),
    })
    owners["days_in_territory"] = (as_of_ts - owners["owner_start_date"]).dt.days
    owners["new_to_territory"] = owners["days_in_territory"].between(0, new_days - 1).fillna(False).astype(bool)
    missing_owner = int(owners["owner_name"].isna().sum())
    if missing_owner and len(users):
        warns.append(f"{missing_owner} roster territories have no matching user.")

    check = roster_vs_alignment(owners, alignment_table)
    n_bad = int((check["Issue"] != "OK").sum()) if len(check) else 0
    if n_bad:
        warns.append(f"{n_bad} territories differ between the roster and zip-to-territory. See More checks.")
    return TerritoryPeople(owners[OWNER_COLUMNS].reset_index(drop=True), warns, check, dups)


def roster_vs_alignment(owners: pd.DataFrame, alignment_table: pd.DataFrame | None) -> pd.DataFrame:
    """Territory IDs and names in the roster vs the zip-to-territory alignment in use."""
    cols = ["Territory_ID", "Roster name", "Alignment name", "Issue"]
    if alignment_table is None or alignment_table.empty or owners.empty:
        return pd.DataFrame(columns=cols)
    al = (alignment_table.assign(Territory_ID=normalize_upper(alignment_table["Territory_ID"]))
          .groupby("Territory_ID")["Territory_Name"].first())
    ro = owners.set_index("Territory_ID")["Territory_Name"]
    ids = sorted(set(al.index) | set(ro.index))
    rows = []
    for t in ids:
        rn, an = ro.get(t), al.get(t)
        if t not in ro.index:
            issue = "In alignment, not in roster"
        elif t not in al.index:
            issue = "In roster, not in alignment"
        elif str(rn).strip().upper() != str(an).strip().upper():
            issue = "Different name"
        else:
            issue = "OK"
        rows.append({"Territory_ID": t, "Roster name": rn, "Alignment name": an, "Issue": issue})
    return pd.DataFrame(rows, columns=cols)


def unavailable(reason: str) -> TerritoryPeople:
    return TerritoryPeople(pd.DataFrame(columns=OWNER_COLUMNS), [reason], available=False)


def today() -> date:
    return date.today()
