"""Plotly figures. Every figure uses the shared template from ui/theme.py.

Chart titles live in the card header (HTML), not inside the plot.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

import fiscal_calendar as fc
from ui.theme import FONT_STACK_PLOTLY, Theme, plotly_template


def _base(theme: Theme, height: int = 300) -> go.Figure:
    fig = go.Figure()
    # Backgrounds are also set on the layout itself so no host theme can repaint them.
    fig.update_layout(template=plotly_template(theme["product"], theme["mode"]), height=height,
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font=dict(family=FONT_STACK_PLOTLY, color=theme["ink"]),
                      hoverlabel=dict(bgcolor=theme["surface"], bordercolor=theme["border"],
                                      font=dict(family=FONT_STACK_PLOTLY, size=12, color=theme["ink"])))
    tick = dict(size=12, color=theme["ink-muted"], family=FONT_STACK_PLOTLY)
    fig.update_xaxes(showgrid=False, zeroline=False, showline=False, tickfont=tick)
    fig.update_yaxes(showgrid=True, gridcolor=theme["border"], gridwidth=1, zeroline=False, showline=False, tickfont=tick)
    return fig


def _alpha(hex_color: str, a: float) -> str:
    h = hex_color.lstrip("#")
    return f"rgba({int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)},{a})"


def _fmt(v: float) -> str:
    return f"{v:,.0f}"


def _neg_zero_line(fig: go.Figure, theme: Theme, values, axis: str = "y") -> None:
    vals = np.asarray(list(values), dtype=float)
    if len(vals) and np.nanmin(vals) < 0:
        fig.update_layout(**{f"{axis}axis": dict(zeroline=True, zerolinecolor=theme["ink-muted"], zerolinewidth=1)})


def _rounded(fig: go.Figure) -> None:
    try:
        fig.update_traces(marker_cornerradius=4, selector=dict(type="bar"))
    except (ValueError, AttributeError):  # older Plotly without cornerradius
        pass


def anomaly_ring_trace(dates, values, reasons, kind: str, theme: Theme, name: str) -> go.Scatter:
    color = theme["up"] if kind == "spike" else theme["down"]
    return go.Scatter(
        x=list(dates), y=list(values), mode="markers", name=name,
        marker=dict(size=14, color="rgba(0,0,0,0)", line=dict(color=color, width=2.5), symbol="circle"),
        text=list(reasons), hovertemplate="%{text}<extra></extra>",
    )


# --- Overview --------------------------------------------------------------------
def weekly_trend(ws: pd.DataFrame, avg13: float, anomalies: pd.DataFrame, theme: Theme, height: int = 320) -> go.Figure:
    """Weekly net units (26 weeks) as a line over a soft fill; dashed 13-week average; the current
    week sits in a tinted band and its partial value is joined with a dashed segment; rings mark unusual weeks."""
    fig = _base(theme, height)
    d = ws.reset_index(drop=True)
    labels = [f"Week of {fc.fmt_date(x)}" + (" (to date)" if p else "") for x, p in zip(d["week_start"], d["partial"])]
    cur_i = int(d.index[d["is_current"]][0]) if d["is_current"].any() else len(d) - 1
    full = d.iloc[: cur_i + (0 if d["partial"].iloc[cur_i] else 1)]
    # current-week band
    x0 = d["week_start"].iloc[cur_i] - pd.Timedelta(days=3.5)
    fig.add_vrect(x0=x0, x1=x0 + pd.Timedelta(days=7), fillcolor=theme["accent-tint"], opacity=0.9, line_width=0, layer="below")
    fig.add_scatter(x=full["week_start"], y=full["units"], mode="lines", name="Units",
                    line=dict(color=theme["accent"], width=2), fill="tozeroy", fillcolor=_alpha(theme["accent"], 0.07),
                    hovertext=labels[: len(full)], hovertemplate="%{hovertext}<br><b>%{y:,.0f}</b> units<extra></extra>")
    if d["partial"].iloc[cur_i] and cur_i > 0:
        seg = d.iloc[cur_i - 1: cur_i + 1]
        fig.add_scatter(x=seg["week_start"], y=seg["units"], mode="lines+markers", name="This week so far",
                        line=dict(color=theme["accent"], width=2, dash="dot"), marker=dict(size=[0, 7], color=theme["accent"]),
                        hovertext=labels[cur_i - 1: cur_i + 1], hovertemplate="%{hovertext}<br><b>%{y:,.0f}</b> units<extra></extra>")
    fig.add_hline(y=avg13, line=dict(color=theme["ink-faint"], width=1.5, dash="dash"))
    if anomalies is not None and len(anomalies):
        fig.add_trace(go.Scatter(
            x=list(anomalies["date"]), y=list(anomalies["value"]), mode="markers", name="Unusual week",
            marker=dict(size=13, color="rgba(0,0,0,0)",
                        line=dict(color=[theme["up"] if k == "spike" else theme["down"] for k in anomalies["kind"]], width=2)),
            text=list(anomalies["reason"]), hovertemplate="%{text}<extra></extra>"))
    fig.update_layout(showlegend=False, margin=dict(l=4, r=8, t=8, b=4))
    fig.update_xaxes(tickformat="%b %-d", dtick=7 * 24 * 3600 * 1000 * 4, ticklabelmode="period",
                     range=[d["week_start"].iloc[0] - pd.Timedelta(days=4), d["week_start"].iloc[-1] + pd.Timedelta(days=4)])
    fig.update_yaxes(rangemode="tozero")
    _neg_zero_line(fig, theme, d["units"])
    return fig


def period_compare(kpis, theme: Theme, height: int = 260) -> go.Figure:
    """Current vs comparison average for week, month and quarter."""
    fig = _base(theme, height)
    names = ["Week", "Month", "Quarter"]
    cur = [k.current for k in kpis]
    avg = [k.average for k in kpis]
    fig.add_bar(y=names, x=avg, orientation="h", name="Comparison average", marker_color=theme["ink-faint"],
                text=[_fmt(v) for v in avg], textposition="outside", cliponaxis=False,
                hovertemplate="%{y}: average %{x:,.1f}<extra></extra>")
    fig.add_bar(y=names, x=cur, orientation="h", name="Current", marker_color=theme["accent"],
                text=[_fmt(v) for v in cur], textposition="outside", cliponaxis=False,
                hovertemplate="%{y}: current %{x:,.0f}<extra></extra>")
    fig.update_layout(barmode="group", bargap=0.35, bargroupgap=0.12)
    fig.update_yaxes(autorange="reversed", showgrid=False)
    fig.update_xaxes(showgrid=True, gridcolor=theme["border"])
    _rounded(fig)
    return fig


def change_bars(gc: pd.DataFrame, theme: Theme, height: int | None = None, max_rows: int = 20) -> go.Figure:
    """Diverging horizontal bars of % change vs average, sorted, value labels at bar ends."""
    d = gc.dropna(subset=["pct"]).copy()
    d = d.reindex(d["pct"].abs().sort_values(ascending=False).index).head(max_rows).sort_values("pct")
    h = height or max(180, 34 * len(d) + 40)
    fig = _base(theme, h)
    if d.empty:
        fig.add_annotation(text="No comparison available", showarrow=False, font=dict(color=theme["ink-muted"]))
        fig.update_xaxes(visible=False)
        fig.update_yaxes(visible=False)
        return fig
    colors = [theme["up"] if p >= 0 else theme["down"] for p in d["pct"]]
    arrows = ["↑" if p >= 0 else "↓" for p in d["pct"]]
    labels = [f"{a} {'+' if p >= 0 else '−'}{abs(p):.0f}%" for a, p in zip(arrows, d["pct"])]
    fig.add_bar(y=d["name"], x=d["pct"], orientation="h", marker_color=colors, text=labels, textposition="outside",
                cliponaxis=False, textfont=dict(size=12, color=theme["ink"]),
                customdata=np.stack([d["current"], d["average"]], axis=1),
                hovertemplate="<b>%{y}</b><br>%{x:+.0f}% vs average<br>Current %{customdata[0]:,.0f}, "
                              "average %{customdata[1]:,.1f}<extra></extra>")
    span = max(10.0, float(d["pct"].abs().max()))
    fig.update_xaxes(range=[-span * 1.45 if (d["pct"] < 0).any() else -span * 0.15,
                            span * 1.45 if (d["pct"] > 0).any() else span * 0.15],
                     ticksuffix="%", showgrid=True, gridcolor=theme["border"], zeroline=True,
                     zerolinecolor=theme["ink-muted"], zerolinewidth=1)
    fig.update_yaxes(showgrid=False)
    fig.update_layout(showlegend=False, bargap=0.35)
    _rounded(fig)
    return fig


# --- Accounts ----------------------------------------------------------------------
def account_history(weekly: pd.DataFrame, anomalies: pd.DataFrame | None, theme: Theme, height: int = 300) -> go.Figure:
    fig = _base(theme, height)
    fig.add_scatter(x=weekly["week_start"], y=weekly["units"], mode="lines", name="Net units",
                    line=dict(color=theme["accent"], width=2, shape="hv"),
                    fill="tozeroy", fillcolor=theme["accent-tint"],
                    hovertemplate="Week of %{x|%b %-d, %Y}<br><b>%{y:,.0f}</b> units<extra></extra>")
    if anomalies is not None and len(anomalies):
        for kind, nm in [("spike", "Spike"), ("drop", "Drop")]:
            a = anomalies[anomalies["kind"] == kind]
            if len(a):
                fig.add_trace(anomaly_ring_trace(a["date"], a["value"], a["reason"], kind, theme, nm))
    fig.update_layout(showlegend=False)
    _neg_zero_line(fig, theme, weekly["units"])
    return fig


def monthly_bars(monthly: pd.DataFrame, theme: Theme, height: int = 260) -> go.Figure:
    fig = _base(theme, height)
    fig.add_bar(x=monthly["month"], y=monthly["sales"], name="Purchases", marker_color=theme["accent"],
                hovertemplate="%{x|%b %Y}: %{y:,.0f} purchased<extra></extra>")
    if (monthly["returns"] != 0).any():
        fig.add_bar(x=monthly["month"], y=monthly["returns"], name="Returns", marker_color=theme["down"],
                    hovertemplate="%{x|%b %Y}: %{y:,.0f} returned<extra></extra>")
    fig.add_scatter(x=monthly["month"], y=monthly["net"], mode="markers", name="Net",
                    marker=dict(color=theme["ink"], size=6, symbol="line-ew-open", line=dict(width=2)),
                    hovertemplate="%{x|%b %Y}: net %{y:,.0f}<extra></extra>")
    fig.update_layout(barmode="relative", showlegend=True)
    fig.update_xaxes(tickformat="%b %Y")
    _neg_zero_line(fig, theme, monthly["returns"])
    _rounded(fig)
    return fig


def order_intervals(orders: pd.DataFrame, typical: float | None, theme: Theme, height: int = 240) -> go.Figure:
    """Days between consecutive orders, with the typical interval as reference."""
    fig = _base(theme, height)
    d = orders.drop_duplicates("Invoice_Date").sort_values("Invoice_Date")
    gaps = d["Invoice_Date"].diff().dt.days
    fig.add_bar(x=d["Invoice_Date"].iloc[1:], y=gaps.iloc[1:], marker_color=theme["accent"], name="Days since previous order",
                hovertemplate="Order on %{x|%b %-d, %Y}<br>%{y:.0f} days after the previous one<extra></extra>")
    if typical and typical > 0:
        fig.add_hline(y=typical, line=dict(color=theme["ink-faint"], dash="dash", width=1.5),
                      annotation=dict(text=f"Typical {typical:.0f} days", font=dict(size=12, color=theme["ink-muted"]),
                                      xanchor="left", x=0, bgcolor=theme["surface"]))
    fig.update_layout(showlegend=False)
    fig.update_yaxes(ticksuffix=" d")
    _rounded(fig)
    return fig


def movers(df: pd.DataFrame, label_col: str, theme: Theme, kind: str, height: int | None = None) -> go.Figure:
    """Top growing / declining by unit change (last 3 vs prior 3 months)."""
    d = df.copy()
    h = height or max(160, 30 * len(d) + 30)
    fig = _base(theme, h)
    if d.empty:
        fig.add_annotation(text="None in this selection", showarrow=False, font=dict(color=theme["ink-muted"]))
        fig.update_xaxes(visible=False)
        fig.update_yaxes(visible=False)
        return fig
    color = theme["up"] if kind == "up" else theme["down"]
    names = [n if len(n) <= 38 else n[:36] + "…" for n in d[label_col].astype(str)]
    sign = "+" if kind == "up" else "−"
    arrow = "↑" if kind == "up" else "↓"
    text = [f"{arrow} {sign}{abs(v):,.0f}" + (f" ({p:+.0f}%)".replace("-", "−") if pd.notna(p) else "")
            for v, p in zip(d["delta_3v3"], d["pct_3v3"])]
    fig.add_bar(y=names, x=d["delta_3v3"].abs(), orientation="h", marker_color=color, text=text,
                textposition="outside", cliponaxis=False, textfont=dict(size=12, color=theme["ink"]),
                customdata=np.stack([d["last3"], d["prior3"]], axis=1),
                hovertemplate="<b>%{y}</b><br>Last 3 months %{customdata[0]:,.0f}, prior 3 %{customdata[1]:,.0f}<extra></extra>")
    fig.update_yaxes(autorange="reversed", showgrid=False)
    fig.update_xaxes(range=[0, float(d["delta_3v3"].abs().max()) * 1.7], showgrid=True, gridcolor=theme["border"])
    fig.update_layout(showlegend=False, bargap=0.3)
    _rounded(fig)
    return fig


def heatmap(h: pd.DataFrame, theme: Theme, height: int | None = None) -> go.Figure:
    fig = _base(theme, height or max(220, 22 * len(h) + 60))
    if h.empty:
        fig.add_annotation(text="No sales in this window", showarrow=False, font=dict(color=theme["ink-muted"]))
        fig.update_xaxes(visible=False)
        fig.update_yaxes(visible=False)
        return fig
    names = [n if len(n) <= 44 else n[:42] + "…" for n in h.index.astype(str)]
    fig.add_heatmap(z=h.values, x=list(h.columns), y=names, colorscale=[[0, theme["surface-sunken"]], [1, theme["accent"]]],
                    xgap=2, ygap=2, hovertemplate="<b>%{y}</b><br>%{x}: %{z:,.0f} units<extra></extra>",
                    colorbar=dict(thickness=10, outlinewidth=0, tickfont=dict(size=11, color=theme["ink-muted"]),
                                  title=dict(text="Units", font=dict(size=11, color=theme["ink-muted"]))))
    fig.update_yaxes(autorange="reversed", showgrid=False, tickfont=dict(size=11))
    fig.update_xaxes(side="top", showgrid=False)
    return fig


# =============================================================================
# Product deep dive
# =============================================================================
def _mix(c1: str, c2: str, t: float) -> str:
    a = [int(c1.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    b = [int(c2.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)]
    return "#" + "".join(f"{round(x + (y - x) * t):02x}" for x, y in zip(a, b))


def confidence_colors(theme: Theme) -> dict:
    """Ordinal ramp of the product accent: High darkest, Low lightest (never a status colour)."""
    return {"High": theme["accent"], "Medium": _mix(theme["surface"], theme["accent"], 0.62),
            "Low": _mix(theme["surface"], theme["accent"], 0.36)}


def dd_weekly(w: pd.DataFrame, upc: float, unit: str, theme: Theme, height: int = 300) -> go.Figure:
    """Weekly units (bars, one scale). The right axis relabels the same scale in estimated cycles."""
    fig = _base(theme, height)
    colors = [_mix(theme["surface"], theme["accent"], 0.45) if p else theme["accent"] for p in w["partial"]]
    lab = [f"Week of {fc.fmt_date(x)}" + (" (to date)" if p else "") for x, p in zip(w["week_start"], w["partial"])]
    fig.add_bar(x=w["week_start"], y=w["units"], marker_color=colors, name=unit.capitalize(),
                customdata=np.c_[w["cycles"], lab],
                hovertemplate="%{customdata[1]}<br><b>%{y:,.0f}</b> " + unit +
                              "<br>≈ %{customdata[0]:,.1f} cycles (estimate)<extra></extra>")
    top = max(1.0, float(w["units"].max()) * 1.08)
    fig.update_yaxes(range=[min(0, float(w["units"].min()) * 1.1), top], title_text=unit.capitalize())
    fig.add_scatter(x=[w["week_start"].iloc[0]], y=[0], yaxis="y2", mode="markers", marker_opacity=0,
                    hoverinfo="skip", showlegend=False)
    fig.update_layout(yaxis2=dict(overlaying="y", side="right", range=[v / upc for v in fig.layout.yaxis.range],
                                  showgrid=False, zeroline=False, title_text="Est. cycles",
                                  tickfont=dict(size=12, color=theme["ink-muted"], family=FONT_STACK_PLOTLY),
                                  title_font=dict(size=12, color=theme["ink-muted"])),
                      showlegend=False, bargap=0.25, margin=dict(l=4, r=4, t=8, b=4))
    fig.update_xaxes(tickformat="%b %-d")
    _rounded(fig)
    return fig


def dd_order_hist(h: pd.DataFrame, band_order: list[str], unit: str, theme: Theme, height: int = 280) -> go.Figure:
    fig = _base(theme, height)
    cat = theme["cat"]
    present = set(h["band"])
    for i, b in enumerate(band_order):
        if b not in present:
            continue
        d = h[h["band"] == b]
        fig.add_bar(x=d["units"], y=d["events"], name=b, marker_color=cat[i % len(cat)],
                    marker_line=dict(color=theme["surface"], width=1),
                    hovertemplate=f"<b>%{{x}} {unit}</b> per order event<br>%{{y}} events<br>{b}<extra></extra>")
    fig.update_layout(barmode="stack", bargap=0.15, legend=dict(orientation="h", y=1.02, x=0, yanchor="bottom",
                                                                 traceorder="normal"),
                      margin=dict(l=4, r=8, t=28, b=4))
    fig.update_xaxes(title_text=f"{unit.capitalize()} per order event (orders within the grouping window combined)",
                     dtick=1 if h["units"].max() <= 30 else None)
    fig.update_yaxes(title_text="Events")
    _rounded(fig)
    return fig


def dd_mix(share: pd.DataFrame, theme: Theme, height: int = 260, pct: bool = True, order: list | None = None) -> go.Figure:
    """100% stacked monthly bars, categories in fixed order (entity keeps its colour)."""
    fig = _base(theme, height)
    if share is None or share.empty:
        return fig
    full = list(order) if order else [c for c in share.columns if str(c) != "Other"] + (["Other"] if "Other" in share.columns else [])
    cat = theme["cat"]
    scale = 100 if share.values.max() <= 1.0001 else 1
    for i, c in enumerate(full):
        if c not in share.columns:
            continue
        vals = share[c] * scale
        color = theme["ink-faint"] if str(c) == "Other" else cat[i % len(cat)]
        fig.add_bar(x=share.index, y=vals, name=str(c), marker_color=color,
                    marker_line=dict(color=theme["surface"], width=1),
                    hovertemplate=f"<b>{c}</b><br>%{{x|%b %Y}}: %{{y:.0f}}%<extra></extra>")
    fig.update_layout(barmode="stack", bargap=0.2, legend=dict(orientation="h", y=1.02, x=0, yanchor="bottom",
                                                                traceorder="normal"),
                      margin=dict(l=4, r=8, t=30, b=4))
    fig.update_yaxes(range=[0, 100], ticksuffix="%")
    fig.update_xaxes(tickformat="%b")
    return fig


def dd_intervals(iv: pd.DataFrame, bands, label_cycle: int, max_gap: int, theme: Theme, height: int = 260) -> go.Figure:
    fig = _base(theme, height)
    for lo, hi, name in bands:
        fig.add_vrect(x0=lo - 0.5, x1=hi + 0.5, fillcolor=theme["accent-tint"], line_width=0, layer="below",
                      annotation_text=name.replace("-day cycle", "-day band"), annotation_position="top left",
                      annotation_font=dict(size=11, color=theme["ink-muted"]))
    if len(iv):
        c = iv.groupby(["gap", "on_schedule"]).size().reset_index(name="n")
        for flag, color, name in [(True, theme["accent"], "On schedule"), (False, theme["ink-faint"], "Off schedule")]:
            d = c[c["on_schedule"] == flag]
            fig.add_bar(x=d["gap"], y=d["n"], marker_color=color, name=name,
                        hovertemplate="%{x} days between orders<br><b>%{y}</b> reorders<extra>" + name + "</extra>")
    fig.add_vline(x=label_cycle, line=dict(color=theme["ink-muted"], dash="dash", width=1.5))
    fig.update_layout(barmode="stack", bargap=0.1, showlegend=False, margin=dict(l=4, r=8, t=24, b=4))
    fig.update_xaxes(title_text="Days between order events (within a course)", range=[0, max_gap + 1])
    fig.update_yaxes(title_text="Reorders")
    _rounded(fig)
    return fig


def dd_hbar_pct(df: pd.DataFrame, label: str, value: str, theme: Theme, height: int | None = None) -> go.Figure:
    d = df.sort_values(value)
    fig = _base(theme, height or max(160, 26 * len(d) + 40))
    fig.add_bar(y=d[label].astype(str), x=d[value] * 100, orientation="h", marker_color=theme["accent"],
                text=[f"{v * 100:.0f}%" for v in d[value]], textposition="outside",
                textfont=dict(color=theme["ink-muted"], size=12),
                hovertemplate="%{y}: <b>%{x:.0f}%</b> on schedule<extra></extra>")
    fig.update_xaxes(range=[0, 110], ticksuffix="%", showgrid=True, gridcolor=theme["border"])
    fig.update_yaxes(showgrid=False)
    fig.update_layout(showlegend=False, bargap=0.35, margin=dict(l=4, r=8, t=4, b=4))
    _rounded(fig)
    return fig


def dd_starts(st_: pd.DataFrame, theme: Theme, height: int = 300) -> go.Figure:
    """Two small multiples on a shared month axis: new course starts (bars) and courses running (line)."""
    from plotly.subplots import make_subplots

    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.12, row_heights=[0.55, 0.45],
                        subplot_titles=("New course starts", "Courses running at month end"))
    base = _base(theme, height)
    fig.update_layout(base.layout)
    fig.add_bar(x=st_["month"], y=st_["starts"], marker_color=theme["accent"], name="Starts", row=1, col=1,
                hovertemplate="%{x|%b %Y}: <b>%{y}</b> new course starts (estimate)<extra></extra>")
    fig.add_scatter(x=st_["month"], y=st_["ongoing"], mode="lines+markers", line=dict(color=theme["accent"], width=2),
                    marker=dict(size=8, color=theme["accent"], line=dict(color=theme["surface"], width=2)),
                    name="Running", row=2, col=1,
                    hovertemplate="%{x|%b %Y}: <b>%{y}</b> courses running (estimate)<extra></extra>")
    for a in fig.layout.annotations:
        a.font = dict(size=12, color=theme["ink-muted"], family=FONT_STACK_PLOTLY)
        a.x, a.xanchor = 0, "left"
    tick = dict(size=12, color=theme["ink-muted"], family=FONT_STACK_PLOTLY)
    fig.update_xaxes(showgrid=False, tickfont=tick, tickformat="%b")
    fig.update_yaxes(showgrid=True, gridcolor=theme["border"], tickfont=tick, rangemode="tozero")
    fig.update_layout(showlegend=False, height=height, margin=dict(l=4, r=8, t=24, b=4))
    _rounded(fig)
    return fig


def dd_persistence(p, theme: Theme, ref=None, height: int = 300) -> go.Figure:
    """Kaplan–Meier step curve: % of courses reaching each cycle. Ticks mark ongoing (censored) courses."""
    fig = _base(theme, height)
    t = p.table
    if t.empty:
        return fig
    if ref is not None and len(ref.table) and ref is not p:
        fig.add_scatter(x=ref.table["cycle"], y=ref.table["survival"] * 100, mode="lines", line_shape="hv",
                        line=dict(color=theme["ink-faint"], width=1.5, dash="dash"), name="All accounts",
                        hovertemplate="All accounts: %{y:.0f}% reach cycle %{x}<extra></extra>")
    fig.add_scatter(x=t["cycle"], y=t["survival"] * 100, mode="lines", line_shape="hv",
                    line=dict(color=theme["accent"], width=2), name="This selection" if ref is not None else "Courses",
                    customdata=t["at_risk"],
                    hovertemplate="<b>%{y:.0f}%</b> of courses reach cycle %{x}<br>%{customdata} courses still at "
                                  "that cycle<extra></extra>")
    if p.censored_cycles:
        cc = pd.Series(p.censored_cycles).value_counts().sort_index()
        surv = t.set_index("cycle")["survival"]
        fig.add_scatter(x=[int(c) + 0.5 for c in cc.index], y=[float(surv.get(int(c), surv.iloc[-1])) * 100 for c in cc.index],
                        mode="markers", marker=dict(symbol="line-ns-open", size=12, color=theme["accent"],
                                                    line=dict(width=2, color=theme["accent"])),
                        name="Ongoing courses", customdata=np.c_[cc.values, cc.index],
                        hovertemplate="%{customdata[0]} ongoing course(s) at cycle %{customdata[1]} "
                                      "(still running, counted as censored)<extra></extra>")
    fig.update_yaxes(range=[0, 105], ticksuffix="%", title_text="Courses reaching cycle")
    fig.update_xaxes(title_text="Cycle", dtick=1 if t["cycle"].max() <= 16 else 2, range=[0.5, t["cycle"].max() + 0.5])
    fig.update_layout(legend=dict(orientation="h", y=1.02, x=0, yanchor="bottom"), margin=dict(l=4, r=8, t=28, b=4))
    return fig


def dd_bars(x, y, theme: Theme, xtitle: str = "", ytitle: str = "", height: int = 240, hover: str = "") -> go.Figure:
    fig = _base(theme, height)
    fig.add_bar(x=list(x), y=list(y), marker_color=theme["accent"],
                hovertemplate=hover or "%{x}: <b>%{y:,.0f}</b><extra></extra>")
    fig.update_xaxes(title_text=xtitle)
    fig.update_yaxes(title_text=ytitle)
    fig.update_layout(showlegend=False, bargap=0.3, margin=dict(l=4, r=8, t=8, b=4))
    _rounded(fig)
    return fig


def dd_waterfall(steps: pd.DataFrame, unit: str, theme: Theme, height: int = 280) -> go.Figure:
    fig = _base(theme, height)
    measure = ["absolute"] + ["relative"] * (len(steps) - 2) + ["total"]
    short = {"Last quarter, same days": "Last quarter<br>same days", "This quarter to date": "This quarter<br>to date"}
    fig.add_trace(go.Waterfall(
        x=[short.get(x, x) for x in steps["step"]], y=steps["value"], measure=measure,
        text=[_fmt(v) if m != "relative" else (("+" if v > 0 else "−" if v < 0 else "±") + _fmt(abs(v)))
              for v, m in zip(steps["value"], measure)],
        textposition="outside", textfont=dict(color=theme["ink-muted"], size=12),
        increasing=dict(marker=dict(color=theme["up"])), decreasing=dict(marker=dict(color=theme["down"])),
        totals=dict(marker=dict(color=theme["accent"])),
        connector=dict(line=dict(color=theme["border"], width=1)),
        hovertemplate="%{x}: <b>%{y:,.0f}</b> " + unit + "<extra></extra>"))
    fig.update_layout(showlegend=False, margin=dict(l=4, r=8, t=16, b=4))
    fig.update_xaxes(tickangle=0)
    fig.update_yaxes(title_text=unit.capitalize())
    return fig


def dd_heatmap_pct(h: pd.DataFrame, theme: Theme, height: int | None = None) -> go.Figure:
    """Cohort retention: one-hue ramp of the accent, % in each cell, blank = not happened yet."""
    fig = _base(theme, height or max(200, 34 * len(h) + 60))
    if h.empty:
        return fig
    h = h.loc[:, h.notna().any(axis=0)]
    z = h.values.astype(float)
    text = [["" if v != v else f"{v:.0f}%" for v in row] for row in z]
    fig.add_heatmap(z=z, x=list(h.columns), y=list(h.index), text=text, texttemplate="%{text}",
                    textfont=dict(size=11), xgap=2, ygap=2, zmin=0, zmax=100, showscale=False,
                    colorscale=[[0, _mix(theme["surface"], theme["accent"], 0.06)], [1, theme["accent"]]],
                    hovertemplate="%{y} cohort, %{x}: <b>%{z:.0f}%</b> of accounts ordered<extra></extra>")
    fig.update_yaxes(autorange="reversed", showgrid=False)
    fig.update_xaxes(side="top", showgrid=False)
    fig.update_layout(margin=dict(l=4, r=8, t=8, b=4))
    return fig


def dd_forecast(hist: pd.DataFrame, table: pd.DataFrame, unit: str, range_pct: int, theme: Theme,
                n_hist: int = 26, height: int = 320) -> go.Figure:
    """Actuals solid, forecast dashed, the range shaded in the product tint."""
    fig = _base(theme, height)
    if table.empty:
        return fig
    cur = table["week_start"].iloc[0]
    h = hist[hist["week_start"] < cur].tail(n_hist)
    t = table
    fig.add_scatter(x=list(t["week_start"]) + list(t["week_start"][::-1]), y=list(t["hi"]) + list(t["lo"][::-1]),
                    fill="toself", fillcolor=_alpha(theme["accent"], 0.16), line=dict(width=0), hoverinfo="skip",
                    name=f"{range_pct}% range")
    fig.add_scatter(x=h["week_start"], y=h["units"], mode="lines", line=dict(color=theme["accent"], width=2),
                    name="Actual", hovertemplate="Week of %{x|%b %-d}: <b>%{y:,.0f}</b> " + unit + "<extra>Actual</extra>")
    xs = [h["week_start"].iloc[-1]] + list(t["week_start"]) if len(h) else list(t["week_start"])
    ys = [h["units"].iloc[-1]] + list(t["blend"]) if len(h) else list(t["blend"])
    fig.add_scatter(x=xs, y=ys, mode="lines", line=dict(color=theme["accent"], width=2, dash="dash"), name="Forecast",
                    customdata=[[None, None]] + [[lo, hi] for lo, hi in zip(t["lo"], t["hi"])] if len(h) else
                    [[lo, hi] for lo, hi in zip(t["lo"], t["hi"])],
                    hovertemplate="Week of %{x|%b %-d}: <b>%{y:,.0f}</b> " + unit +
                                  " (range %{customdata[0]:,.0f}–%{customdata[1]:,.0f})<extra>Forecast</extra>")
    fig.add_vline(x=cur - pd.Timedelta(days=3.5), line=dict(color=theme["ink-faint"], width=1, dash="dot"))
    fig.update_layout(legend=dict(orientation="h", y=1.02, x=0, yanchor="bottom"), margin=dict(l=4, r=8, t=28, b=4))
    fig.update_xaxes(tickformat="%b %-d")
    fig.update_yaxes(rangemode="tozero", title_text=unit.capitalize() + " per week")
    return fig


def dd_calendar(cal: pd.DataFrame, unit: str, theme: Theme, height: int = 230) -> go.Figure:
    """Expected units per week for the next weeks, stacked by confidence (ordinal ramp)."""
    fig = _base(theme, height)
    colors = confidence_colors(theme)
    labels = [("This week" if i == 0 else f"{w:%b} {w.day}") for i, w in enumerate(cal.index)]
    for c in ["High", "Medium", "Low"]:
        if c in cal:
            fig.add_bar(x=labels, y=cal[c], name=f"{c} confidence", marker_color=colors[c],
                        marker_line=dict(color=theme["surface"], width=1),
                        hovertemplate="%{x}<br><b>%{y:,.1f}</b> " + unit + f" expected ({c.lower()} confidence)<extra></extra>")
    fig.update_layout(barmode="stack", bargap=0.25, legend=dict(orientation="h", y=1.02, x=0, yanchor="bottom",
                                                                 traceorder="normal"),
                      margin=dict(l=4, r=8, t=28, b=4))
    fig.update_xaxes(tickangle=0)
    fig.update_yaxes(title_text=unit.capitalize())
    return fig


def dd_line_pct(df: pd.DataFrame, x: str, y: str, theme: Theme, height: int = 220, hover: str = "") -> go.Figure:
    fig = _base(theme, height)
    fig.add_scatter(x=df[x], y=df[y], mode="lines+markers", line=dict(color=theme["accent"], width=2),
                    marker=dict(size=8, color=theme["accent"], line=dict(color=theme["surface"], width=2)),
                    hovertemplate=hover or "%{x|%b %Y}: <b>%{y:.1f}%</b><extra></extra>")
    fig.update_yaxes(ticksuffix="%", rangemode="tozero")
    fig.update_xaxes(tickformat="%b")
    fig.update_layout(showlegend=False, margin=dict(l=4, r=8, t=8, b=4))
    return fig
