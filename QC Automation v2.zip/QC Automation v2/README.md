# Sell-Through Monitor

A Streamlit app for the oncology commercial team. It pulls 867 wholesaler sell-through data for
**BELEODAQ** and **RYZNEUTA** from SQL Server (`ACROTECH_HUB.POWERBI`), adds territory alignment
(team Fusion) and corporate parents from the customer master, and shows:

- week, month and fiscal-quarter-to-date performance against recent averages
- account and parent trends
- anomaly flags
- a PDF summary

## Setup (Windows)

1. **Python 3.11 – 3.13.** Check with `python --version`.
2. **ODBC Driver 18 for SQL Server** (17 also works). Search the Microsoft site for "ODBC Driver 18 for SQL Server". The app finds installed drivers on its own.
3. In this folder, create a virtual environment and install:

   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. **PDF charts.** kaleido 1.x renders charts with Chrome. If Google Chrome is installed, nothing else is needed. If not, run this once:

   ```powershell
   plotly_get_chrome
   ```
   This downloads a private Chromium into the Python environment. If Chrome can't be installed at all, the PDF is still built, with tables in place of charts and a note saying why.
5. Optional: install the IBM Plex Sans fonts from `static/` on the machine, so PDF chart labels use the same font as the app. The app itself loads the font from `static/`.

## Run

```powershell
streamlit run app.py
```

The browser opens at http://localhost:8501.

1. Go to **Connect & load** and enter the server.
2. Choose SQL Server login or Windows authentication, then **Test connection**.
3. Pick a timeframe. "Minimum for analysis" is the default.
4. Click **Load data**.

## Tests

```powershell
pytest
```

The suite has 138 tests and needs no database. It covers:

- the fiscal calendar
- cleaning and both joins, including row-count preservation
- the read-only query guard
- KPIs checked against hand calculations
- trend status and anomaly rules
- a headless run of every page on synthetic data

The tests use the attached CSV samples, which are kept in `tests/samples/`.

## Configuration (`config.py`)

| Setting | Default | Meaning |
|---|---|---|
| `ACTIVE_PRODUCTS` | BELEODAQ, RYZNEUTA | The only products the app will ever show |
| `TEAM` | Fusion | Alignment team, filtered before the zip join |
| `ALIGNMENT_FILE_ID` | `None` | `None` = latest FileID; set a value to pin one |
| `QTY_COLUMN` | `Factored_QTY` | Units on every page (Sold_Qty × Factor) |
| `LOCAL_STORE_DIR` | `data_cache` | Where the stored tables live, next to the app |
| `ALIGNMENT_STORE_MAX_AGE_DAYS` | 7 | After this many days, Connect & load asks you to update the stored tables |
| `NEW_TO_TERRITORY_DAYS` | 90 | Owners who started within this many days are "New to territory" |
| `DEFAULT_THRESHOLDS` | see file | Anomaly and trend thresholds; also adjustable in the sidebar |

## Key rules (summary of the build spec)

- **Dates and quantities.** Date = `Invoice_Date`. Units = `SUM(Factored_QTY)` (Sold_Qty × Factor), net of returns. Returns are identified by `Sale_Returns`.
  - A row with no `Factored_QTY` falls back to Sold_Qty × Factor, then `Converted_QTY`.
  - A return row with a positive quantity is made negative. Every correction is counted under Data quality → More checks → Quantity checks.
- **Stored tables.** Zip-to-territory (team Fusion, all FileIDs), customer master, roster and users are pulled once and saved in `data_cache/`. Every load reuses them.
  - After 7 days, Connect & load and the sidebar ask you to update. Loads keep using the stored copies until you click **Update stored tables**.
  - An update pulls each table in full, checks it, and only then replaces the stored copy. The previous copy is kept as `*.prev.parquet`. If a pull or check fails, the stored copy is unchanged.
  - A copy from a different server or database is never used. Custom-query mode doesn't use the stored zip-to-territory.
  - Delete `data_cache/` to force a fresh pull on the next load.
- **Roster and users.** `POWERBI_ROSTER` is the territory master. Owner = `NAME` from `POWERBI_USER`, joined on `Territory_ID`; if a territory has several users, the active one with the latest start date wins. Both tables are optional: without them, owner names are hidden.
- **Account key.** The key is `Ship_To_DEA`, falling back to `Detail_Group_ID`. If both are missing, the row is "Unidentified ship-to". The display name comes from the latest invoice.
- **Territory.** Analysis uses Region and Territory only; CAM territory is not pulled or used. 867 `Ship_To_Zip` is joined to `ZIPCode`, both normalized to 5 digits. The alignment is filtered to team Fusion and the latest FileID. It is a LEFT join; unmatched zips are labelled "Unaligned". The current alignment is applied to all history.
- **Parent.** Matching tries three keys in order: COMBO, then outlet ID (`ED_ID`), then SPOR ID. Each key maps to exactly one parent; ties go to the Corporate_Account parent, then the non-archived one, then the most frequent. A ship-to never splits across parents: the parent from its latest matched invoice wins. Conflicts are logged and downloadable.
- **Fiscal year.** It starts April 1. Apr 2026 – Mar 2027 is **FY 2026-27**, so Oct 2026 is Q3 FY 2026-27. Weeks run Monday to Sunday.
- **Safety.** Every join asserts that the 867 row count is unchanged. Queries use bound parameters only. Custom queries must be SELECT/WITH; INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, EXEC, MERGE, SELECT … INTO and similar are blocked.
- **Credentials.** They live only in the Streamlit session. The engine URL holds no password, and error messages mask it.

## Product deep dive

A page between Accounts and Report with six sections: Snapshot, Demand, Rhythm & persistence, Accounts, Forecast and Field actions. Product facts and every calculation parameter are in `config.PRODUCT_PROFILES` / `DEEP_DIVE_DEFAULTS`; all of them can be changed in **Deep dive settings** on the page.

- **Estimates.** 867 rows are account-level shipments, never patient records. Every patient, cycle and course figure carries an "Estimate" pill with its method.
- **Cycle events.** An account's orders within 7 days (Beleodaq) or 3 days (Ryzneuta) form one event; returns net into the event they fall in. Cycle-equivalents = units ÷ 20 vials (1,000 mg/m² × 1.9 m² ÷ 500 mg, rounded up, × 5 days) or ÷ 1 syringe.
- **Account regime.** Cadence (single-patient rhythm: course logic applies) or run-rate (several overlapping patients: volume only). Each account shows the reason.
- **Courses and persistence.** Cadence accounts only. A gap over 42 days (Beleodaq) or 35 days (Ryzneuta) ends a course, measured against the product's latest invoice. Persistence is a Kaplan–Meier curve with ongoing courses censored. Course starts are compared with the 867 `New_Start` flag.
- **Forecast.** Next order per account, overdue accounts, and a 13-week blend of account-by-account, exponential smoothing and seasonal-naive forecasts, weighted by a 12-week rolling backtest (WAPE).
- **Field actions.** Ranked per territory with evidence, owner (from roster + users), due date and confidence; trade/operations items are listed separately. Excel export has one tab per territory.
- **Not built yet:** RYZNEUTA target penetration and site-of-care mix (they need customer-master fields the query doesn't pull yet), and goals/attainment.
- **Charts.** No chart has two scales. The weekly chart's right axis relabels the same bars in cycles. Category mixes use a colour-blind-checked palette; status colours stay reserved for status.

## Notes on deviations from the build spec

The UI follows the Claude Design mockups. Where a mockup and Part B disagreed on visuals, the mockup wins. Where the mockups showed something Part A doesn't support, Part A wins. The cases:

**Following the mockups:**
- **Progress cards.** Connection, data-load and PDF progress use the mockups' step cards: a progress bar, plus each step's detail and time. This replaces `st.status`.
- **Filter bars.** They are white cards, not sunken bands.
- **Overview layout.** The weekly chart is a line chart. The Overview pairs it with Alerts in the left column; "Change by region" and "Change by territory" sit beside them as month-to-date lists.
- **Account alerts on the Overview.** These are new: order gaps, large returns and week-to-date spikes.

**Following Part A:**
- **Quarter labels** read "Q3 FY 2026-27", the fiscal-year label you confirmed. The mockups show "Q3 FY27".
- **Territory match** is labelled "by ship-to zip". The mockup says "by DEA number", but the alignment joins on zip.
- **The account master tile** is labelled "Customer master", the name of the source table (POWERBI_CUSTOMER_MASTER).

**Practical choices:**
- **Accounts table.** It uses Streamlit's native grid, so row selection, sorting and scrolling work. The account shows on one line as "Name – City, ST (DEA)" rather than the mockup's two lines.
- **Alert thresholds.** The settings panel opens from a button on the Accounts page header. The mockups' sidebar has no room for it.
- **Applying an alert's filter.** Geography alerts have a small filter icon that applies that alert's filter, as Part A asks.

**Other changes:**
- **Page folder.** Pages live in `app_pages/`, not `pages/`. Streamlit 1.66 shows a spurious "Page not found" dialog on deep links whenever a `pages/` folder exists next to an app that uses `st.navigation`.
- **Text colours.** In light mode, status pills and the RYZNEUTA accent use darker text variants (`--up-ink`, `--down-ink`, `--watch-ink`, `--accent-ink`). The base tokens on their tints fall below WCAG AA; for example, watch on watch-tint is 2.6:1. Fills, bars and icons keep the spec colors.
- **Captions** use `--ink-muted`. `--ink-faint` on white is 2.9:1, so it is kept for placeholders and non-text uses.
- **Account-level spikes and drops** are computed on rolling one-month periods against the previous six. They must also move at least 25% from the mean; this is adjustable.
- **Dark mode** ships. It follows the operating system setting.
- **PDF without Chrome.** If Chrome isn't available, the PDF is still built, with tables in place of charts and a note saying why. A short probe render detects this up front, so generation doesn't hang.

## Project structure

```
app.py                     entry, navigation, sidebar, theme injection
config.py                  products, team, tables, queries, thresholds
db.py                      connection, read-only guard, parameter binding
data_prep.py               cleaning, account key, names
enrichment.py              alignment and customer-master joins, conflict logs
product_engine.py          deep dive: cycle events, account regimes, courses, persistence, estimated patients
forecast.py                deep dive: next order per account, overdue, 13-week forecast + backtest, quarter landing
field_actions.py           deep dive: ranked field actions, trade/operations list, narrative
deep_dive.py               deep dive: everything the page and the PDF show for one product and selection
local_store.py             stored copies of zip-to-territory, customer master, roster and users (weekly update)
territory_people.py        roster + users: owner per territory, tenure, roster vs alignment check
fiscal_calendar.py         weeks, fiscal quarters, comparison windows
metrics.py                 KPIs, geography change, account and parent metrics
anomalies.py               spike, drop, lapsed, suspicious rules and alerts
charts.py                  Plotly figures (shared template)
pdf_report.py              PDF build (reportlab + kaleido)
ui/theme.py                tokens, product tint, Plotly template
ui/components.py           page components, skeletons, step lists, downloads
ui/compute.py              cached page computations
ui/state.py                session-state helpers
assets/styles.css          all CSS, including skeletons and motion
static/                    IBM Plex Sans (woff2 for the app, ttf for the PDF), OFL licence
app_pages/                 Connect & load, Overview, Accounts, Product deep dive, Report
tests/                     pytest suite, CSV samples (incl. RYZNEUTA, roster, users), synthetic data
data_cache/                stored tables (created on first load)
.streamlit/config.toml     theme and static file serving
```
