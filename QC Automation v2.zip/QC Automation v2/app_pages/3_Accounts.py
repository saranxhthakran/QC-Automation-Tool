"""Accounts: account / parent history, trend status, anomaly flags and drill-down."""
from __future__ import annotations

from datetime import date

import pandas as pd
import streamlit as st

import anomalies as A
import charts as C
import config
import fiscal_calendar as fc
import metrics as M
from ui import components as ui
from ui import state
from ui.compute import accounts_cached, first_time
from ui.theme import PLOTLY_CONFIG, Theme

ss = st.session_state
product = state.product()
TH = Theme.for_product(product)

if not state.has_data():
    ui.no_data_state("accounts", "Accounts")
    st.stop()

df = state.data().sales
pdf = df[df["Product"] == product]
md = pdf["Invoice_Date"].max().date() if len(pdf) else None
full_history = state.meta().get("full_history", False)

h1, h2 = st.columns([5, 1.2], vertical_alignment="bottom")
with h1:
    ui.page_header("Accounts", "Ship-to accounts and their parents: trends, flags and drill-downs.")
with h2:
    ui.threshold_popover()
if md is None:
    ui.state_card(f"No {product} sales in the pulled data.", "Widen the timeframe on Connect & load, or switch product.",
                  [{"label": "Go to Connect & load", "type": "primary", "page": "app_pages/1_Connect_and_load.py"}],
                  key="state-ac-none")
    st.stop()


# ---- Filter card (cascades Region → Territory → Parent → Account) ---------------------------
def _sync_product():
    ss["product"] = ss["ac_product"]


ss["ac_product"] = product
for k in ("ac_regions", "ac_territories", "ac_parents", "ac_accounts"):
    ui.init(k, [])
ui.init("ac_view", "Account")
q_start = max(fc.quarter_start(md), pdf["Invoice_Date"].min().date())
if not isinstance(ss.get("ac_window"), (tuple, list)) or ss.get("_ac_window_for") != (state.version(), product):
    ss["ac_window"] = (q_start, md)
    ss["_ac_window_for"] = (state.version(), product)

with st.container(key="filter-ac"):
    c = st.columns(3)
    c[0].selectbox("Product", config.ACTIVE_PRODUCTS, key="ac_product", on_change=_sync_product)
    regions_all = sorted(pdf["Region_Name"].dropna().unique())
    ss["ac_regions"] = [x for x in ss["ac_regions"] if x in regions_all]
    c[1].multiselect("Region", regions_all, key="ac_regions", placeholder="All regions")
    p1 = pdf[pdf["Region_Name"].isin(ss["ac_regions"])] if ss["ac_regions"] else pdf
    terr_all = sorted(p1["Territory_Name"].dropna().unique())
    ss["ac_territories"] = [x for x in ss["ac_territories"] if x in terr_all]
    c[2].multiselect("Territory", terr_all, key="ac_territories", placeholder="All territories")

    p2 = p1[p1["Territory_Name"].isin(ss["ac_territories"])] if ss["ac_territories"] else p1
    c = st.columns(4, vertical_alignment="bottom")
    parents_all = sorted(p2["parent_name"].dropna().unique())
    ss["ac_parents"] = [x for x in ss["ac_parents"] if x in parents_all]
    c[0].multiselect("Parent", parents_all, key="ac_parents", placeholder="All parents")
    p3 = p2[p2["parent_name"].isin(ss["ac_parents"])] if ss["ac_parents"] else p2
    acct_labels = p3.sort_values("Invoice_Date").groupby("account_key")["account_label"].last().sort_values()
    ss["ac_accounts"] = [x for x in ss["ac_accounts"] if x in acct_labels.index]
    c[1].multiselect("Account", acct_labels.index.tolist(), key="ac_accounts", placeholder="Any account",
                     format_func=lambda k: acct_labels.get(k, k))
    c[2].date_input("Date range", key="ac_window", min_value=pdf["Invoice_Date"].min().date(), max_value=md,
                    format="MM/DD/YYYY")
    view = c[3].segmented_control("Granularity", ["Account", "Parent"], key="ac_view", required=True, width="stretch")
    ui.active_filters({"ac_regions": "Region", "ac_territories": "Territory", "ac_parents": "Parent"}, "ac")

win = ss["ac_window"]
if not (isinstance(win, (tuple, list)) and len(win) == 2):
    st.markdown('<div class="t-small">Pick an end date to update the table.</div>', unsafe_allow_html=True)
    st.stop()
window = (pd.Timestamp(win[0]).date(), pd.Timestamp(win[1]).date())

# ---- Compute -------------------------------------------------------------------------------------
th = state.thresholds()
args = (state.version(), product, tuple(ss["ac_regions"]), tuple(ss["ac_territories"]),
        tuple(ss["ac_parents"]), tuple(ss["ac_accounts"]), window, tuple(sorted(th.items())))
miss = first_time(("ac",) + args)
chips_ph = st.empty()
table_ph = st.empty()
if miss:
    ui.skeleton("chips", chips_ph)
    ui.skeleton("table", table_ph, rows=10)
b = accounts_cached(*args, _df=df)


def clear_geo():
    for k in ("ac_regions", "ac_territories", "ac_parents", "ac_accounts"):
        ss[k] = []


if b.accounts.empty:
    chips_ph.empty()
    table_ph.empty()
    where = ", ".join(ss["ac_territories"] or ss["ac_parents"] or [r.title() for r in ss["ac_regions"]]) or "this selection"
    ui.state_card(f"No {product} sales in {where} for this period.", "Widen the date range or clear the filters.",
                  [{"label": "Clear filters", "type": "secondary", "on_click": clear_geo}], key="state-ac-empty")
    st.stop()

is_parent = view == "Parent"
m = b.parents if is_parent else b.accounts
label_col = "parent_name" if is_parent else "account_label"
key_col = "parent_key" if is_parent else "account_key"
noun = "parents" if is_parent else "accounts"

with chips_ph.container():
    sel_status = ui.status_filter(M.status_counts(m), f"ac_status_{view}")
mm = m if sel_status == "All" else m[m["status"] == sel_status]

STATUS_COLORS = [TH["up"], TH["ink-faint"], TH["down"], TH["watch"], TH["accent"], TH["watch"]]
FLAG_TYPES = ["Spike", "Drop", "Lapsed", "Suspicious"]


def table_frame(m: pd.DataFrame) -> pd.DataFrame:
    if is_parent:
        t = pd.DataFrame({"key": m["parent_key"].values, "Parent": m["parent_name"].values,
                          "Ship-tos": m["shiptos"].fillna(0).astype(int).values,
                          "Lapsed ship-tos": m["lapsed_shiptos"].fillna(0).astype(int).values})
    else:
        t = pd.DataFrame({"key": m["account_key"].values, "Account": m["account_label"].values,
                          "Parent": m["parent_name"].values, "Territory": m["Territory_Name"].values})
    t["Status"] = [[s] for s in m["status"]]
    t["Net units"] = m["net_units"].values
    t["Last 3 vs prior 3"] = [("" if v != v else f"{'↑' if v > 0 else '↓' if v < 0 else '→'} {v:+.1f}%")
                              for v in m["pct_3v3"].astype(float)]
    t["_pct"] = m["pct_3v3"].values
    t["Days since last order"] = m["days_since_last"].values
    t["26-week trend"] = m["spark"].values
    if is_parent:
        t["Decline pattern"] = m["decline_pattern"].values
        t["Flags"] = [[f"{n} flags"] if n > 1 else (["1 flag"] if n == 1 else []) for n in m["n_flags"]]
    else:
        fl = b.flags.groupby("account_key")["flag"].agg(lambda s: sorted(set(s), key=FLAG_TYPES.index))
        t["Flags"] = [fl.get(k, []) for k in m["account_key"]]
    t["_n_flags"] = m["n_flags"].values
    t["_lapsed"] = m["is_lapsed"].values
    return t.sort_values(["_n_flags", "Net units"], ascending=[False, False]).reset_index(drop=True)


tbl = table_frame(mm)
search = (ss.get("ac_search") or "").strip().lower()
if search:
    hay = tbl.iloc[:, 1].astype(str).str.lower() + " " + tbl["key"].astype(str).str.lower()
    tbl = tbl[hay.str.contains(search, regex=False)].reset_index(drop=True)


def _style(t: pd.DataFrame):
    vis = t.drop(columns=["_n_flags", "_lapsed", "_pct"])

    def col_pct(v):
        if v is None or v != v:
            return f"color: {TH['ink-muted']}"
        return f"color: {TH['up-ink'] if v > 0 else TH['down-ink'] if v < 0 else TH['ink-muted']}; font-weight: 600"

    pcts = t["_pct"].values
    sty = vis.style.apply(lambda s: [col_pct(v) for v in pcts], subset=["Last 3 vs prior 3"])
    lapsed = t["_lapsed"].values
    sty = sty.apply(lambda s: [f"color: {TH['down-ink']}; font-weight: 600" if l else "" for l in lapsed],
                    subset=["Days since last order"])
    sty = sty.apply(lambda s: ["font-weight: 600"] * len(s), subset=[vis.columns[1]])
    return sty


with table_ph.container(key="card-table"):
    hc1, hc2, hc3 = st.columns([3.2, 1.6, 0.6], vertical_alignment="center")
    hc1.markdown(f'<h3 class="t-card">{len(tbl):,} {noun}</h3><div class="t-sub">Sorted by flags, then net units. '
                 f'Select a row to open the {"parent" if is_parent else "account"}.</div>', unsafe_allow_html=True)
    hc2.text_input("Search", key="ac_search", placeholder=f"Search {noun} or DEA", label_visibility="collapsed",
                   icon=":material/search:")
    ui.download_csv("CSV", tbl.drop(columns=["key", "26-week trend", "_n_flags", "_lapsed", "_pct"]).assign(
        Status=lambda x: x["Status"].str[0], Flags=lambda x: x["Flags"].str.join(", ")),
        f"{product.lower()}_{noun}_{date.today():%Y%m%d}.csv", f"dl-tbl-{view}", container=hc3)
    colcfg = {
        "key": None,
        "Account": st.column_config.TextColumn(width=270, pinned=True, help="Name – City, ST (DEA or outlet ID)"),
        "Parent": st.column_config.TextColumn(width=300 if is_parent else 140, pinned=is_parent),
        "Territory": st.column_config.TextColumn(width=110),
        "Status": st.column_config.MultiselectColumn(options=config.TREND_STATUSES, color=STATUS_COLORS, width=90),
        "Net units": st.column_config.NumberColumn(format="%,.0f", help="Net of returns, selected dates", width=64),
        "Last 3 vs prior 3": st.column_config.TextColumn(help="Last 3 months vs the 3 before, net units", width=100),
        "Days since last order": st.column_config.NumberColumn("Days since", format="%d", width=72,
                                                               help="Red when overdue against the account's own cadence"),
        "26-week trend": st.column_config.LineChartColumn(y_min=0, color=TH["accent"], width=100),
        "Flags": st.column_config.MultiselectColumn(options=FLAG_TYPES + [f"{i} flags" for i in range(2, 200)] + ["1 flag"],
                                                    color=TH["watch"], width=120),
    }
    event = st.dataframe(_style(tbl), hide_index=True, column_config=colcfg, on_select="rerun",
                         selection_mode="single-row", key=f"tbl-{view}", height=470, row_height=40)
    note = f"Net units, orders and flags use invoices {fc.fmt_range(window)}."
    if not full_history:
        note += " First invoice means the first invoice within the pulled range."
    st.markdown(f'<div class="t-caption" style="display:flex;justify-content:space-between"><span>Showing {len(tbl):,} '
                f'of {len(mm):,}</span><span>{ui.E(note)}</span></div>', unsafe_allow_html=True)


# ---- Drill-down dialog -------------------------------------------------------------------------
def _stat(label, value):
    return f'<div class="stat"><div class="k">{ui.E(label)}</div><div class="v num">{ui.E(value)}</div></div>'


@st.dialog("Account drill-down", width="large")
def drilldown(key: str, parent: bool):
    sub = pdf[pdf["parent_key" if parent else "account_key"] == key]
    row = m.set_index(key_col).loc[key]
    if parent:
        title = row["parent_name"]
        loc = f"{int(row['shiptos'])} ship-tos, {int(row['active_shiptos'])} active. {row['decline_pattern']}."
        chips = ""
    else:
        title = row["account_name"]
        loc = f"{(row['account_city'] or '').title()}, {row['account_state'] or ''}  DEA {key}".strip(", ")
        loc += f"  |  Parent: {row['parent_name']} (matched by {row['match_method']})"
        chips = "".join(f'<span class="tag">{ui.E(w)}</span>' for w in str(row["main_wholesalers"]).split(", "))
    st.markdown(f'<div class="dd-head"><div class="name">{ui.E(title)}</div><div class="sub">{ui.E(loc)}</div>'
                f'<div class="chips">{ui.status_badge(row["status"])}{chips}</div></div>', unsafe_allow_html=True)
    fi = "First invoice" + ("" if full_history else " (in range)")
    st.markdown('<div class="stats4">'
                + _stat(fi, fc.fmt_date(row["first_invoice"]))
                + _stat("Last invoice", fc.fmt_date(row["last_invoice"]))
                + _stat("Average order size", f"{row['avg_order_size']:,.1f} units" if pd.notna(row["avg_order_size"]) else "—")
                + _stat("Average days between orders",
                        f"{row['avg_days_between']:,.0f} days" if pd.notna(row["avg_days_between"]) else "—")
                + "</div>", unsafe_allow_html=True)
    first = sub["Invoice_Date"].min().date()
    n_weeks = max(4, (fc.week_start(md) - fc.week_start(first)).days // 7 + 1)
    weekly = M.weekly_series(sub, md, n_weeks)
    an = A.series_anomalies(weekly, n_roll=int(th["rolling_periods"]), k=th["sd_multiplier"],
                            consecutive=int(th["consecutive_declines"]))
    ui.card_head("Full history", "Weekly net units; rings mark unusual weeks")
    st.plotly_chart(C.account_history(weekly, an, TH, 240), theme=None, config=PLOTLY_CONFIG, key="dd-hist")
    a, bcol = st.columns(2)
    with a:
        ui.card_head("Monthly purchases and returns")
        st.plotly_chart(C.monthly_bars(M.monthly_series(sub), TH, 220), theme=None, config=PLOTLY_CONFIG, key="dd-month")
    with bcol:
        ui.card_head("Days between orders")
        st.plotly_chart(C.order_intervals(M.order_table(sub, "account_key"), row.get("typical_interval"), TH, 220),
                        theme=None, config=PLOTLY_CONFIG, key="dd-int")
    fl = b.flags[b.flags["account_key"].isin(sub["account_key"].unique())]
    ui.card_head("Why it was flagged", f"{len(fl)} flags in the selected dates")
    if fl.empty:
        st.markdown('<div class="t-small">No flags in the selected dates.</div>', unsafe_allow_html=True)
    else:
        names = pdf.drop_duplicates("account_key").set_index("account_key")["account_name"]
        items = "".join(
            f'<li><span><span class="tag {ui.E(r.severity)}">{ui.E(r.flag)}</span></span><span>'
            + (f"<b>{ui.E(names.get(r.account_key, r.account_key))}</b>: " if parent else "")
            + f"{ui.E(r.reason)}</span></li>" for r in fl.head(60).itertuples())
        st.markdown(f'<ul class="flag-list">{items}</ul>', unsafe_allow_html=True)
    if parent:
        ui.card_head("Ship-tos")
        kids = b.accounts[b.accounts["parent_key"] == key][["account_label", "status", "net_units", "pct_3v3",
                                                            "days_since_last", "flags"]]
        st.dataframe(kids.rename(columns={"account_label": "Account", "status": "Status", "net_units": "Net units",
                                          "pct_3v3": "Last 3 vs prior 3", "days_since_last": "Days since order",
                                          "flags": "Flags"}),
                     hide_index=True, column_config={"Last 3 vs prior 3": st.column_config.NumberColumn(format="%+.1f%%"),
                                                     "Net units": st.column_config.NumberColumn(format="%,.0f")})


rows = event.selection.rows if event and hasattr(event, "selection") else []
if rows:
    sel_key = tbl.loc[rows[0], "key"]
    marker = (view, sel_key, state.version())
    if ss.get("_dd_open") != marker:
        ss["_dd_open"] = marker
        drilldown(sel_key, is_parent)
else:
    ss.pop("_dd_open", None)

# ---- Top movers ----------------------------------------------------------------------------------
st.write("")
name_col = "parent_name" if is_parent else "account_name"
g, d = M.top_movers(m, name_col, 10)
sub_col = None if is_parent else "Territory_Name"
if not is_parent:
    terr = m.set_index("account_name")["Territory_Name"].to_dict()
    g["Territory_Name"] = g["account_name"].map(terr)
    d["Territory_Name"] = d["account_name"].map(terr)
c1, c2 = st.columns(2, gap="medium")
with c1.container(key="card-grow"):
    ui.card_head("Top 10 growing", "Last 3 months vs prior 3, by change in units")
    st.markdown(ui.top_list_html(g, name_col, sub_col, "up"), unsafe_allow_html=True)
with c2.container(key="card-decl"):
    ui.card_head("Top 10 declining", "Last 3 months vs prior 3, by change in units")
    st.markdown(ui.top_list_html(d, name_col, sub_col, "down"), unsafe_allow_html=True)

# ---- Units by month ------------------------------------------------------------------------------
st.write("")
with st.container(key="card-heat"):
    h_start = fc.add_months(fc.month_start(md), -11)
    sel = pdf[pdf[key_col].isin(mm[key_col])]
    lbl = m.set_index(key_col)[name_col]
    h = M.month_heatmap(sel, key_col, lbl, (h_start, md), 12)
    if len(h):
        h.columns = [c[:3] for c in h.columns]
    vmax = float(h.values.max()) if len(h) else 0
    ui.card_head("Units by month", f"Top 12 {noun} by net units, {fc.fmt_date(h_start)} to {fc.fmt_date(md)}",
                 right=ui.heatmap_legend_html(vmax, TH))
    st.markdown(ui.heatmap_html(h, TH), unsafe_allow_html=True)
