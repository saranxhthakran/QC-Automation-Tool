"""Report: build a PDF summarizing the Overview and Accounts pages."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
import streamlit as st

import config
import fiscal_calendar as fc
import pdf_report as P
from ui import components as ui
from ui import state

ss = st.session_state
product = state.product()

if not state.has_data():
    ui.no_data_state("report", "Report")
    st.stop()

if ss.get("_toast_pdf"):
    st.toast(ss.pop("_toast_pdf"), icon=":material/check_circle:")

ui.page_header("Report", "A landscape PDF of the Overview and Accounts pages, in the app's palette and type.")
st.write("")
data = state.data()
left, right = st.columns([1, 1], gap="medium")

with left.container(key="card-options"):
    ui.card_head("Options", "What goes into the PDF")
    ui.init("rep_scope", "Current product")
    scope = st.segmented_control("Scope", ["Current product", "Both products"], key="rep_scope", required=True)
    ui.init("rep_sections", ["Overview", "Accounts", "Product deep dive", "Data-quality appendix"])
    sections = st.pills("Sections", ["Overview", "Accounts", "Product deep dive", "Data-quality appendix"],
                        selection_mode="multi", key="rep_sections")
    products = [product] if scope == "Current product" else list(config.ACTIVE_PRODUCTS)

    win = ss.get("ac_window")
    of = {"regions": tuple(ss.get("ov_regions", [])), "territories": tuple(ss.get("ov_territories", [])),
          "same_weekdays": bool(ss.get("same_weekdays", True))}
    af = {"regions": tuple(ss.get("ac_regions", [])), "territories": tuple(ss.get("ac_territories", [])),
          "parents": tuple(ss.get("ac_parents", [])),
          "accounts": tuple(ss.get("ac_accounts", [])),
          "window": tuple(win) if isinstance(win, (tuple, list)) and len(win) == 2 and scope == "Current product" else (None, None)}
    dates = (fc.fmt_range(tuple(fc.to_date(x) for x in af["window"])) if af["window"][0]
             else "current fiscal quarter to date")
    st.markdown('<div class="divider"></div><div class="t-label">Filters carried over from the other pages</div>'
                f'<div class="t-small"><b>Overview:</b> {ui.E(P._filters_text(of))}; '
                f'{"same weekdays" if of["same_weekdays"] else "full weeks"}</div>'
                f'<div class="t-small"><b>Accounts:</b> {ui.E(P._filters_text(af))}; dates {ui.E(dates)}</div>'
                f'<div class="t-small"><b>Product deep dive:</b> {ui.E(P._filters_text({k: ss.get("pdd_" + k, []) for k in ("regions", "territories", "parents", "accounts")}))}</div>',
                unsafe_allow_html=True)
    if scope == "Both products":
        ui.note("Each product gets its own overview, anchored on its own latest invoice. Account dates default to "
                "each product's current fiscal quarter.", "info")

with right.container(key="card-outline"):
    ui.card_head("Outline", "Pages in the PDF")
    pages = [("Cover", "Title, generation time, timeframe, data mode, load date, filters"),
             ("Summary", "3–5 sentences generated from the numbers, per product")]
    for p in products:
        if "Overview" in (sections or []):
            pages.append((f"{p} overview", "KPI table, weekly trend, region and territory change, alerts"))
        if "Accounts" in (sections or []):
            pages.append((f"{p} accounts", "Status counts, top 10 growing and declining, flagged accounts"))
        if "Product deep dive" in (sections or []):
            pages.append((f"{p} deep dive", "This week's narrative, snapshot, forecast, persistence, top field actions"))
    if "Data-quality appendix" in (sections or []):
        pages.append(("Appendix", "Alignment and customer-master match rates"))
    items = "".join(f'<div class="page"><div class="thumb"></div><div><div class="pt">{ui.E(t)}</div>'
                    f'<div class="pd">{ui.E(d)}</div></div></div>' for t, d in pages)
    st.markdown(f'<div class="outline">{items}</div>', unsafe_allow_html=True)

st.write("")
gen = st.button("Generate PDF", type="primary", key="btn-pdf", disabled=not sections)
prog_ph = st.empty()
if gen:
    pw = ss.get("pdd_window")
    ddf = {"regions": tuple(ss.get("pdd_regions", [])), "territories": tuple(ss.get("pdd_territories", [])),
           "parents": tuple(ss.get("pdd_parents", [])),
           "accounts": tuple(ss.get("pdd_accounts", [])),
           "history_start": (pd.Timestamp(pw[0]) if isinstance(pw, (tuple, list)) and len(pw) == 2
                             and scope == "Current product" else None)}
    opts = P.ReportOptions(products=products, include_overview="Overview" in sections,
                           include_accounts="Accounts" in sections,
                           include_deep_dive="Product deep dive" in sections, deep_dive_filters=ddf,
                           deep_dive_settings=dict(ss.get("pdd_settings", {})),
                           include_appendix="Data-quality appendix" in sections, overview_filters=of,
                           account_filters=af, thresholds=state.thresholds(), data_meta=state.meta())
    card = ui.ProgressCard("Generating PDF", ["Building summary", "Rendering charts", "Laying out pages", "Finishing"],
                           prog_ph)
    prev = {"i": -1, "t": 0.0}
    import time

    def progress(i):
        now = time.perf_counter()
        if prev["i"] >= 0:
            card.done(prev["i"], "", now - prev["t"])
        card.start(i)
        prev.update(i=i, t=now)

    try:
        pdf, notes = P.build_pdf(data, opts, progress)
        card.done(prev["i"], "", time.perf_counter() - prev["t"])
        name = f"sell_through_{'_'.join(p.lower() for p in products)}_{datetime.now():%Y%m%d_%H%M}.pdf"
        ss["_pdf"] = (pdf, name, notes)
        ss["_toast_pdf"] = "PDF ready"
        st.rerun()
    except Exception as exc:  # noqa: BLE001
        i = card.running_index()
        if i is not None:
            card.fail(i, str(exc)[:300])
        ui.error_state(f"The PDF couldn't be built: {str(exc)[:300]}",
                       "Try again; if it repeats, generate with fewer sections and share the message with the app owner.")

if ss.get("_pdf"):
    pdf, name, notes = ss["_pdf"]
    with st.container(key="card-pdf"):
        c1, c2 = st.columns([5, 1.3], vertical_alignment="center")
        c1.markdown(f'<div class="file-card"><div class="file-ic">PDF</div><div><div class="t1">{ui.E(name)}</div>'
                    f'<div class="t2">{len(pdf) / 1024:,.0f} KB, ready to download</div></div></div>',
                    unsafe_allow_html=True)
        c2.download_button("Download PDF", data=pdf, file_name=name, mime="application/pdf", icon=":material/download:",
                           key="dl-pdf", on_click="ignore", type="primary", width="stretch")
        for n in notes:
            ui.note(n, "watch")
