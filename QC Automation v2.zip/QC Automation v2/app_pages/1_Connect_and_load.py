"""Connect & load: connection, timeframe, data pull, enrichment and data-quality summary."""
from __future__ import annotations

import time
import uuid
from datetime import date, datetime, timedelta

import pandas as pd
import streamlit as st

import config
import db
import enrichment as en
import fiscal_calendar as fc
import local_store as ls
from data_prep import apply_column_mapping, guess_mapping, prepare_sales
from ui import components as ui
from ui import state
from ui.compute import cached_query, fingerprint
from ui.theme import Theme

ss = st.session_state
TH = Theme.for_product(state.product())
AUTH_OPTS = ["SQL Server authentication", "Windows authentication"]

if ss.get("_toast"):
    st.toast(ss.pop("_toast"), icon=":material/check_circle:")

ui.page_header("Connect & load", "Sign in to the data hub, choose how much history to pull, then load.")


# =============================================================================
# Timeframe (computed up front so collapsed cards and the stepper can use it)
# =============================================================================
def timeframe() -> tuple[date | None, date | None, date | None, str]:
    """(start, end, anchor, preset) from session state."""
    anchors = ss.get("anchors")
    if anchors is None or anchors.empty or anchors["MaxDate"].dropna().empty:
        return None, None, None, ""
    valid = anchors["MaxDate"].dropna()
    anchor = valid.min().date()
    preset = ss.get("tf_preset", config.TIMEFRAME_PRESETS[0])
    if preset == "Custom range":
        rng = ss.get("tf_custom")
        if isinstance(rng, (tuple, list)) and len(rng) == 2:
            return pd.Timestamp(rng[0]).date(), pd.Timestamp(rng[1]).date(), anchor, preset
        return None, None, anchor, preset
    s, e = fc.preset_range(preset, anchor, date.today(), config.HISTORY_START_YEAR)
    return s, max(e, valid.max().date()), anchor, preset


connected = state.connected()
start, end, anchor, preset = timeframe()
has_data = state.has_data()
step2_done = connected and start is not None and end is not None
collapse1 = has_data and connected and not ss.get("_edit_connect")
collapse2 = has_data and step2_done and not ss.get("_edit_tf")

conn_sub = ss["conn_params"].database if connected else "Server and credentials"
tf_sub = preset if step2_done else "History to pull"
load_sub = (f"{len(state.data().sales):,} rows" if has_data else "Ready to load" if step2_done else "Pull, match and check")
st.markdown(ui.stepper_html([
    ("Connect", conn_sub, "done" if connected else "current"),
    ("Choose timeframe", tf_sub, "done" if step2_done else "current" if connected else "todo"),
    ("Load data", load_sub, "done" if has_data else "current" if step2_done else "todo"),
]), unsafe_allow_html=True)


# =============================================================================
# Step 1: Connect
# =============================================================================
def run_connection(params: db.ConnectionParams, ph) -> None:
    for k in ["connected", "engine", "schema", "date_is_text", "align_summary", "align_warnings", "anchors",
              "_conn_error", "_conn_ok", "align_store_meta", "ref_store_meta", "_store_errors"]:
        ss.pop(k, None)
    card = ui.ProgressCard("Checking the connection", ["Connecting to server", "Checking tables", "Reading column types",
                                                       "Checking territory alignment"], ph)
    t_all = time.perf_counter()
    try:
        card.start(0)
        t0 = time.perf_counter()
        engine = db.create_engine(params)
        db.run_query(engine, "SELECT 1 AS ok")
        card.done(0, params.server, time.perf_counter() - t0)

        card.start(1)
        t0 = time.perf_counter()
        schema = db.read_schema(engine, params.database)
        missing = [t for t in config.ALL_TABLES if not schema.get(t)]
        if missing:
            card.fail(1, f"Missing in {params.database}.{config.SCHEMA}: {', '.join(missing)}")
            ss["_conn_error"] = (f"Connected, but these tables weren't found in {params.database}.{config.SCHEMA}: "
                                 f"{', '.join(missing)}.", "Check the database name, or ask for read access to the POWERBI schema.")
            return
        card.done(1, f"{len(config.ALL_TABLES)} of {len(config.ALL_TABLES)} found", time.perf_counter() - t0)

        card.start(2)
        t0 = time.perf_counter()
        is_text = db.invoice_date_is_text(schema)
        card.done(2, f"Invoice_Date is {schema[config.TABLE_867].get('Invoice_Date', '?')}", time.perf_counter() - t0)

        card.start(3)
        t0 = time.perf_counter()
        stored = ls.load(ls.ALIGNMENT, ls.source_id(params.server, params.database))
        if stored is not None:
            summ = ls.alignment_summary(stored.df)
            detail = f"Stored copy, {ls.describe(stored.meta)}"
        else:
            summ = db.run_query(engine, config.alignment_check_query(params.database))
            detail = f"{len(summ)} team/FileID groups; no stored copy yet"
        warns = en.check_alignment_summary(summ, config.TEAM)
        card.done(3, detail, time.perf_counter() - t0)
    except Exception as exc:  # noqa: BLE001
        what, how = db.friendly_error(exc, params)
        i = card.running_index()
        if i is not None:
            card.fail(i, what)
        ss["_conn_error"] = (what, how)
        return
    ss.update(conn_params=params, engine=engine, schema=schema, date_is_text=is_text, align_summary=summ,
              align_warnings=warns, connected=True, _edit_connect=False,
              align_store_meta=stored.meta if stored is not None else None,
              ref_store_meta={n: m for n in ls.REFERENCE_TABLES
                              if (m := ls.read_meta(n)) and m.get("source") == ls.source_id(params.server, params.database)},
              _conn_ok=f"Connected in {time.perf_counter() - t_all:.1f}s. {len(config.ALL_TABLES)} of "
                       f"{len(config.ALL_TABLES)} tables found.")
    card.clear()
    st.rerun()


def edit_connect():
    ss["_edit_connect"] = True


if collapse1:
    p = ss["conn_params"]
    who = "Windows authentication" if p.auth == "Windows" else f"as {p.username}"
    ui.done_card("connect", f"1. Connected to {p.database}", f"{p.server} {who}, {p.driver}", edit_connect)
else:
    drivers = db.available_drivers()
    if ss.get("cl_auth") not in AUTH_OPTS:
        ss["cl_auth"] = AUTH_OPTS[0]
    ui.init("cl_database", config.DEFAULT_DATABASE)
    ui.init("cl_trust", True)
    with st.container(key="card-connect"):
        chip = f'<span class="ok-chip">{ui.ICONS["check"]}Connected</span>' if connected else ""
        ui.card_head("1. Connect", "SQL Server credentials for the commercial data hub", right=chip)
        if ss.get("_conn_error"):
            ui.error_state(*ss["_conn_error"])
        if not drivers:
            ui.error_state("No SQL Server ODBC driver found on this computer.",
                           "Install ODBC Driver 18 for SQL Server, then reload this page.")
        left, right = st.columns(2, gap="medium")
        with left:
            with st.container(key="cl-mono-1"):
                st.text_input("Server", key="cl_server", placeholder="sql-prod-02.acrotech.local")
                st.text_input("Database", key="cl_database")
            if drivers:
                st.selectbox("ODBC driver", drivers, key="cl_driver")
            else:
                st.selectbox("ODBC driver", ["No driver found"], disabled=True, key="cl_driver_none")
        with right:
            auth = st.selectbox("Authentication type", AUTH_OPTS, key="cl_auth")
            win = auth.startswith("Windows")
            st.text_input("Username", key="cl_username", disabled=win)
            st.text_input("Password", key="cl_password", type="password", disabled=win)
        st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
        b1, b2, b3 = st.columns([1.2, 4, 1.6], vertical_alignment="center")
        test = b1.button("Test connection", disabled=not drivers, key="btn-test")
        if connected and ss.get("_conn_ok"):
            b2.markdown(f'<span class="foot-note">{ui.E(ss["_conn_ok"])}</span>', unsafe_allow_html=True)
        b3.checkbox("Trust server certificate", key="cl_trust",
                    help="Needed for most internal servers without a public certificate (ODBC Driver 18 encrypts by default).")
        if connected:
            with st.expander("Territory alignment check"):
                if ss.get("align_store_meta"):
                    st.markdown(f'<div class="t-small">From the stored zip-to-territory copy, '
                                f'{ui.E(ls.describe(ss["align_store_meta"]))}.</div>', unsafe_allow_html=True)
                else:
                    st.code(config.alignment_check_query(ss["conn_params"].database), language="sql")
                if ss.get("align_summary") is not None:
                    st.dataframe(ss["align_summary"], hide_index=True, width="content")
            for w in ss.get("align_warnings", []):
                ui.note(w, "watch")
    conn_ph = st.empty()
    if test:
        server = (ss.get("cl_server") or "").strip()
        database = (ss.get("cl_database") or config.DEFAULT_DATABASE).strip()
        if not server:
            ss["_conn_error"] = ("Enter a server name to connect.",
                                 "Use the SQL Server host name, optionally with \\INSTANCE or ,port.")
            st.rerun()
        elif not win and not (ss.get("cl_username") and ss.get("cl_password")):
            ss["_conn_error"] = ("Enter a username and password, or switch to Windows authentication.", "")
            st.rerun()
        else:
            try:
                config.safe_identifier(database)
                params = db.ConnectionParams(server=server, database=database, auth="Windows" if win else "SQL Server login",
                                             username="" if win else ss.get("cl_username", ""),
                                             password="" if win else ss.get("cl_password", ""),
                                             driver=ss.get("cl_driver", drivers[0] if drivers else ""),
                                             trust_server_certificate=bool(ss.get("cl_trust", True)))
                run_connection(params, conn_ph)
                st.rerun()
            except ValueError as exc:
                ss["_conn_error"] = (str(exc), "Database names can contain letters, numbers and underscores.")
                st.rerun()


# =============================================================================
# Step 2: Choose timeframe
# =============================================================================
def edit_tf():
    ss["_edit_tf"] = True


if connected and ss.get("anchors") is None:
    try:
        q = config.anchor_query(ss["conn_params"].database, ss.get("date_is_text", False))
        with st.spinner("Finding latest invoice dates"):
            anchors = cached_query(fingerprint(), q, tuple(config.ACTIVE_PRODUCTS), ss["engine"])
        anchors["MaxDate"] = pd.to_datetime(anchors["MaxDate"], errors="coerce")
        anchors["LoadDate"] = pd.to_datetime(anchors["LoadDate"], errors="coerce")
        ss["anchors"] = anchors
        st.rerun()
    except Exception as exc:  # noqa: BLE001
        what, how = db.friendly_error(exc, ss["conn_params"])
        ui.error_state(f"Couldn't read the latest invoice dates: {what}", how)

if collapse2:
    weeks = ((end - start).days + 1) // 7
    ui.done_card("tf", f"2. Timeframe: {preset}", f"{fc.fmt_date(start)} – {fc.fmt_date(end)}, {weeks} weeks", edit_tf)
else:
    with st.container(key="card-timeframe"):
        ui.card_head("2. Choose timeframe", "How much invoice history to pull")
        anchors = ss.get("anchors")
        if not connected or anchors is None:
            st.markdown('<div class="t-small">Connect first to see each product’s latest invoice date.</div>',
                        unsafe_allow_html=True)
        else:
            chips = []
            for p in config.ACTIVE_PRODUCTS:
                t = Theme.for_product(p)
                row = anchors[anchors["Product"].str.upper() == p]
                val = "no sales found" if row.empty or pd.isna(row["MaxDate"].iloc[0]) else ui.fmt_md(row["MaxDate"].iloc[0]) + f", {row['MaxDate'].iloc[0].year}"
                chips.append(f'<span class="lp-chip" style="background:{t["accent-tint"]};color:{t["accent-ink"]}">'
                             f'<span class="sw" style="background:{t["accent"]}"></span><b>{p}</b> {ui.E(val)}</span>')
            st.markdown(f'<div class="lp-chips"><span class="t-label">Latest invoice</span>{"".join(chips)}</div>',
                        unsafe_allow_html=True)
            for p in config.ACTIVE_PRODUCTS:
                if p not in set(anchors["Product"].str.upper()):
                    ui.note(f"No {p} rows were found in POWERBI_867.", "watch")
            if anchor is None:
                ui.error_state("Neither product has any sales in POWERBI_867.",
                               "Check that the Product column uses the names BELEODAQ and RYZNEUTA.")
            else:
                ui.init("tf_preset", config.TIMEFRAME_PRESETS[0])
                with st.container(key="tf-presets"):
                    st.pills("Timeframe", config.TIMEFRAME_PRESETS, key="tf_preset", required=True)
                if ss["tf_preset"] == "Custom range":
                    ui.init("tf_custom", (fc.minimum_analysis_start(anchor), anchors["MaxDate"].dropna().max().date()))
                    st.date_input("Custom range", key="tf_custom", min_value=date(config.HISTORY_START_YEAR, 1, 1),
                                  max_value=date.today(), format="MM/DD/YYYY")
                start, end, anchor, preset = timeframe()
                if start and end:
                    weeks = ((end - start).days + 1) // 7
                    st.markdown(f'<div class="kv"><div><div class="k">Range</div><div class="v num">{fc.fmt_date(start)} – '
                                f'{fc.fmt_date(end)}</div></div><div><div class="k">Span</div><div class="v num">{weeks} weeks'
                                f'</div></div></div>', unsafe_allow_html=True)
                    warns = fc.range_warnings(start, end, anchor)
                    if preset == "Minimum for analysis":
                        ui.note("This is the shortest range that fills every comparison: 13 weeks, 3 months and 3 fiscal "
                                f"quarters. Account trends and the heatmap will only cover these {weeks} weeks.", "watch")
                    elif warns:
                        ui.note("This range leaves some metrics incomplete. " + " ".join(warns), "watch")
                    if not preset.startswith("Full history"):
                        ui.note("Account first-invoice dates are only accurate with Full history; with this range they "
                                "show as first invoice within the pulled range.", "info")
                else:
                    st.markdown('<div class="t-small">Pick an end date.</div>', unsafe_allow_html=True)
        if has_data and ss.get("_edit_tf"):
            st.button("Done", key="tf-done", type="secondary", on_click=lambda: ss.update(_edit_tf=False))

step2_done = connected and start is not None and end is not None


# =============================================================================
# Step 3: Load data
# =============================================================================
def default_queries(database: str, s: date, e: date) -> list[tuple[str, str, tuple]]:
    is_text = ss.get("date_is_text", False)
    return [
        ("Sales (POWERBI_867)", config.sales_query(database, is_text), (s, e, *config.ACTIVE_PRODUCTS)),
        ("Territory alignment (POWERBI_ZIPTOTERR)", config.alignment_query(database), (config.TEAM,)),
        ("Customer master (POWERBI_CUSTOMER_MASTER)", config.customer_master_query(database), ()),
    ]


# ----- Reference tables (zip-to-territory, customer master, roster, users): stored locally, updated on request ---
def store_source() -> str:
    p = ss["conn_params"]
    return ls.source_id(p.server, p.database)


def _remember(name: str, stored: ls.StoredTable) -> None:
    ss.setdefault("ref_store_meta", {})[name] = stored.meta
    if name == ls.ALIGNMENT:
        ss["align_store_meta"] = stored.meta
        ss["align_summary"] = ls.alignment_summary(stored.df)
        ss["align_warnings"] = en.check_alignment_summary(ss["align_summary"], config.TEAM)


def table_available(name: str) -> bool:
    """Optional tables (roster, users) are skipped when the schema check didn't find them."""
    rt = ls.REFERENCE_TABLES[name]
    return rt.required or bool(ss.get("schema", {}).get(rt.table))


def pull_reference(name: str, engine, database: str) -> pd.DataFrame:
    """Full pull straight from the database (never the query cache)."""
    sql, params = ls.reference_query(name, database)
    return db.run_query(engine, sql, params)


def get_reference(name: str, engine, database: str) -> tuple[pd.DataFrame | None, str]:
    """The stored copy if there is one (even when it's due for an update); otherwise pull and store it."""
    rt = ls.REFERENCE_TABLES[name]
    errs = ss.setdefault("_store_errors", {})
    if not table_available(name):
        return None, f"{rt.table} not found; skipped"
    stored = ls.load(name, store_source())
    if stored is not None:
        _remember(name, stored)
        return stored.df, f"Stored copy, {ls.describe(stored.meta)}"
    df = pull_reference(name, engine, database)
    try:
        stored = ls.save(name, df, store_source(), ls.table_meta(name, df), lambda d: ls.validate(name, d))
    except ls.StoreError as exc:
        # Nothing stored yet: use this pull for this session and say why it wasn't saved.
        errs[name] = str(exc)
        return df, f"{len(df):,} rows (not saved: {exc})"
    errs.pop(name, None)
    _remember(name, stored)
    return stored.df, f"{len(df):,} rows pulled and saved locally"


def update_references(ph) -> bool:
    """Full pull → check → replace each stored copy (old copy kept as backup). A copy that fails stays as it was."""
    params, engine = ss["conn_params"], ss["engine"]
    names = [n for n in ls.REFERENCE_TABLES if table_available(n)]
    labels = [f"{ls.REFERENCE_TABLES[n].label}: full pull and check" for n in names]
    card = ui.ProgressCard("Updating stored tables", labels, ph)
    failed = []
    for i, name in enumerate(names):
        rt = ls.REFERENCE_TABLES[name]
        t = time.perf_counter()
        card.start(i)
        try:
            df = pull_reference(name, engine, params.database)
            stored = ls.save(name, df, store_source(), ls.table_meta(name, df), lambda d, n=name: ls.validate(n, d))
        except ls.StoreError as exc:
            card.fail(i, f"{exc} The stored copy is unchanged.")
            failed.append(rt.label)
            continue
        except Exception as exc:  # noqa: BLE001
            what, _ = db.friendly_error(exc, params)
            card.fail(i, f"{what} The stored copy is unchanged.")
            failed.append(rt.label)
            continue
        ss.setdefault("_store_errors", {}).pop(name, None)
        _remember(name, stored)
        card.done(i, f"{len(df):,} rows, stored copy replaced", time.perf_counter() - t)
    if failed:
        ui.error_state(f"Not updated: {', '.join(failed)}.", "Their stored copies are unchanged. Try again later.")
    return not failed


def load_people(roster_df, user_df, alignment_table):
    """Owners per territory from the roster and user tables (None-safe)."""
    import territory_people as tp

    if roster_df is None:
        return tp.unavailable("The roster table isn't available, so owner names are hidden.")
    return tp.build_owners(roster_df, user_df, date.today(), alignment_table)


def finish_load(sales_raw, align_raw, cm_raw, card: ui.ProgressCard, i0: int, mode: str, s, e, sqls, t_all,
                roster_raw=None, user_raw=None):
    t = time.perf_counter()
    card.start(i0)
    sales, info = prepare_sales(sales_raw)
    al = en.prepare_alignment(align_raw, config.TEAM, config.ALIGNMENT_FILE_ID)
    sales = en.apply_alignment(sales, al)
    card.done(i0, f"{int(sales['aligned'].sum()):,} of {len(sales):,} rows aligned", time.perf_counter() - t)

    t = time.perf_counter()
    card.start(i0 + 1)
    pm = en.match_parents(sales, cm_raw)
    mapped = int((pm.shipto_parents["method"] != config.UNMAPPED).sum())
    card.done(i0 + 1, f"{mapped:,} of {len(pm.shipto_parents):,} ship-tos", time.perf_counter() - t)

    t = time.perf_counter()
    card.start(i0 + 2)
    ps, pdt = en.ptcl_crosscheck(pm.sales)
    data = en.EnrichedData(pm.sales, al, pm, info, ps, pdt)
    if mode != "Default" and roster_raw is None:
        # Custom queries: use the stored roster and user copies if there are any (no pull).
        r_, u_ = ls.load(ls.ROSTER, store_source()), ls.load(ls.USER, store_source())
        roster_raw, user_raw = (r_.df if r_ else None), (u_.df if u_ else None)
    try:
        data.people = load_people(roster_raw, user_raw, al.table)
    except Exception as exc:  # noqa: BLE001 - owners are optional; never block a load
        import territory_people as tp
        data.people = tp.unavailable(f"Owner names are hidden: the roster or user table couldn't be read ({exc}).")
    q = data.quality()
    card.done(i0 + 2, f"{q['rows']:,} rows, {q['accounts']:,} accounts", time.perf_counter() - t)
    ss["data"] = data
    ss["data_meta"] = {"mode": mode, "start": s, "end": e, "preset": ss.get("tf_preset"),
                       "loaded_at": datetime.now().isoformat(timespec="seconds"), "sql": sqls,
                       "file_id": al.file_id, "full_history": str(ss.get("tf_preset", "")).startswith("Full history"),
                       "alignment_stored": (ss.get("align_store_meta") if mode == "Default" else None),
                       "reference_stored": dict(ss.get("ref_store_meta", {}))}
    ss["data_version"] = uuid.uuid4().hex
    ss["_load_msg"] = f"Loaded {q['rows']:,} sales rows in {time.perf_counter() - t_all:.1f}s"
    ss["_toast"] = "Data loaded"
    ss["_edit_connect"] = ss["_edit_tf"] = False
    ss.pop("_computed_keys", None)


def load_default(s: date, e: date, ph) -> bool:
    params, engine = ss["conn_params"], ss["engine"]
    labels = ["Finding latest invoice dates", "Pulling sales data", "Loading zip-to-territory",
              "Loading customer master", "Loading roster and users", "Matching territories", "Matching parents",
              "Running checks"]
    card = ui.ProgressCard("Loading data", labels, ph)
    t_all = time.perf_counter()
    try:
        t = time.perf_counter()
        card.start(0)
        anc = cached_query(fingerprint(), config.anchor_query(params.database, ss.get("date_is_text", False)),
                           tuple(config.ACTIVE_PRODUCTS), engine)
        card.done(0, f"{len(anc)} products", time.perf_counter() - t)
        frames = []
        for i, (name, sql, p) in enumerate(default_queries(params.database, s, e), start=1):
            t = time.perf_counter()
            card.start(i)
            ref = {config.alignment_query(params.database): ls.ALIGNMENT,
                   config.customer_master_query(params.database): ls.CUSTOMER_MASTER}.get(sql)
            if ref:
                df_, detail = get_reference(ref, engine, params.database)
                frames.append(df_)
                card.done(i, detail, time.perf_counter() - t)
                continue
            frames.append(cached_query(fingerprint(), sql, p, engine))
            card.done(i, f"{len(frames[-1]):,} rows", time.perf_counter() - t)
        t = time.perf_counter()
        card.start(4)
        people_frames, notes = [], []
        for name in (ls.ROSTER, ls.USER):
            try:
                df_, detail = get_reference(name, engine, params.database)
            except Exception as exc:  # noqa: BLE001 - optional tables never block a load
                df_, detail = None, f"couldn't be read ({db.friendly_error(exc, params)[0]})"
            people_frames.append(df_)
            notes.append(f"{ls.REFERENCE_TABLES[name].label}: {detail}")
        card.done(4, "; ".join(notes), time.perf_counter() - t)
        finish_load(frames[0], frames[1], frames[2], card, 5, "Default", s, e,
                    [(n, q, [str(x) for x in p]) for n, q, p in default_queries(params.database, s, e)], t_all,
                    roster_raw=people_frames[0], user_raw=people_frames[1])
        return True
    except en.JoinCheckError as exc:
        card.fail(card.running_index() or 5, str(exc))
        ui.error_state(str(exc), "Fix the duplicated zips in POWERBI_ZIPTOTERR, then load again.")
        if len(exc.detail):
            st.dataframe(exc.detail, hide_index=True)
    except Exception as exc:  # noqa: BLE001
        what, how = db.friendly_error(exc, params)
        i = card.running_index()
        if i is not None:
            card.fail(i, what)
        ui.error_state(what, how)
    return False


# ----- Custom queries -----------------------------------------------------------------
def _new_query(name: str = "", sql: str = "") -> dict:
    return {"id": uuid.uuid4().hex[:8], "name": name or f"query_{len(ss.get('custom_queries', [])) + 1}", "sql": sql}


def custom_mode(s: date, e: date) -> None:
    queries = ss.setdefault("custom_queries", [_new_query()])
    results: dict = ss.setdefault("custom_results", {})

    def remove(qid):
        ss["custom_queries"] = [q for q in ss["custom_queries"] if q["id"] != qid]
        results.pop(qid, None)

    for q in queries:
        with st.container(key=f"inner-q-{q['id']}"):
            c1, c2, c3 = st.columns([2.2, 3, 1], vertical_alignment="bottom")
            q["name"] = c1.text_input("Query name", value=q["name"], key=f"qname-{q['id']}")
            c3.button("Remove", key=f"qrm-{q['id']}", on_click=remove, args=(q["id"],), type="tertiary",
                      icon=":material/delete:")
            q["sql"] = st.text_area("SQL", value=q["sql"], key=f"qsql-{q['id']}", height=130, label_visibility="collapsed",
                                    placeholder="SELECT … FROM [ACROTECH_HUB].[POWERBI].[POWERBI_867]\n"
                                                "WHERE [Invoice_Date] >= {start_date} AND [Invoice_Date] <= {end_date}")
            if q["sql"].strip():
                ok, why = db.check_read_only(q["sql"])
                if not ok:
                    ui.note(why, "down")
                elif not db.bind_date_placeholders(q["sql"], s, e)[2]:
                    ui.note("No {start_date} or {end_date} placeholder, so this query ignores the timeframe.", "watch")
            r = results.get(q["id"])
            if r is not None:
                if r.ok:
                    st.markdown(f'<span class="foot-note ok">{len(r.df):,} rows in {r.seconds:.1f}s</span>',
                                unsafe_allow_html=True)
                    with st.expander("Preview (first 100 rows)"):
                        st.dataframe(r.df.head(100), hide_index=True, height=220)
                else:
                    ui.error_state(f"{q['name']} failed.", r.error)

    with st.container(horizontal=True, gap="small", vertical_alignment="center"):
        if st.button("Add query", icon=":material/add:", key="q-add"):
            queries.append(_new_query())
            st.rerun()
        with st.popover("Upload .sql"):
            ups = st.file_uploader("Upload .sql files", type=["sql", "txt"], accept_multiple_files=True, key="q-upload")
        seen = ss.setdefault("_uploaded_sql", set())
        for f in ups or []:
            sig = (f.name, f.size)
            if sig not in seen:
                seen.add(sig)
                queries.append(_new_query(f.name.rsplit(".", 1)[0], f.getvalue().decode("utf-8-sig", errors="replace")))
                st.rerun()
        run_all = st.button("Run all", key="q-run", icon=":material/play_arrow:")

    if run_all:
        engine = ss["engine"]
        card = ui.ProgressCard("Running queries", [q["name"] for q in queries])
        for i, q in enumerate(queries):
            card.start(i)
            ok, why = db.check_read_only(q["sql"])
            if not ok:
                results[q["id"]] = db.QueryResult(q["name"], q["sql"], error=why)
                card.fail(i, why)
                continue
            sql, params, _ = db.bind_date_placeholders(q["sql"], s, e)
            t = time.perf_counter()
            try:
                df = cached_query(fingerprint(), sql, tuple(params), engine)
                results[q["id"]] = db.QueryResult(q["name"], sql, df, time.perf_counter() - t)
                card.done(i, f"{len(df):,} rows", time.perf_counter() - t)
            except Exception as exc:  # noqa: BLE001 - a failing query doesn't stop the others
                what, how = db.friendly_error(exc, ss["conn_params"])
                results[q["id"]] = db.QueryResult(q["name"], sql, None, time.perf_counter() - t, f"{what} {how}")
                card.fail(i, what)
        st.rerun()

    ok_results = {qid: r for qid, r in results.items() if r.ok and any(q["id"] == qid for q in queries)}
    if not ok_results:
        return
    st.markdown('<div class="divider"></div><div class="t-card" style="font-size:15px">Assign results</div>'
                '<div class="t-sub">Tell the app which result is which, then check the column mapping</div>',
                unsafe_allow_html=True)
    names = {qid: r.name for qid, r in ok_results.items()}
    opts = list(ok_results)
    c1, c2, c3 = st.columns(3)
    sales_id = c1.selectbox("867 sales data", opts, format_func=names.get, key="as_sales")
    align_id = c2.selectbox("Territory alignment", opts, format_func=names.get, key="as_align", index=min(1, len(opts) - 1))
    cm_id = c3.selectbox("Customer master (optional)", [None] + opts, key="as_cm",
                         format_func=lambda x: "None" if x is None else names[x], index=min(3, len(opts)))
    mappings = {}
    for role, qid, targets, optional in [
        ("sales", sales_id, config.REQUIRED_867, config.OPTIONAL_867),
        ("align", align_id, config.REQUIRED_ALIGNMENT, set()),
        ("cm", cm_id, config.REQUIRED_CUSTOMER_MASTER, config.OPTIONAL_CUSTOMER_MASTER),
    ]:
        if qid is None:
            continue
        src = list(ok_results[qid].df.columns)
        guess = guess_mapping(src, targets)
        missing = [t for t in targets if not guess[t] and t not in optional]
        with st.expander(f"Column mapping: {names[qid]}" + (f" ({len(missing)} to map)" if missing else ""),
                         expanded=bool(missing)):
            cols = st.columns(3)
            m = {}
            for j, t in enumerate(targets):
                choices = [None] + src
                default = choices.index(guess[t]) if guess[t] in choices else 0
                m[t] = cols[j % 3].selectbox(t + (" (optional)" if t in optional else ""), choices, index=default,
                                             key=f"map-{role}-{qid}-{t}",
                                             format_func=lambda x: "Not available" if x is None else x)
            mappings[role] = (qid, m)
    ss["_custom_mappings"] = mappings


def load_custom(s: date, e: date, ph) -> bool:
    mappings = ss.get("_custom_mappings", {})
    results = ss.get("custom_results", {})
    if "sales" not in mappings or "align" not in mappings:
        ui.error_state("Run the queries and assign the 867 sales and territory alignment results first.")
        return False
    card = ui.ProgressCard("Loading data", ["Preparing query results", "Matching territories", "Matching parents",
                                            "Running checks"], ph)
    t_all = time.perf_counter()
    try:
        card.start(0)
        t = time.perf_counter()
        frames = {}
        for role, (qid, m) in mappings.items():
            required = {"sales": config.REQUIRED_867, "align": config.REQUIRED_ALIGNMENT, "cm": config.REQUIRED_CUSTOMER_MASTER}[role]
            optional = {"sales": config.OPTIONAL_867, "align": set(), "cm": config.OPTIONAL_CUSTOMER_MASTER}[role]
            miss = [c for c in required if not m.get(c) and c not in optional]
            if miss:
                raise ValueError(f"Map these columns for {results[qid].name}: {', '.join(miss)}.")
            frames[role] = apply_column_mapping(results[qid].df, m)
        card.done(0, f"{len(frames['sales']):,} sales rows", time.perf_counter() - t)
        finish_load(frames["sales"], frames["align"], frames.get("cm"), card, 1, "Custom queries", s, e,
                    [(results[qid].name, results[qid].sql, [str(s), str(e)]) for _, (qid, _) in mappings.items()], t_all)
        return True
    except en.JoinCheckError as exc:
        card.fail(card.running_index() or 1, str(exc))
        ui.error_state(str(exc), "Fix the duplicated zips, then load again.")
        st.dataframe(exc.detail, hide_index=True)
    except Exception as exc:  # noqa: BLE001
        i = card.running_index()
        if i is not None:
            card.fail(i, str(exc))
        ui.error_state(str(exc))
    return False


def align_status_row() -> None:
    """Stored reference tables: ages, the weekly update prompt and the Update button."""
    metas = ss.get("ref_store_meta", {})
    parts = []
    for name, rt in ls.REFERENCE_TABLES.items():
        if not table_available(name):
            parts.append(f"{rt.label}: not in the database")
        elif metas.get(name):
            parts.append(f"{rt.label}: {ls.describe(metas[name])}")
        else:
            parts.append(f"{rt.label}: not stored yet, pulled on the next load")
    c1, c2 = st.columns([4, 1.4], vertical_alignment="center")
    c1.markdown('<span class="foot-note">Stored tables. ' + ui.E("; ".join(parts)) + ".</span>",
                unsafe_allow_html=True)
    ss["_align_update_clicked"] = c2.button(
        "Update stored tables", key="btn-align-update", width="stretch", icon=":material/sync:",
        help="Pull zip-to-territory, customer master, roster and users again in full and replace the stored copies")
    old = ls.oldest(metas)
    if old and ls.is_stale(old[1], config.ALIGNMENT_STORE_MAX_AGE_DAYS):
        ui.note(f"{ls.REFERENCE_TABLES[old[0]].label} was pulled {int(ls.age_days(old[1]))} days ago. Update the "
                "stored tables to pick up alignment, customer-master and roster changes; loads keep using the stored copies "
                "until you do.", "watch")
    for name, err in ss.get("_store_errors", {}).items():
        ui.note(f"{ls.REFERENCE_TABLES[name].label} couldn't be saved locally, so it will be pulled again next load: "
                f"{err}", "watch")


load_ph = None
with st.container(key="card-load"):
    ui.init("load_mode", "Default (recommended)")
    mode = ss["load_mode"]
    h1, h2 = st.columns([3, 2], vertical_alignment="center")
    with h1:
        ui.card_head("3. Load data", "Use the standard queries, or bring your own" if mode.startswith("Default")
                     else "Each query becomes a table the app can join on DEA or outlet ID")
    with h2, st.container(horizontal=True, horizontal_alignment="right"):
        st.segmented_control("Data mode", ["Default (recommended)", "Custom queries"], key="load_mode", required=True,
                             label_visibility="collapsed", disabled=not step2_done)
    if not step2_done:
        st.markdown('<div class="t-small">Connect and choose a timeframe first.</div>', unsafe_allow_html=True)
    else:
        if mode.startswith("Default"):
            fid = f"FileID {config.ALIGNMENT_FILE_ID}" if config.ALIGNMENT_FILE_ID else "latest FileID"
            st.markdown(
                '<div class="tiles">'
                f'<div class="tile"><div class="t1">Sales (867)</div><div class="t2">Both products, {fc.fmt_date(start)} → '
                f'{"today" if end >= date.today() - timedelta(days=7) else fc.fmt_date(end)}</div></div>'
                f'<div class="tile"><div class="t1">Customer master</div><div class="t2">DEA, outlet ID, address, COMBO; '
                f'{"stored copy" if ss.get("ref_store_meta", {}).get(ls.CUSTOMER_MASTER) else "pulled once, then stored"}</div></div>'
                f'<div class="tile"><div class="t1">Territory alignment</div><div class="t2">Team {config.TEAM}, {fid}, '
                f'{"stored copy" if ss.get("align_store_meta") else "pulled once, then stored"}</div></div>'
                '<div class="tile"><div class="t1">Parent hierarchy</div><div class="t2">COMBO, outlet ID and SPOR keys</div></div>'
                '</div>', unsafe_allow_html=True)
            align_status_row()
            with st.expander("View SQL :gray[5 queries, read-only]"):
                sql_txt = "\n\n".join(
                    f"-- {name}" + (f"\n-- parameters: {', '.join(str(x) for x in p)}" if p else "")
                    + ("\n-- Read from the stored local copy; runs only when there is none, or on Update."
                       if ("ZIPTOTERR" in name or "CUSTOMER_MASTER" in name) else "") + f"\n{sql};"
                    for name, sql, p in default_queries(ss["conn_params"].database, start, end))
                for rname in (ls.ROSTER, ls.USER):
                    rt = ls.REFERENCE_TABLES[rname]
                    sql_txt += (f"\n\n-- {rt.label} ({rt.table}, optional)\n-- Read from the stored local copy; runs "
                                f"only when there is none, or on Update.\n{ls.reference_query(rname, ss['conn_params'].database)[0]};")
                st.code(sql_txt, language="sql")
        else:
            custom_mode(start, end)
        st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
        f1, f2, f3 = st.columns([4, 1, 1], vertical_alignment="center")
        msg = ss.get("_load_msg")
        f1.markdown(f'<span class="foot-note {"ok" if msg else ""}">'
                    f'{ui.E(msg or "Pulls BELEODAQ and RYZNEUTA only. Results are cached for 8 hours.")}</span>',
                    unsafe_allow_html=True)
        refresh = f2.button("Refresh data", key="btn-refresh", disabled=not has_data, width="stretch",
                            help="Clear cached query results and pull again")
        go = f3.button("Load data", type="primary", key="btn-load", width="stretch")
        load_ph = st.empty()
        if refresh:
            cached_query.clear()
        if ss.pop("_align_update_clicked", False) and mode.startswith("Default"):
            if update_references(load_ph):
                ss["_toast"] = "Stored tables updated"
                if has_data:
                    ok = load_default(start, end, load_ph)
                    if ok:
                        ss["_toast"] = "Stored tables updated and data re-matched"
                        st.rerun()
                else:
                    st.rerun()
        if go or refresh:
            ok = load_default(start, end, load_ph) if mode.startswith("Default") else load_custom(start, end, load_ph)
            if ok:
                st.rerun()


# =============================================================================
# Data quality
# =============================================================================
if state.has_data():
    data: en.EnrichedData = state.data()
    q = data.quality()
    meta = state.meta()
    s_ = data.sales
    ui.section_title("Data quality", "How well the loaded sales rows join to territories and parent accounts")

    acct_aligned = s_.groupby("account_key")["aligned"].any()
    unaligned_accts = int((~acct_aligned).sum())
    ms = data.parents.method_summary.set_index("Method")
    colors = [TH["accent"], ui._mix(TH["surface"], TH["accent"], 0.55), ui._mix(TH["surface"], TH["accent"], 0.28), TH["watch"]]
    methods = config.MATCH_METHODS + [config.UNMAPPED]
    labels = {"COMBO": "By COMBO", "Outlet ID": "By outlet ID", "SPOR": "By SPOR", config.UNMAPPED: "Unmapped"}
    stack = "".join(f'<span style="width:{max(0.0, ms.loc[m_, "% of ship-tos"]):.2f}%;background:{c}"></span>'
                    for m_, c in zip(methods, colors) if ms.loc[m_, "% of ship-tos"] > 0)
    legend = "".join(
        f'<div><div class="k"><i style="background:{c}"></i>{ui.E(labels[m_])}</div>'
        f'<div class="v num">{ms.loc[m_, "% of ship-tos"]:.1f}%</div>'
        f'<div class="s num">{ms.loc[m_, "% of units"]:.1f}% of units</div></div>' for m_, c in zip(methods, colors))
    c1, c2 = st.columns([1, 1.7], gap="medium")
    c1.markdown(
        f'<div class="dqc"><div class="h">Territory match <span>by ship-to zip, % of units</span></div>'
        f'<div class="big num">{q["aligned_unit_pct"]:.1f}%</div><div class="trk"><span style="width:{q["aligned_unit_pct"]:.1f}%"></span></div>'
        f'<div class="d">{unaligned_accts:,} accounts have no territory alignment and fall under Unaligned. '
        f'Team {config.TEAM}, FileID {ui.E(str(data.alignment.file_id))}, applied to all history.'
        + (f' Zip-to-territory {ui.E(ls.describe(meta["alignment_stored"]))}.' if meta.get("alignment_stored") else "")
        + '</div></div>',
        unsafe_allow_html=True)
    c2.markdown(
        f'<div class="dqc"><div class="h">Parent match <span>first rule that matched, in order, % of ship-tos</span></div>'
        f'<div class="stack">{stack}</div><div class="stack-legend">{legend}</div></div>', unsafe_allow_html=True)
    st.write("")
    st.markdown(
        '<div class="stats">'
        f'<div><div class="k">Sales rows</div><div class="v num">{q["rows"]:,}</div></div>'
        f'<div><div class="k">Accounts</div><div class="v num">{q["accounts"]:,}</div></div>'
        f'<div><div class="k">Return rows</div><div class="v num">{q["return_rows"]:,}</div></div>'
        f'<div><div class="k">Unaligned accounts</div><div class="v num {"watch" if unaligned_accts else ""}">{unaligned_accts:,}</div></div>'
        f'<div><div class="k">Unmapped accounts</div><div class="v num {"watch" if q["unmapped_shiptos"] else ""}">{q["unmapped_shiptos"]:,}</div></div>'
        '</div>', unsafe_allow_html=True)
    st.write("")
    unaligned_tbl = (s_[~s_["aligned"]].groupby(["account_key", "account_label", "zip5", "Ship_To_State"], dropna=False)
                     .agg(rows=(config.QTY_COLUMN, "size"), units=(config.QTY_COLUMN, "sum")).reset_index()
                     .sort_values("units", ascending=False))
    export_cols = [c for c in s_.columns if c != "combo_norm"]
    stamp = f"{date.today():%Y%m%d}"
    with st.container(key="dq-downloads", horizontal=True, gap="small"):
        ui.download_csv("Unaligned accounts (CSV)", unaligned_tbl, f"unaligned_accounts_{stamp}.csv", "dl-unal")
        ui.download_csv("Unmapped accounts (CSV)", data.parents.unmapped, f"unmapped_accounts_{stamp}.csv", "dl-unmap")
        ui.download_csv("Full extract (CSV)", s_[export_cols], f"sell_through_enriched_{stamp}.csv", "dl-full-csv")
        ui.download_xlsx("Full extract (Excel)", s_[export_cols], f"sell_through_enriched_{stamp}.xlsx", "dl-full-xlsx",
                         "enriched")
    for w in data.alignment.warnings:
        ui.note(w, "watch")
    if q["positive_returns_fixed"]:
        ui.note(f"{q['positive_returns_fixed']:,} return rows had a positive {q['qty_column']}; they were made negative "
                "so they net against sales.", "watch")
    _fb = sum(v for k, v in q["qty_source_counts"].items() if k != q["qty_column"])
    if _fb:
        ui.note(f"{_fb:,} rows have no {q['qty_column']}; units for them come from Sold_Qty × Factor or Converted_QTY. "
                "See More checks.", "watch")
    people = getattr(data, "people", None)
    if people is not None:
        for w in people.warnings:
            ui.note(w, "watch" if people.available else "info")
    if q["unidentified_rows"]:
        ui.note(f"{q['unidentified_rows']:,} rows have neither a DEA nor a Detail_Group_ID and are grouped as "
                "“Unidentified ship-to”.", "watch")

    with st.expander("More checks: date ranges, match methods, conflict logs, cross-checks"):
        bp = q["by_product"].rename(columns={"first": "First invoice", "last": "Latest invoice", "rows": "Rows",
                                             "units": "Net units"})
        st.markdown('<div class="t-label">Date range per product</div>', unsafe_allow_html=True)
        st.dataframe(bp, hide_index=True, width="content",
                     column_config={"First invoice": st.column_config.DateColumn(format="MMM D, YYYY"),
                                    "Latest invoice": st.column_config.DateColumn(format="MMM D, YYYY"),
                                    "Net units": st.column_config.NumberColumn(format="%,.0f")})
        st.markdown('<div class="t-label">Quantity checks</div>', unsafe_allow_html=True)
        st.dataframe(data.quantity_checks(), hide_index=True, width="content")
        if people is not None and people.available:
            st.markdown('<div class="t-label">Territory owners (roster + users)</div>', unsafe_allow_html=True)
            own = people.owners.rename(columns={"owner_name": "Owner", "owner_start_date": "Start date",
                                                "new_to_territory": "New to territory",
                                                "region_manager_login": "Region manager login"})
            st.dataframe(own.drop(columns=["days_in_territory"]), hide_index=True, height=220,
                         column_config={"Start date": st.column_config.DateColumn(format="MMM D, YYYY")})
            if len(people.roster_vs_alignment):
                bad = people.roster_vs_alignment[people.roster_vs_alignment["Issue"] != "OK"]
                st.markdown(f'<div class="t-label">Roster vs zip-to-territory ({len(bad):,} differences)</div>',
                            unsafe_allow_html=True)
                st.dataframe(bad if len(bad) else people.roster_vs_alignment.head(0), hide_index=True, height=180)
        st.markdown('<div class="t-label">Parent match by method</div>', unsafe_allow_html=True)
        st.dataframe(data.parents.method_summary, hide_index=True, width="content",
                     column_config={"% of ship-tos": st.column_config.NumberColumn(format="%.1f%%"),
                                    "% of units": st.column_config.NumberColumn(format="%.1f%%"),
                                    "Units": st.column_config.NumberColumn(format="%,.0f")})
        st.markdown(f'<div class="t-label">Key conflicts ({len(data.parents.lookup_conflicts):,}): keys that map to several '
                    'parents, and how each was resolved</div>', unsafe_allow_html=True)
        st.dataframe(data.parents.lookup_conflicts, hide_index=True, height=200)
        ui.download_csv("Key conflicts (CSV)", data.parents.lookup_conflicts, f"parent_key_conflicts_{stamp}.csv", "dl-kc")
        st.markdown(f'<div class="t-label">Ship-tos whose rows matched different parents ({q["shipto_conflicts"]:,}); the '
                    'parent from the most recent matched invoice is used</div>', unsafe_allow_html=True)
        st.dataframe(data.parents.shipto_conflicts, hide_index=True, height=200)
        ui.download_csv("Ship-to conflicts (CSV)", data.parents.shipto_conflicts, f"shipto_parent_conflicts_{stamp}.csv", "dl-sc")
        if len(data.alignment.duplicates):
            st.markdown('<div class="t-label">Duplicate zips in the alignment</div>', unsafe_allow_html=True)
            st.dataframe(data.alignment.duplicates, hide_index=True)
        if len(data.ptcl_summary):
            st.markdown('<div class="t-label">PTCL_BELEODAQ team flag vs zip alignment (information only; the zip join '
                        'is the source of truth)</div>', unsafe_allow_html=True)
            st.dataframe(data.ptcl_summary, hide_index=True, width="content")
            st.dataframe(data.ptcl_detail.head(500), hide_index=True, height=200)
        if "New_Start" in s_ and s_["New_Start"].notna().any():
            first = s_.groupby("account_key")["Invoice_Date"].transform("min")
            flagged = s_["New_Start"].astype("string").str.upper().str.contains("NEW", na=False)
            agree = int((flagged & (s_["Invoice_Date"] == first)).sum())
            st.markdown(f'<div class="t-small">New_Start cross-check: {int(flagged.sum()):,} rows carry NEW START; '
                        f'{agree:,} of them are also the account’s first invoice in the pulled range.</div>',
                        unsafe_allow_html=True)
