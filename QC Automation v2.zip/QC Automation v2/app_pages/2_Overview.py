"""Overview: week / month / fiscal quarter to date vs recent averages, trend, alerts, geography change."""
from __future__ import annotations

from datetime import timedelta

import streamlit as st

import charts as C
import config
import fiscal_calendar as fc
from ui import components as ui
from ui import state
from ui.compute import first_time, overview_cached
from ui.theme import PLOTLY_CONFIG, Theme

ss = st.session_state
product = state.product()
TH = Theme.for_product(product)

if not state.has_data():
    ui.no_data_state("overview", "Overview")
    st.stop()

df = state.data().sales
pdf = df[df["Product"] == product]
md = pdf["Invoice_Date"].max().date() if len(pdf) else None

# ---- Header band --------------------------------------------------------------------
with st.container(key="header-band"):
    h1, h2 = st.columns([4, 1.4], vertical_alignment="center")
    with h1:
        badge = ui.freshness_badge("Latest invoice", ui.fmt_wd(md)) if md else ""
        st.markdown(f'<h1 class="t-page">{ui.E(product)} overview</h1>{badge}', unsafe_allow_html=True)
    with h2:
        ui.init("same_weekdays", True)
        st.toggle("Compare same weekdays", key="same_weekdays",
                  help="On: a partial week is compared with the same weekdays of the previous 13 weeks. "
                       "Off: with full Mon–Sun weeks.")

if md is None:
    st.write("")
    ui.state_card(f"No {product} sales in the pulled data.", "Widen the timeframe on Connect & load, or switch product.",
                  [{"label": "Go to Connect & load", "type": "primary", "page": "app_pages/1_Connect_and_load.py"}],
                  key="state-ov-none")
    st.stop()

# ---- Filter card -----------------------------------------------------------------------
for k in ("ov_regions", "ov_territories"):
    ui.init(k, [])
with st.container(key="filter-ov"):
    f1, f2 = st.columns(2)
    regions_all = sorted(pdf["Region_Name"].dropna().unique().tolist())
    ss["ov_regions"] = [r for r in ss["ov_regions"] if r in regions_all]
    f1.multiselect("Region", regions_all, key="ov_regions", placeholder="All regions")
    tpool = pdf[pdf["Region_Name"].isin(ss["ov_regions"])] if ss["ov_regions"] else pdf
    terr_all = sorted(tpool["Territory_Name"].dropna().unique().tolist())
    ss["ov_territories"] = [t for t in ss["ov_territories"] if t in terr_all]
    f2.multiselect("Territory", terr_all, key="ov_territories", placeholder="All territories")
    ui.active_filters({"ov_regions": "Region", "ov_territories": "Territory"}, "ov")

# ---- Compute (skeletons on a cache miss) --------------------------------------------------
th = state.thresholds()
args = (state.version(), product, tuple(ss["ov_regions"]), tuple(ss["ov_territories"]),
        bool(ss["same_weekdays"]), tuple(sorted(th.items())))
miss = first_time(("ov",) + args)

kpi_cols = st.columns(3, gap="medium")
kpi_ph = [c.empty() for c in kpi_cols]
left, mid, right = st.columns([1.9, 1, 1.1], gap="medium")
trend_ph, alerts_ph = left.empty(), left.empty()
region_ph, terr_ph = mid.empty(), right.empty()

if miss:
    for ph in kpi_ph:
        ui.skeleton("kpi", ph)
    ui.skeleton("chart", trend_ph, 300)
    ui.skeleton("alerts", alerts_ph)
    ui.skeleton("change", region_ph, 520)
    ui.skeleton("change", terr_ph, 520)

b = overview_cached(*args, _df=df)


def clear_geo():
    ss["ov_regions"], ss["ov_territories"] = [], []


if b.rows == 0:
    for ph in kpi_ph + [trend_ph, alerts_ph, region_ph, terr_ph]:
        ph.empty()
    where = ", ".join(ss["ov_territories"] or [r.title() for r in ss["ov_regions"]]) or "this selection"
    ui.state_card(f"No {product} sales in {where} for this period.",
                  "Widen the date range or clear the territory filter.",
                  [{"label": "Clear territory filter", "type": "secondary", "on_click": clear_geo},
                   {"label": "Widen date range", "type": "tertiary", "page": "app_pages/1_Connect_and_load.py"}],
                  icon="chart", key="state-ov-empty")
    st.stop()


# ---- KPI cards: entrance plays once per data load ----------------------------------------
def _notes(k) -> tuple[str, str, str, str]:
    w = k.windows
    if k.key == "week":
        s, e = w.current
        partial = e.weekday() < 6
        if ss["same_weekdays"] and partial:
            note = f"{s:%a}–{e:%a} this week against the same weekdays, averaged over the last 13 weeks."
        elif partial:
            note = "This week so far against full Mon–Sun weeks, averaged over the last 13 weeks."
        else:
            note = "This week against the previous 13 full weeks, averaged."
        return f"{ui.fmt_wd_short(s)} – {ui.fmt_wd_short(e)}", "This week", "13-week average", note
    if k.key == "month":
        s, e = w.current
        months = [c[0].strftime("%B") for c in reversed(w.comparisons)]
        note = (f"First {e.day} days of {e:%B} against the same days of {', '.join(months[:-1])} and {months[-1]}."
                if e.day > 1 else f"{e:%B} 1 against the first day of {', '.join(months[:-1])} and {months[-1]}.")
        return f"{ui.fmt_md(s)} – {ui.fmt_md(e)}", "This month", "3-month average", note
    s, e = w.current
    n = (e - s).days + 1
    note = f"First {n} days of Q{fc.fiscal_quarter(e)} against the same span of the previous three quarters."
    return f"{ui.fmt_md(s)} – {ui.fmt_md(e)}", "This quarter", "3-quarter average", note


enter = ss.get("_kpi_entrance_for") != state.version()
ss["_kpi_entrance_for"] = state.version()
for i, (ph, k) in enumerate(zip(kpi_ph, b.kpis)):
    rng, cl, al, note = _notes(k)
    ph.markdown(ui.kpi_card_html(k.title, rng, k.current, k.average, k.diff, k.pct, cl, al, note,
                                 enter=enter, delay_ms=i * 60, xfade=not miss), unsafe_allow_html=True)

# ---- Weekly units --------------------------------------------------------------------------
with trend_ph.container(key="card-weekly"):
    ui.card_head("Weekly units", "Last 26 weeks, Monday start",
                 right=ui.legend_html([("ln", "Units"), ("dash", "13-week average"), ("ring", "Unusual week")]))
    st.plotly_chart(C.weekly_trend(b.weekly, b.kpis[0].average if b.kpis else 0, b.weekly_anomalies, TH, 290),
                    theme=None, config=PLOTLY_CONFIG, key="ov-weekly")


# ---- Alerts ------------------------------------------------------------------------------------
def apply_alert(level: str, name: str):
    if level == "Territory":
        ss["ov_territories"] = [name]
    elif level == "Region":
        ss["ov_regions"], ss["ov_territories"] = [name], []


def _alert_rows(alerts, prefix: str):
    for i, a in enumerate(alerts):
        geo = a.level in ("Territory", "Region") and a.name and a.name != config.UNALIGNED
        if geo:
            c1, c2 = st.columns([14, 1], vertical_alignment="center")
            c1.markdown(ui.alert_html(a.severity, a.entity, a.rest, a.chips), unsafe_allow_html=True)
            c2.button("", key=f"{prefix}-{i}", icon=":material/filter_alt:", type="tertiary", on_click=apply_alert,
                      args=(a.level, a.name), help=f"Filter the overview to {a.entity}")
        else:
            st.markdown(ui.alert_html(a.severity, a.entity, a.rest, a.chips), unsafe_allow_html=True)


@st.dialog("All alerts", width="large")
def all_alerts(alerts):
    st.markdown(f'<div class="t-sub">{len(alerts)} alerts for {ui.E(product)} in this selection</div>',
                unsafe_allow_html=True)
    _alert_rows(alerts, "al-all")


with alerts_ph.container(key="card-alerts"):
    h1, h2 = st.columns([5, 1], vertical_alignment="center")
    h1.markdown(f'<h3 class="t-card">Alerts<span class="count-badge">{len(b.alerts)}</span></h3>', unsafe_allow_html=True)
    if len(b.alerts) > 5 and h2.button("See all", key="al-see-all", type="tertiary"):
        all_alerts(b.alerts)
    with st.container(key="alert-filters"):
        if not b.alerts:
            st.markdown('<div class="t-small">Nothing unusual against the recent averages.</div>', unsafe_allow_html=True)
        _alert_rows(b.alerts[:5], "al")

# ---- Region and territory change -------------------------------------------------------------
sub = "Month to date vs 3-month average, sorted by % change"
with region_ph.container(key="card-region"):
    ui.card_head("Change by region", sub)
    rc = b.region_change["month"].copy()
    rc["name"] = rc["name"].astype(str).map(lambda x: x if x == config.UNALIGNED else x.title())
    st.markdown(ui.change_list_html(rc), unsafe_allow_html=True)
with terr_ph.container(key="card-territory"):
    ui.card_head("Change by territory", sub)
    st.markdown(ui.change_list_html(b.territory_change["month"], max_rows=16), unsafe_allow_html=True)

st.markdown(f'<div class="t-caption" style="margin-top:14px">Anchored on the latest {ui.E(product)} invoice across all '
            'geographies, so a quiet territory shows low sales rather than an older week. Territories use the current '
            f'alignment (team {config.TEAM}) for all history.</div>', unsafe_allow_html=True)
