"""Product deep dive: demand in patient terms, treatment rhythm, accounts, forecast and the field action plan.

867 data are account-level shipments, not patient records: every patient, cycle and course figure is an
estimate and carries an "Estimate" pill. Recommendations stay within the approved labels.
"""
from __future__ import annotations

from collections import OrderedDict
from datetime import date

import pandas as pd
import streamlit as st

import charts as C
import config
import deep_dive as DD
import fiscal_calendar as fc
import forecast as F
import product_engine as pe
from ui import components as ui
from ui import state
from ui.theme import PLOTLY_CONFIG, Theme

ss = st.session_state
product = state.product()
TH = Theme.for_product(product)
PROF = config.PRODUCT_PROFILES[product]
UNIT, UNITS = PROF["unit"], PROF["units"]
SECTIONS = ["Snapshot", "Demand", "Rhythm & persistence", "Accounts", "Forecast", "Field actions"]

if not state.has_data():
    ui.no_data_state("deep-dive", "Product deep dive")
    st.stop()

data = state.data()
df = data.sales
pdf = df[df["Product"] == product]
md = pdf["Invoice_Date"].max().date() if len(pdf) else None
people = getattr(data, "people", None)


# =============================================================================
# Settings (per product, session only)
# =============================================================================
SETTING_FIELDS = [
    # key, label, min, max, step, products (None = both)
    ("bsa_m2", "Body surface area (m²)", 1.2, 2.6, 0.05, ["BELEODAQ"]),
    ("unit_mg", "Vial size (mg)", 100.0, 1000.0, 50.0, ["BELEODAQ"]),
    ("dose_standard", "Standard dose (mg/m²)", 100.0, 2000.0, 50.0, ["BELEODAQ"]),
    ("dose_reduced", "Reduced dose (mg/m²)", 100.0, 2000.0, 50.0, ["BELEODAQ"]),
    ("dose_organ", "Liver/kidney dose (mg/m²)", 100.0, 2000.0, 50.0, ["BELEODAQ"]),
    ("dose_tolerance_units", "Dose-level tolerance (± vials)", 0.0, 5.0, 0.5, ["BELEODAQ"]),
    ("cycle_days", "Cycle length (days)", 7, 42, 1, None),
    ("on_schedule_lo", "On schedule from (days)", 1, 60, 1, None),
    ("on_schedule_hi", "On schedule to (days)", 1, 60, 1, None),
    ("alt_on_schedule_lo", "14-day cycle on schedule from", 1, 30, 1, ["RYZNEUTA"]),
    ("alt_on_schedule_hi", "14-day cycle on schedule to", 1, 30, 1, ["RYZNEUTA"]),
    ("event_window_days", "Order grouping window (days)", 1, 14, 1, None),
    ("max_course_gap_days", "Maximum gap within a course (days)", 14, 120, 1, None),
    ("regime_max_ce_per_event", "Run-rate if cycle-equivalents per event above", 1.0, 5.0, 0.1, None),
    ("regime_max_events_per_21d", "Run-rate if events per 21 days above", 1.0, 5.0, 0.1, None),
    ("regime_max_interval_cv", "Run-rate if interval variation (CV) above", 0.2, 2.0, 0.05, None),
    ("overdue_tolerance_days", "Overdue after expected date + (days)", 0, 30, 1, None),
    ("forecast_weeks", "Forecast horizon (weeks)", 4, 26, 1, None),
    ("forecast_range_pct", "Forecast range (%)", 50, 95, 5, None),
    ("new_start_days", "New start follow-through window (days)", 7, 90, 1, None),
    ("lapsed_high_value_pct", "Lapsed high-value: percentile of 12-month units", 0, 99, 5, None),
    ("runrate_slowdown_pct", "Run-rate slowdown: drop vs 13-week average (%)", 10, 90, 5, None),
    ("w_units", "Priority weight: units at stake", 0.0, 3.0, 0.25, None),
    ("w_probability", "Priority weight: probability", 0.0, 3.0, 0.25, None),
    ("w_urgency", "Priority weight: urgency", 0.0, 3.0, 0.25, None),
]


def settings_popover() -> dict:
    defaults = pe.settings_for(product)
    cur = dict(ss.setdefault("pdd_settings", {}).get(product, {}))
    with st.popover("Deep dive settings", icon=":material/tune:"):
        st.markdown(f'<div class="t-sub" style="margin-bottom:6px">{ui.E(product)} calculation parameters. Changes '
                    'apply to this page only, for this session.</div>', unsafe_allow_html=True)
        obs = st.toggle("Use observed values instead of label values", value=bool(cur.get("use_observed", 0)),
                        key=f"pdd_obs_{product}",
                        help="Observed = median cycle size and interval measured from single-patient (cadence) accounts.")
        new = {"use_observed": int(obs)}
        for k, lbl, lo, hi, step, prods in SETTING_FIELDS:
            if prods and product not in prods:
                continue
            v = cur.get(k, defaults[k])
            wkey = f"pdd_set_{product}_{k}"
            if isinstance(step, int):
                new[k] = st.number_input(lbl, min_value=int(lo), max_value=int(hi), step=step, value=int(v), key=wkey)
            else:
                new[k] = st.number_input(lbl, min_value=float(lo), max_value=float(hi), step=float(step), value=float(v),
                                         key=wkey)
        changed = {k: v for k, v in new.items() if v != defaults.get(k)}

        def reset():
            ss["pdd_settings"][product] = {}
            for k, *_ in SETTING_FIELDS:
                ss.pop(f"pdd_set_{product}_{k}", None)
            ss.pop(f"pdd_obs_{product}", None)

        st.button("Reset to defaults", type="tertiary", key=f"pdd_reset_{product}", on_click=reset)
    ss["pdd_settings"][product] = changed
    return changed


# =============================================================================
# Header
# =============================================================================
h1, h2 = st.columns([5, 1.4], vertical_alignment="bottom")
with h1:
    badges = ""
    if md:
        badges = ui.freshness_badge("As of", ui.fmt_wd(md))
        ld = data.sales.loc[data.sales["Product"] == product, "Load_Date"].dropna()
        if len(ld):
            badges += " " + ui.freshness_badge("Data loaded", ui.fmt_wd(ld.max()))
    st.markdown(f'<div class="page-header"><h1 class="t-page">{ui.E(product)} deep dive</h1>'
                f'<div class="sub">Demand in patient terms, treatment rhythm, accounts, forecast and field actions. '
                f'Patient, cycle and course figures are estimates from shipments.</div></div>{badges}',
                unsafe_allow_html=True)
with h2:
    overrides = settings_popover()

if md is None:
    ui.state_card(f"No {product} sales in the pulled data.", "Widen the timeframe on Connect & load, or switch product.",
                  [{"label": "Go to Connect & load", "type": "primary", "page": "app_pages/1_Connect_and_load.py"}],
                  key="state-pdd-none")
    st.stop()

# =============================================================================
# Filters
# =============================================================================
for k in ("pdd_regions", "pdd_territories", "pdd_parents", "pdd_accounts"):
    ui.init(k, [])
first = pdf["Invoice_Date"].min().date()
if not isinstance(ss.get("pdd_window"), (tuple, list)) or ss.get("_pdd_window_for") != (state.version(), product):
    ss["pdd_window"] = (first, md)
    ss["_pdd_window_for"] = (state.version(), product)

with st.container(key="filter-pdd"):
    c = st.columns(3)
    regions_all = sorted(pdf["Region_Name"].dropna().unique())
    ss["pdd_regions"] = [x for x in ss["pdd_regions"] if x in regions_all]
    c[0].multiselect("Region", regions_all, key="pdd_regions", placeholder="All regions")
    p1 = pdf[pdf["Region_Name"].isin(ss["pdd_regions"])] if ss["pdd_regions"] else pdf
    terr_all = sorted(p1["Territory_Name"].dropna().unique())
    ss["pdd_territories"] = [x for x in ss["pdd_territories"] if x in terr_all]
    c[1].multiselect("Territory", terr_all, key="pdd_territories", placeholder="All territories")
    p2 = p1[p1["Territory_Name"].isin(ss["pdd_territories"])] if ss["pdd_territories"] else p1
    parents_all = sorted(p2["parent_name"].dropna().unique())
    ss["pdd_parents"] = [x for x in ss["pdd_parents"] if x in parents_all]
    c[2].multiselect("Parent", parents_all, key="pdd_parents", placeholder="All parents")
    c = st.columns([2, 1])
    p3 = p2[p2["parent_name"].isin(ss["pdd_parents"])] if ss["pdd_parents"] else p2
    acct_labels = p3.sort_values("Invoice_Date").groupby("account_key")["account_label"].last().sort_values()
    ss["pdd_accounts"] = [x for x in ss["pdd_accounts"] if x in acct_labels.index]
    c[0].multiselect("Account (ship-to)", acct_labels.index.tolist(), key="pdd_accounts", placeholder="Any account",
                     format_func=lambda k: acct_labels.get(k, k))
    c[1].date_input("History window", key="pdd_window", min_value=first, max_value=md, format="MM/DD/YYYY",
                    help="Orders used for events, courses and persistence. Default: all pulled data.")
    ui.active_filters({"pdd_regions": "Region", "pdd_territories": "Territory", "pdd_parents": "Parent"}, "pdd")

win = ss["pdd_window"]
if not (isinstance(win, (tuple, list)) and len(win) == 2):
    st.markdown('<div class="t-small">Pick an end date for the history window.</div>', unsafe_allow_html=True)
    st.stop()
hist_start = pd.Timestamp(win[0])

ui.init("pdd_section", SECTIONS[0])
with st.container(key="pdd-nav"):
    section = st.segmented_control("Section", SECTIONS, key="pdd_section", required=True, label_visibility="collapsed",
                                   width="stretch")

# =============================================================================
# Compute (session cache: engine per product/settings/history; bundle per filter selection)
# =============================================================================
cache: OrderedDict = ss.setdefault("_pdd_cache", OrderedDict())
ver = state.version()
for k in [k for k in cache if k[1] != ver]:
    cache.pop(k)
skey = pe.settings_key(overrides)
k_eng = ("eng", ver, product, skey, hist_start)
k_sel = ("sel", ver, product, skey, hist_start, tuple(ss["pdd_regions"]), tuple(ss["pdd_territories"]),
         tuple(ss["pdd_parents"]), tuple(ss["pdd_accounts"]))


def _put(key, value):
    cache[key] = value
    cache.move_to_end(key)
    while len(cache) > 60:
        cache.popitem(last=False)
    return value


prog_ph = st.empty()
body_ph = st.empty()
if k_sel in cache:
    dd: DD.DeepDive = cache[k_sel]
    cache.move_to_end(k_sel)
else:
    with body_ph.container():
        cols = st.columns(3)
        for col in cols:
            ui.skeleton("kpi", col)
        ui.skeleton("chart", height=260)
    card = ui.ProgressCard(f"Building the {product} deep dive", DD.STEPS, prog_ph)
    cur = {"i": -1}

    def step(name):
        i = DD.STEPS.index(name) if name in DD.STEPS else cur["i"] + 1
        if cur["i"] >= 0 and cur["i"] != i:
            card.done(cur["i"])
        card.start(i)
        cur["i"] = i

    eng = cache.get(k_eng)
    if eng is None:
        eng = _put(k_eng, DD.run_product_engine(pdf, product, pd.Timestamp(md), overrides, hist_start, step))

    bt_cache = cache.setdefault(("bt", ver, product, skey, hist_start), {})
    cache.move_to_end(("bt", ver, product, skey, hist_start))
    backtest_engine = DD.make_backtest_engine(df, product, overrides, hist_start, bt_cache)

    try:
        dd = DD.build(df, product, overrides, hist_start, ss["pdd_regions"], ss["pdd_territories"],
                      ss["pdd_parents"], ss["pdd_accounts"], people, step, eng, backtest_engine)
    except Exception as exc:  # noqa: BLE001
        i = card.running_index()
        if i is not None:
            card.fail(i, str(exc)[:300])
        body_ph.empty()
        ui.error_state(f"The deep dive couldn't be built: {str(exc)[:300]}",
                       "Try resetting the deep dive settings; if it repeats, share this message with the app owner.")
        st.stop()
    _put(k_sel, dd)
    prog_ph.empty()
body_ph.empty()

if dd.rows == 0:
    def clear_geo():
        for k in ("pdd_regions", "pdd_territories", "pdd_parents", "pdd_accounts"):
            ss[k] = []
    ui.state_card(f"No {product} sales in this selection.", "Clear the filters or widen the history window.",
                  [{"label": "Clear filters", "type": "secondary", "on_click": clear_geo}], key="state-pdd-empty")
    st.stop()

for n in dd.notices:
    ui.note(n, "watch")

S = dd.settings
UPC = float(S["units_per_cycle"])
EST_TIP = {
    "cycles": f"Estimate: units ÷ {UPC:g} {UNITS} per cycle"
              + ("" if S.get("fixed_units_per_cycle") else f" (dose {S['dose_standard']:,.0f} mg/m² × BSA {S['bsa_m2']} m² "
                 f"÷ {S['unit_mg']:,.0f} mg, rounded up per day, × {S['days_per_cycle']} days)") + ".",
    "patients": ("Estimate: cycle-equivalents shipped in the last 21 days. "
                 + ("Range = syringes ÷ 1.5 (every patient on a 14-day cycle) to syringes ÷ 1 (all on 21 days)."
                    if S.get("alt_cycle_days") else "One 21-day cycle ≈ one patient on treatment.")
                 + " Account-level shipments, not patient records."),
    "courses": (f"Estimate: a course is a run of order events with gaps of at most {S['max_course_gap_days']} days, "
                "measured only at single-patient (cadence) accounts. A course start is a proxy for a new patient."),
}


def est(kind: str) -> str:
    return f'<span class="est-pill" title="{ui.E(EST_TIP[kind])}">Estimate</span>'


def stat_card(title: str, value: str, unit: str = "", sub: str = "", estimate: str | None = None) -> str:
    pill = est(estimate) if estimate else ""
    u = f'<span class="u">{ui.E(unit)}</span>' if unit else ""
    return (f'<div class="dd-stat"><div class="k-title">{ui.E(title)}{pill}</div><div class="v num">{value}{u}</div>'
            f'<div class="s">{ui.E(sub)}</div></div>')


def takeaway(key: str) -> None:
    st.markdown(f'<div class="takeaway">{ui.E(dd.takeaways.get(key, ""))}</div>', unsafe_allow_html=True)


def chart(fig, key: str) -> None:
    st.plotly_chart(fig, theme=None, config=PLOTLY_CONFIG, key=key)


def owner_label(row) -> str:
    o = row.get("owner") if isinstance(row, dict) else row
    return "—" if o is None or o != o or o is pd.NA else str(o)


# =============================================================================
# 1. Snapshot
# =============================================================================
def render_snapshot():
    takeaway("snapshot")
    sn = dd.snapshot
    k = sn["qtd_kpi"]
    c1, c2, c3 = st.columns([1.25, 1, 1], gap="medium")
    if k is not None:
        s, e = k.windows.current
        c1.markdown(ui.kpi_card_html(f"{UNITS.capitalize()} quarter to date", f"{ui.fmt_md(s)} – {ui.fmt_md(e)}",
                                     k.current, k.average, k.diff, k.pct, "This quarter", "3-quarter average",
                                     f"First {(e - s).days + 1} days of {sn['quarter']} against the same span of the "
                                     "previous three quarters. Units are Factored_QTY, net of returns."),
                    unsafe_allow_html=True)
    pts = sn["patients"]
    land = sn["landing"]
    lsub0 = (f"{land['lo']:,.0f}–{land['hi']:,.0f} range; last {land['n_past']} quarters averaged "
             f"{land['avg_last3']:,.0f}" if land.get("avg_last3") else f"{land['lo']:,.0f}–{land['hi']:,.0f} range")
    c2.markdown(stat_card("Estimated cycles QTD", f"{sn['cycles_qtd']:,.1f}", "cycles",
                          f"3-quarter average for the same days: {sn['cycles_qtd_avg']:,.1f}", "cycles")
                + "<div style='height:12px'></div>"
                + stat_card("Estimated active patients", pe.fmt_patients(pts["low"], pts["high"]), "patients",
                            f"From {pts['units_21d']:,.0f} {UNITS} shipped in the last 21 days", "patients")
                + "<div style='height:12px'></div>"
                + stat_card(f"Projected {sn['quarter']} landing", f"{land['projected']:,.0f}", UNITS, lsub0),
                unsafe_allow_html=True)
    c3.markdown(stat_card("Active accounts / parents", f"{sn['active_children']:,} / {sn['active_parents']:,}", "",
                          f"Ordered in the last 90 days, of {sn['total_children']:,} accounts and "
                          f"{sn['total_parents']:,} parents")
                + "<div style='height:12px'></div>"
                + stat_card("New course starts this quarter", f"{sn['starts_qtd']:,}", "",
                            f"{sn['starts_prev']:,} in the same days last quarter", "courses"),
                unsafe_allow_html=True)
    with st.expander(f"{product} ({PROF['generic']}) product facts"):
        lv = S["dose_level_units"]
        units_line = (", ".join(f"{pe.DOSE_LABELS.get(n, n)}: {S['units_per_day'][n]} per day, {u:g} per cycle"
                                for n, u in lv.items()) if not S.get("fixed_units_per_cycle")
                      else f"{UPC:g} {UNIT} ≈ one patient cycle")
        rows = [("Indication", PROF["indication"]), ("Administration", PROF["administration"]),
                ("Regimen", PROF["regimen"]), ("Dose notes", PROF["dose_notes"]), ("Pack", PROF["pack"]),
                (f"{UNITS.capitalize()} per patient", units_line + (f" (BSA {S['bsa_m2']} m²)" if not S.get("fixed_units_per_cycle") else "")),
                ("Compliance", "867 data are account-level shipments, not patient records; every patient, cycle and "
                               "course figure is an estimate. Clinical or dosing questions go to Medical Affairs; "
                               "inventory, returns, contract and wholesaler matters go to trade or operations.")]
        st.markdown('<div class="dd-facts">' + "".join(f'<div class="k">{ui.E(a)}</div><div class="v">{ui.E(b)}</div>'
                                                       for a, b in rows) + "</div>", unsafe_allow_html=True)


# =============================================================================
# 2. Demand in patient terms
# =============================================================================
def render_demand():
    takeaway("demand")
    d = dd.demand
    with st.container(key="card-pdd-weekly"):
        ui.card_head(f"Weekly {UNITS} and estimated cycles", f"Last 52 weeks, Monday start. Right axis: the same bars "
                     f"in cycles (÷ {UPC:g} {UNITS}).", right=est("cycles"))
        chart(C.dd_weekly(d["weekly"], UPC, UNITS, TH), "pdd-weekly")
    c1, c2 = st.columns(2, gap="medium")
    with c1.container(key="card-pdd-hist"):
        band_order = ([pe.DOSE_LABELS[n] for n in ("Standard", "Reduced", "Liver/kidney")] + [pe.PARTIAL, pe.MULTI]
                      if not S.get("fixed_units_per_cycle") else ["1 syringe", "2 syringes", "3–5 syringes", "6+ syringes"])
        ui.card_head("Order sizes", "Order events by net units" + (", banded by inferred dose level"
                                                                   if not S.get("fixed_units_per_cycle") else ", by pack multiple"),
                     right=est("cycles"))
        if len(d["hist"]):
            chart(C.dd_order_hist(d["hist"], band_order, UNITS, TH), "pdd-hist")
        else:
            st.markdown('<div class="t-small">No order events.</div>', unsafe_allow_html=True)
    with c2.container(key="card-pdd-style"):
        ui.card_head("Buying style", "Share of units by how sites order: per day, per cycle, or multi-unit/stock")
        chart(C.dd_mix(d["style_mix"], TH, order=pe.STYLES), "pdd-style")
    if "dose_mix" in d:
        c1, c2 = st.columns(2, gap="medium")
        with c1.container(key="card-pdd-dose"):
            ui.card_head("Dose-level mix over time", "Share of single-cycle events by inferred dose level. A trend "
                         "only, with no clinical interpretation.", right=est("cycles"))
            chart(C.dd_mix(d["dose_mix"], TH, order=list(pe.DOSE_LABELS.values())), "pdd-dose")
        nc_col = c2
    else:
        nc_col = st.container()
    nc = d["no_charge"]
    with nc_col.container(key="card-pdd-nc"):
        ui.card_head("No-charge units", "Sales rows with Extended_Amount = 0, kept in units and shown separately")
        st.markdown('<div class="stats4">'
                    f'<div class="stat"><div class="k">Rows</div><div class="v num">{nc["rows"]:,}</div></div>'
                    f'<div class="stat"><div class="k">{UNITS.capitalize()}</div><div class="v num">{nc["units"]:,.0f}</div></div>'
                    f'<div class="stat"><div class="k">Share of units</div><div class="v num">{nc["share"]:.1%}</div></div>'
                    '</div>', unsafe_allow_html=True)
        if len(nc["by_wholesaler"]):
            st.dataframe(nc["by_wholesaler"].rename(UNITS.capitalize()).reset_index().rename(
                columns={"Shipper_Name": "Wholesaler"}), hide_index=True, width="content")


# =============================================================================
# 3. Treatment rhythm and persistence
# =============================================================================
def render_rhythm():
    takeaway("rhythm")
    r = dd.rhythm
    cal = r["calibration"]
    rr_share = r["runrate_unit_share"]
    obs_u = f"{cal['observed_units']:g}" if cal.get("observed_units") else "not enough data"
    obs_i = f"{cal['observed_interval']:g} days" if cal.get("observed_interval") else "not enough data"
    ns = r["new_start"]
    st.markdown(
        '<div class="calib">'
        f'<span>Observed median cycle: <b>{obs_u}</b> {UNITS}; label-based: <b>{cal["label_units"]:g}</b></span>'
        f'<span>Observed median interval: <b>{obs_i}</b>; label: <b>{cal["label_interval"]:g} days</b></span>'
        f'<span>Using: <b>{"observed" if S.get("use_observed") else "label"}</b> values</span>'
        + (f'<span>Course starts carrying the 867 NEW START flag: <b>{ns["pct_starts_flagged"]:.0f}%</b> '
           f'({ns["starts_flagged"]} of {ns["course_starts"]})</span>' if ns.get("pct_starts_flagged") is not None else "")
        + "</div>", unsafe_allow_html=True)
    ui.note(f"Coverage: {r['n_runrate']} multi-patient (run-rate) accounts are left out of course views"
            + (f"; they take {rr_share:.0%} of the last 12 months' units." if rr_share is not None else ".")
            + f" {r['n_cadence']} single-patient (cadence) accounts are measured.", "info")
    c1, c2 = st.columns([1.5, 1], gap="medium")
    with c1.container(key="card-pdd-int"):
        pct = r["pct_on_schedule"]
        ui.card_head("Days between orders", f"Within-course gaps at cadence accounts vs the label cycle"
                     + (f"; {pct:.0f}% on schedule" if pct is not None else ""), right=est("courses"))
        chart(C.dd_intervals(r["intervals"], r["bands"], int(S["cycle_days"]), int(S["max_course_gap_days"]), TH),
              "pdd-int")
    with c2.container(key="card-pdd-terr"):
        ui.card_head("On schedule by territory", "% of reorders inside the on-schedule band")
        if len(r["by_territory"]):
            chart(C.dd_hbar_pct(r["by_territory"], "Territory_Name", "on_schedule", TH), "pdd-terr")
        else:
            st.markdown('<div class="t-small">No reorders at cadence accounts yet.</div>', unsafe_allow_html=True)
    c1, c2 = st.columns(2, gap="medium")
    with c1.container(key="card-pdd-starts"):
        ui.card_head("New course starts and courses running", "Last 18 months", right=est("courses"))
        chart(C.dd_starts(r["starts"], TH), "pdd-starts")
    with c2.container(key="card-pdd-pers"):
        p = r["persistence"]
        sub = (f"{p.n_courses} courses ({p.n_ended} ended); ticks mark ongoing courses"
               + ("; product-level curve: too few courses in this selection" if r["persistence_is_product"]
                  else "" if r["persistence_is_all"] else "; dashed line = all accounts"))
        ui.card_head("Persistence: courses reaching each cycle", sub, right=est("courses"))
        chart(C.dd_persistence(p, TH, None if r["persistence_is_all"] else r["persistence_product"]), "pdd-pers")
        bits = []
        if p.median_cycles:
            bits.append(f"Half of courses have ended by cycle {int(p.median_cycles)}.")
        if p.drop_after_1 is not None:
            bits.append(f"{p.drop_after_1:.0%} stop after cycle 1")
        if p.drop_after_2 is not None:
            bits.append(f"and {p.drop_after_2:.0%} of those reaching cycle 2 stop there.")
        if p.n_excluded:
            bits.append(f"{p.n_excluded} courses already running when the history window starts are left out.")
        st.markdown(f'<div class="t-small">{ui.E(" ".join(bits))}</div>', unsafe_allow_html=True)
    c1, c2 = st.columns(2, gap="medium")
    with c1.container(key="card-pdd-len"):
        ui.card_head("Course length", "Ended courses by number of cycles", right=est("courses"))
        cl = r["course_lengths"]
        if len(cl):
            chart(C.dd_bars(cl.index, cl.values, TH, "Cycles", "Courses",
                            hover="%{x} cycles: <b>%{y}</b> ended courses<extra></extra>"), "pdd-len")
        else:
            st.markdown('<div class="t-small">No ended courses yet.</div>', unsafe_allow_html=True)
    with c2.container(key="card-pdd-paths"):
        if not S.get("fixed_units_per_cycle"):
            ui.card_head("Dose-level paths", "Courses whose inferred dose level changed (trend only)", right=est("courses"))
            dp = r["dose_paths"]
            if len(dp):
                st.dataframe(dp.rename("Courses").rename_axis("Path").reset_index(), hide_index=True, width="stretch")
            else:
                st.markdown('<div class="t-small">No dose-level changes within courses.</div>', unsafe_allow_html=True)
        else:
            ui.card_head("Account regimes", "Why each account is cadence or run-rate")
            st.dataframe(r["regimes"][["account_key", "regime", "reason"]].rename(
                columns={"account_key": "Account key", "regime": "Regime", "reason": "Reason"}),
                hide_index=True, height=260)


# =============================================================================
# 4. Accounts and adoption
# =============================================================================
def render_accounts():
    takeaway("accounts")
    a = dd.accounts
    if a["parents"].empty:
        st.markdown('<div class="t-small">No accounts in this selection.</div>', unsafe_allow_html=True)
        return
    with st.container(key="card-pdd-parents"):
        ui.card_head("Parents and their accounts", "Select a parent to see its accounts; select an account for its "
                     "contract split. Estimated patients use the last 21 days.", right=est("patients"))
        par = a["parents"].copy()
        par["Est. patients"] = [pe.fmt_patients(lo, hi) for lo, hi in zip(par["Patients low"], par["Patients high"])]
        par["Active / total"] = [f"{int(x)} / {int(y)}" for x, y in zip(par["Active"], par["Children"])]
        show = par[["Parent", "Status", "Units QTD", "Units 12 mo", "Share", "Est. patients", "Active / total",
                    "Run-rate children", "Decline pattern"]]
        ev = st.dataframe(show, hide_index=True, on_select="rerun", selection_mode="single-row", key="pdd-par",
                          height=min(420, 35 * len(show) + 38), column_config={
                              "Share": st.column_config.ProgressColumn("Share of 12-mo units", format="percent",
                                                                       min_value=0, max_value=1),
                              "Units QTD": st.column_config.NumberColumn(format="%,.0f"),
                              "Units 12 mo": st.column_config.NumberColumn(format="%,.0f"),
                              "Status": st.column_config.TextColumn(width=90)})
        rows = ev.selection.rows if ev and hasattr(ev, "selection") else []
        if rows:
            pk = par.iloc[rows[0]]["parent_key"]
            kids = a["children"][a["children"]["parent_key"] == pk].copy()
            kids["Est. patients"] = [pe.fmt_patients(lo, hi) for lo, hi in zip(kids["Patients low"], kids["Patients high"])]
            st.markdown(f'<div class="t-label">Accounts under {ui.E(par.iloc[rows[0]]["Parent"])}</div>',
                        unsafe_allow_html=True)
            kv = kids[["Account", "Territory", "Status", "Regime", "Units QTD", "Units 12 mo", "Share", "Est. patients",
                       "Days since last order", "Regime reason"]]
            ek = st.dataframe(kv, hide_index=True, on_select="rerun", selection_mode="single-row", key="pdd-kids",
                              column_config={"Share": st.column_config.ProgressColumn(format="percent", min_value=0,
                                                                                      max_value=1),
                                             "Units QTD": st.column_config.NumberColumn(format="%,.0f"),
                                             "Units 12 mo": st.column_config.NumberColumn(format="%,.0f")})
            krows = ek.selection.rows if ek and hasattr(ek, "selection") else []
            if krows:
                key = kids.iloc[krows[0]]["account_key"]
                sub = df[(df["Product"] == product) & (df["account_key"] == key)]
                st.markdown(f'<div class="t-label">Contract split for {ui.E(kids.iloc[krows[0]]["Account"])} (one DEA '
                            'can carry WAC and 340B accounts)</div>', unsafe_allow_html=True)
                st.dataframe(pe.contract_split(sub), hide_index=True, width="content",
                             column_config={"Share": st.column_config.NumberColumn(format="percent")})
    c1, c2 = st.columns(2, gap="medium")
    with c1.container(key="card-pdd-conc"):
        ui.card_head("Concentration", "Top parents' share of units: this quarter to date vs the same days last quarter")
        cc = a["concentration"]
        st.dataframe(cc.rename(columns={"period": "Period", "top5": "Top 5", "top10": "Top 10", "top20": "Top 20",
                                        "parents": "Parents ordering"}), hide_index=True, width="stretch",
                     column_config={c: st.column_config.NumberColumn(format="%.0f%%") for c in ("Top 5", "Top 10", "Top 20")})
        if len(cc) == 2 and cc["top5"].notna().all():
            ch = cc["top5"].iloc[0] - cc["top5"].iloc[1]
            st.markdown(f'<div class="t-small">Top-5 share {"up" if ch > 0 else "down"} {abs(ch):.0f} points vs last '
                        'quarter.</div>', unsafe_allow_html=True)
    with c2.container(key="card-pdd-bridge"):
        ps, pe_ = a["bridge_prior"]
        ui.card_head("Growth bridge", f"This quarter to date vs {fc.fmt_range((ps, pe_))}, by account")
        chart(C.dd_waterfall(a["bridge"], UNITS, TH), "pdd-bridge")
    c1, c2 = st.columns([1, 1.2], gap="medium")
    co = a["cohorts"]
    with c1.container(key="card-pdd-coh"):
        ui.card_head("Cohorts by first-order quarter", "% reordering within 2 cycles (accounts at least 2 cycles old) "
                     "and median days to the second order")
        if len(co["summary"]):
            st.dataframe(co["summary"].astype({"median_days_to_2nd": float, "reorder_2_cycles": float}).rename(columns={"cohort": "First order", "accounts": "Accounts",
                                                       "reorder_2_cycles": "Reorder within 2 cycles",
                                                       "median_days_to_2nd": "Median days to 2nd order"}),
                         hide_index=True, width="stretch",
                         column_config={"Reorder within 2 cycles": st.column_config.NumberColumn(format="%.0f%%"),
                                        "Median days to 2nd order": st.column_config.NumberColumn(format="%.0f")})
    with c2.container(key="card-pdd-ret"):
        ui.card_head("Retention", "% of each cohort's accounts ordering in later quarters")
        if len(co["retention"]):
            chart(C.dd_heatmap_pct(co["retention"], TH), "pdd-ret")
    if product == "RYZNEUTA":
        ui.note("RYZNEUTA target penetration (OAM_GCSF_Target, GCSF_Decile, Ryzneuta_Ordering_Status) isn't shown: "
                "those customer-master fields aren't pulled yet.", "info")
    with st.container(key="card-pdd-mix"):
        ui.card_head("Mix over time", "Share of units by month, last 12 months. Site of care (SF_Type1) will follow "
                     "once the customer-master fields are pulled.")
        t1, t2, t3, t4 = st.tabs(["Contract", "340B", "Wholesaler", "Returns rate"])
        with t1:
            chart(C.dd_mix(a["contract_mix"], TH), "pdd-mix-c")
        with t2:
            chart(C.dd_mix(a["b340_mix"], TH, order=["Non-340B", "340B"]), "pdd-mix-b")
        with t3:
            chart(C.dd_mix(a["wholesaler_mix"], TH), "pdd-mix-w")
        with t4:
            chart(C.dd_line_pct(a["returns"], "month", "rate", TH,
                                hover="%{x|%b %Y}: <b>%{y:.1f}%</b> of units returned<extra></extra>"), "pdd-ret-rate")
    dup = a["duplicates"]
    if len(dup):
        with st.expander(f"Data quality: {len(dup)} likely duplicate accounts (same name, address and zip, different keys)"):
            st.markdown('<div class="t-small">Listed only; they are not merged.</div>', unsafe_allow_html=True)
            st.dataframe(dup, hide_index=True)


# =============================================================================
# 5. Forecast
# =============================================================================
def render_forecast():
    takeaway("forecast")
    f = dd.forecast
    fo: F.Forecast = f["fc"]
    land = f["landing"]
    with st.container(key="card-pdd-fan"):
        ui.card_head(f"{int(S['forecast_weeks'])}-week forecast", fo.sentence or "Blended forecast")
        for n_ in fo.notes:
            ui.note(n_, "info")
        if len(fo.table):
            chart(C.dd_forecast(fo.history, fo.table, UNITS, int(S["forecast_range_pct"]), TH), "pdd-fan")
            w = ", ".join(f"{k.lower()} {v:.0%}" for k, v in fo.weights.items())
            st.markdown(f'<div class="t-caption">Blend weights (by backtest accuracy): {ui.E(w)}. Account-by-account = '
                        'expected next orders + run-rate weekly volume + new starts at the recent monthly rate.</div>',
                        unsafe_allow_html=True)
    c1, c2 = st.columns([1, 1.3], gap="medium")
    with c1.container(key="card-pdd-land"):
        ui.card_head("Quarter landing", f"{land['quarter']}, ends {fc.fmt_date(land['quarter_end'])}")
        vs = (f"{ui.fmt_pct(land['vs_avg_pct'])} vs the last {land['n_past']} quarters' average "
              f"({land['avg_last3']:,.0f})") if land.get("avg_last3") else "No complete prior quarters to compare"
        st.markdown('<div class="stats4" style="grid-template-columns:repeat(3,1fr)">'
                    f'<div class="stat"><div class="k">Quarter to date</div><div class="v num">{land["qtd"]:,.0f}</div></div>'
                    f'<div class="stat"><div class="k">Forecast for the rest</div><div class="v num">{land["rest"]:,.0f}</div></div>'
                    f'<div class="stat"><div class="k">Projected total</div><div class="v num">{land["projected"]:,.0f}</div></div>'
                    f'</div><div class="t-small">Range {land["lo"]:,.0f}–{land["hi"]:,.0f} {UNITS}; {ui.E(vs)}.</div>',
                    unsafe_allow_html=True)
    with c2.container(key="card-pdd-cal"):
        ui.card_head("Expected orders, this week and the next 6", "Single-patient accounts' next orders and run-rate "
                     "weekly volume, by confidence (new starts not included)")
        chart(C.dd_calendar(f["calendar"], UNITS, TH), "pdd-cal")
    with st.container(key="card-pdd-soon"):
        soon = f["soon"]
        ui.card_head("Accounts expected to order", "Next 7, 14 and 21 days (cadence accounts)", count=len(soon))
        if len(soon):
            t = soon.assign(**{"Expected": soon["expected_date"].dt.date, "Units": soon["expected_units"],
                               "Prob.": soon["probability"], "Owner": soon["Owner"].fillna("—")})
            st.dataframe(t[["Window", "Expected", "Account", "Parent", "Territory", "Owner", "Units", "Prob.",
                            "confidence", "basis"]].rename(columns={"confidence": "Confidence", "basis": "Basis"}),
                         hide_index=True, height=260,
                         column_config={"Units": st.column_config.NumberColumn(format="%.0f"),
                                        "Prob.": st.column_config.NumberColumn(format="percent"),
                                        "Expected": st.column_config.DateColumn(format="MMM D")})
        else:
            st.markdown('<div class="t-small">No cadence accounts are expected to order in the next 21 days.</div>',
                        unsafe_allow_html=True)
    with st.container(key="card-pdd-over"):
        ov = f["overdue"]
        ui.card_head("Overdue accounts", f"Expected date + {int(S['overdue_tolerance_days'])} days passed with no order "
                     f"(as of {fc.fmt_date(dd.as_of)}), ranked by {UNITS} at stake", count=len(ov))
        if len(ov):
            t = ov.assign(Expected=ov["expected_date"].dt.date, Owner=ov["Owner"].fillna("—"))
            st.dataframe(t[["Account", "Parent", "Territory", "Owner", "Expected", "days_overdue", "units_at_stake",
                            "confidence", "explanation"]].rename(columns={
                                "days_overdue": "Days overdue", "units_at_stake": f"{UNITS.capitalize()} at stake",
                                "confidence": "Confidence", "explanation": "Possible explanation"}),
                         hide_index=True, height=260,
                         column_config={f"{UNITS.capitalize()} at stake": st.column_config.NumberColumn(format="%.1f"),
                                        "Expected": st.column_config.DateColumn(format="MMM D")})
        else:
            st.markdown('<div class="t-small">No overdue accounts.</div>', unsafe_allow_html=True)
    rr = f["runrate"]
    if len(rr):
        with st.expander(f"Run-rate accounts: expected weekly {UNITS} ({len(rr)})"):
            st.dataframe(rr[["Account", "Parent", "Territory", "weekly_rate", "w4", "w13", "confidence"]].rename(columns={
                "weekly_rate": "Expected per week", "w4": "Last 4 weeks (avg)", "w13": "Last 13 weeks (avg)",
                "confidence": "Confidence"}), hide_index=True,
                column_config={c: st.column_config.NumberColumn(format="%.1f")
                               for c in ("Expected per week", "Last 4 weeks (avg)", "Last 13 weeks (avg)")})


# =============================================================================
# 6. Field action plan
# =============================================================================
def render_actions():
    takeaway("actions")
    A = dd.actions
    acts: pd.DataFrame = A["actions"]
    with st.container(key="card-pdd-narr"):
        ui.card_head("This week", "Built from the numbers on this page")
        st.markdown('<ul class="narr">' + "".join(f"<li>{ui.E(x)}</li>" for x in A["narrative"]) + "</ul>",
                    unsafe_allow_html=True)
    no = A["new_owners"]
    if len(no):
        names = "; ".join(f"{r.owner_name} ({r.Territory_Name}, since {fc.fmt_date(r.owner_start_date)})"
                          for r in no.itertuples())
        ui.note(f"New to territory (started in the last {config.NEW_TO_TERRITORY_DAYS} days): {names}. Managers may "
                "want to prioritize ride-alongs.", "info")
    c1, c2, c3 = st.columns([2, 2.4, 1.6], vertical_alignment="bottom")
    owners = sorted(acts["owner"].dropna().astype(str).unique()) if len(acts) else []
    ui.init("pdd_owner", "All owners")
    if ss["pdd_owner"] not in ["All owners"] + owners:
        ss["pdd_owner"] = "All owners"
    owner = c1.selectbox("Owner", ["All owners"] + owners, key="pdd_owner")
    ui.init("pdd_act_view", "Top 10 per territory")
    view = c2.segmented_control("View", ["Top 10 per territory", "Region summary", "Trade & operations"],
                                key="pdd_act_view", required=True)
    a = acts if owner == "All owners" else acts[acts["owner"].astype(str) == owner]
    stamp = f"{date.today():%Y%m%d}"
    export = _export_frame(a)
    with c3.container(horizontal=True, gap="small", horizontal_alignment="right"):
        st.download_button("Excel", data=lambda: _excel(export, A), file_name=f"{product.lower()}_field_actions_{stamp}.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           icon=":material/download:", on_click="ignore", key="pdd-xlsx",
                           help="One tab per territory, plus region summary and trade/operations")
        ui.download_csv("CSV", export, f"{product.lower()}_field_actions_{stamp}.csv", "pdd-csv")
    if view == "Top 10 per territory":
        top = F_top(a)
        if top.empty:
            st.markdown('<div class="t-small">No field actions for this selection.</div>', unsafe_allow_html=True)
        for terr, g in top.groupby("Territory_Name", sort=False, dropna=False):
            own = g["owner"].dropna()
            own_txt = own.iloc[0] if len(own) else "Owner not available"
            new_tag = " · New to territory" if g["new_to_territory"].any() else ""
            with st.container(key=f"card-pdd-t-{abs(hash(str(terr))) % 10 ** 8}"):
                n_a = len(g)
                ui.card_head(str(terr), f"{own_txt}{new_tag} · {n_a} action{'s' if n_a != 1 else ''} · "
                                        f"{FA_units(g['units_at_stake'].sum())} at stake")
                st.dataframe(_display(g), hide_index=True, column_config=_cfg(), height=35 * n_a + 38)
    elif view == "Region summary":
        rs = A["region_summary"] if owner == "All owners" else _region(a)
        st.dataframe(rs.rename(columns={"Region_Name": "Region", "action": "Action type", "actions": "Actions",
                                        "units_at_stake": f"{UNITS.capitalize()} at stake"}), hide_index=True,
                     width="stretch", column_config={f"{UNITS.capitalize()} at stake": st.column_config.NumberColumn(format="%.1f")})
    else:
        tr = A["trade"]
        ui.note("These go to trade or operations, not field sales: stocking spikes, unusual returns, contract or 340B "
                "shifts, wholesaler switches and no-charge units.", "info")
        if len(tr):
            st.dataframe(tr.drop(columns=["account_key"]).rename(columns={
                "Territory_Name": "Territory", "account_name": "Account", "parent_name": "Parent", "issue": "Issue",
                "evidence": "Evidence", "route_to": "Route to"}), hide_index=True, width="stretch")
        else:
            st.markdown('<div class="t-small">Nothing to route this week.</div>', unsafe_allow_html=True)
    with st.expander("How actions are ranked"):
        st.markdown(
            f"**Priority = units at stake^{S['w_units']:g} × probability^{S['w_probability']:g} × urgency^{S['w_urgency']:g}** "
            "(weights in Deep dive settings).\n\n"
            "- **Units at stake**: expected units of the missed or next order (cadence), the weekly shortfall × 4 "
            "(run-rate), or average monthly units (lapsed, declines).\n"
            "- **Probability**: the chance the order happens if the field acts, from the persistence curve (Beleodaq "
            "continuation) or forecast confidence.\n"
            f"- **Urgency**: 1 + days overdue ÷ cycle length (max 3) for continuation checks; new starts get 1 + the "
            "cycle-1 drop-off; completed courses 0.5.\n\n"
            "Action types: continuation check, new start follow-through, course likely completed (don't chase), "
            "concentrated decline, lapsed high-value account, RYZNEUTA adoption (one order, no reorder), run-rate "
            "slowdown. Clinical or dosing questions go to Medical Affairs.")


def FA_units(n: float) -> str:
    import field_actions as FA

    return FA.units_text(n, product)


def F_top(a: pd.DataFrame) -> pd.DataFrame:
    import field_actions as FA

    return FA.top_per_territory(a, 10)


def _region(a):
    import field_actions as FA

    return FA.region_summary(a)


def _display(g: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "Account": g["account_name"], "Action": g["action"], "Evidence": g["evidence"],
        f"{UNITS.capitalize()} at stake": g["units_at_stake"], "Due by": g["due_by"].dt.date,
        "Confidence": g["confidence"], "Next step": g["next_step"], "Parent": g["parent_name"],
        "Priority": g["priority"]})


def _cfg():
    return {"Next step": st.column_config.TextColumn(width=260), "Evidence": st.column_config.TextColumn(width=380),
            f"{UNITS.capitalize()} at stake": st.column_config.NumberColumn(format="%.1f", width=80),
            "Due by": st.column_config.DateColumn(format="MMM D", width=70),
            "Priority": st.column_config.NumberColumn(format="%.1f", width=70),
            "Account": st.column_config.TextColumn(width=200, pinned=True)}


def _export_frame(a: pd.DataFrame) -> pd.DataFrame:
    if a.empty:
        return pd.DataFrame(columns=["Region", "Territory", "Owner", "New to territory", "Account", "Account key",
                                     "Parent", "Action", "Next step", "Evidence", "Units at stake", "Probability",
                                     "Due by", "Confidence", "Priority"])
    return pd.DataFrame({
        "Region": a["Region_Name"], "Territory": a["Territory_Name"], "Owner": a["owner"],
        "New to territory": a["new_to_territory"], "Account": a["account_name"], "Account key": a["account_key"],
        "Parent": a["parent_name"], "Action": a["action"], "Next step": a["next_step"], "Evidence": a["evidence"],
        "Units at stake": a["units_at_stake"].round(1), "Probability": a["probability"].round(2),
        "Due by": a["due_by"].dt.date, "Confidence": a["confidence"], "Priority": a["priority"].round(2)})


def _excel(export: pd.DataFrame, A: dict) -> bytes:
    sheets, used = {}, set()
    for terr, g in export.groupby("Territory", dropna=False):
        name = "".join(ch for ch in str(terr) if ch not in '[]:*?/\\')[:31] or "Unaligned"
        base, i = name, 2
        while name in used:
            name = f"{base[:28]}_{i}"
            i += 1
        used.add(name)
        sheets[name] = g.sort_values("Priority", ascending=False)
    sheets["Region summary"] = A["region_summary"]
    sheets["Trade & operations"] = A["trade"].drop(columns=["account_key"], errors="ignore")
    return ui.excel_bytes(sheets)


RENDER = {"Snapshot": render_snapshot, "Demand": render_demand, "Rhythm & persistence": render_rhythm,
          "Accounts": render_accounts, "Forecast": render_forecast, "Field actions": render_actions}
RENDER.get(section, render_snapshot)()

st.markdown(f'<div class="t-caption" style="margin-top:14px">As of the latest {ui.E(product)} invoice '
            f'({fc.fmt_date(dd.as_of)}), across all geographies. History window {fc.fmt_date(dd.history_start)} – '
            f'{fc.fmt_date(dd.as_of)}. Units are {config.QTY_COLUMN}, net of returns. Patient, cycle and course figures '
            'are estimates from account-level shipments and never identify a patient.</div>', unsafe_allow_html=True)
