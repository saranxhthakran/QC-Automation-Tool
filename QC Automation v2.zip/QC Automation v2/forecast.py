"""When quantity is expected: next order per account, overdue accounts, 13-week forecast with a
rolling backtest, and the fiscal-quarter landing.

Cadence accounts: next date = last event + recency-weighted median interval, kept inside the label
on-schedule band; expected units = median of the last 3 events (× probability of continuing for
Beleodaq ongoing courses). Run-rate accounts: expected weekly units from recent weekly volume with
trend (Holt). Fewer than 3 events: product-level fallback, low confidence.

All figures are estimates from account-level shipments. Pure functions, no Streamlit.
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from statistics import NormalDist

import numpy as np
import pandas as pd

import config
import fiscal_calendar as fc
import product_engine as pe

Q = config.QTY_COLUMN
HIGH, MEDIUM, LOW = "High", "Medium", "Low"
CONFIDENCE_ORDER = [HIGH, MEDIUM, LOW]


# =============================================================================
# Small helpers
# =============================================================================
def weighted_median(values, weights) -> float:
    v = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    if len(v) == 0:
        return float("nan")
    o = np.argsort(v)
    v, w = v[o], w[o]
    c = np.cumsum(w)
    return float(v[np.searchsorted(c, c[-1] / 2.0)])


def recency_weights(n: int, half_life: float = 3.0) -> np.ndarray:
    """Most recent interval weighs 1, one `half_life` intervals earlier weighs 0.5."""
    return 0.5 ** (np.arange(n - 1, -1, -1) / half_life)


def holt(y, alpha: float = 0.4, beta: float = 0.2) -> tuple[float, float]:
    """(level, trend) after Holt's linear smoothing; one-step forecast = level + trend."""
    y = np.asarray(y, dtype=float)
    if len(y) == 0:
        return 0.0, 0.0
    level, trend = y[0], (y[1] - y[0]) if len(y) > 1 else 0.0
    for x in y[1:]:
        prev = level
        level = alpha * x + (1 - alpha) * (level + trend)
        trend = beta * (level - prev) + (1 - beta) * trend
    return float(level), float(trend)


def rolling_weeks(df: pd.DataFrame, as_of, n: int = 13, key: str | None = None):
    """Units in n consecutive 7-day windows ending on as_of (oldest first); per key if given."""
    a = pd.Timestamp(as_of)
    lo = a - pd.Timedelta(days=7 * n - 1)
    d = df[(df["Invoice_Date"] >= lo) & (df["Invoice_Date"] <= a)]
    idx = ((d["Invoice_Date"] - lo).dt.days // 7).clip(0, n - 1)
    if key is None:
        return d.groupby(idx)[Q].sum().reindex(range(n), fill_value=0.0).values.astype(float)
    return d.assign(_w=idx).pivot_table(index=key, columns="_w", values=Q, aggfunc="sum",
                                        fill_value=0.0).reindex(columns=range(n), fill_value=0.0)


def band_limits(s: dict) -> tuple[int, int]:
    b = pe.schedule_bands(s)
    return min(x[0] for x in b), max(x[1] for x in b)


# =============================================================================
# Next order per account
# =============================================================================
NEXT_COLUMNS = ["account_key", "regime", "basis", "n_events", "last_event", "interval", "expected_date",
                "expected_units", "weekly_rate", "w4", "w13", "probability", "confidence", "course_status",
                "current_cycle", "is_overdue", "days_overdue", "explanation"]


def next_orders(res: pe.EngineResult, df: pd.DataFrame) -> pd.DataFrame:
    """One row per account with positive history. `df` is the same product rows the engine used."""
    s, as_of = res.settings, res.as_of
    ev = res.events[res.events["net_units"] > 0].sort_values(["account_key", "start"])
    if ev.empty:
        return pd.DataFrame(columns=NEXT_COLUMNS)
    lo, hi = band_limits(s)
    tol = int(s["overdue_tolerance_days"])
    max_gap = int(s["max_course_gap_days"])
    reg = res.regimes.set_index("account_key")
    last_course = res.courses.sort_values("course_no").drop_duplicates("account_key", keep="last").set_index("account_key")
    # product-level fallbacks (cadence accounts)
    cad_keys = reg.index[reg["regime"] == pe.CADENCE]
    cad_ev = ev[ev["account_key"].isin(cad_keys)]
    fb_interval = res.calibration.get("observed_interval") or float(s["cycle_days"])
    fb_interval = float(np.clip(fb_interval, lo, hi))
    fb_units = float(cad_ev["net_units"].median()) if len(cad_ev) else float(s["units_per_cycle"])
    weekly = rolling_weeks(df, as_of, 13, "account_key")
    rows = []
    for key, g in ev.groupby("account_key", sort=False):
        r = reg.loc[key] if key in reg.index else None
        regime = r["regime"] if r is not None else pe.CADENCE
        n = len(g)
        last = g["start"].max()
        row = {"account_key": key, "regime": regime, "n_events": n, "last_event": last, "interval": np.nan,
               "expected_date": pd.NaT, "expected_units": np.nan, "weekly_rate": np.nan, "w4": np.nan,
               "w13": np.nan, "probability": np.nan, "confidence": LOW, "course_status": None,
               "current_cycle": np.nan, "is_overdue": False, "days_overdue": 0, "explanation": ""}
        if regime == pe.RUNRATE:
            y = weekly.loc[key].values if key in weekly.index else np.zeros(13)
            lvl, tr = holt(y)
            mean = y.mean()
            cv = y.std() / mean if mean > 0 else np.inf
            row.update(basis="Weekly volume with trend", weekly_rate=max(0.0, lvl + tr), w4=float(y[-4:].mean()),
                       w13=float(mean), probability=1.0,
                       confidence=HIGH if cv <= 0.5 and n >= 8 else MEDIUM if cv <= 1.0 else LOW)
            rows.append(row)
            continue
        gaps = pe.course_gaps(g["start"], max_gap)
        course = last_course.loc[key] if key in last_course.index else None
        status = course["status"] if course is not None else pe.ONGOING
        cycle = int(course["cycles"]) if course is not None else 1
        if n >= 3 and len(gaps) >= 1:
            interval = float(np.clip(weighted_median(gaps, recency_weights(len(gaps))), lo, hi))
            units = float(g["net_units"].tail(3).median())
            cv = float(np.std(gaps) / np.mean(gaps)) if len(gaps) >= 3 and np.mean(gaps) > 0 else np.nan
            conf = HIGH if (n >= 6 and cv == cv and cv <= 0.3) else MEDIUM if (cv != cv or cv <= 0.6) else LOW
            basis = "Own ordering rhythm"
        else:
            interval, units, conf, basis = fb_interval, fb_units, LOW, "Product-level fallback (fewer than 3 orders)"
        exp = last + pd.Timedelta(days=round(interval))
        p = res.persistence.p_continue(cycle) if not s.get("fixed_units_per_cycle") else 1.0
        if status == pe.ENDED:
            p = 0.0
        overdue_days = int((as_of - exp).days)
        row.update(basis=basis, interval=interval, expected_date=exp, expected_units=units, probability=p,
                   confidence=conf, course_status=status, current_cycle=cycle,
                   is_overdue=bool(status == pe.ONGOING and overdue_days > tol), days_overdue=max(0, overdue_days))
        rows.append(row)
    out = pd.DataFrame(rows, columns=NEXT_COLUMNS)
    out["explanation"] = [explain_overdue(r, res, df) if r.is_overdue else "" for r in out.itertuples()]
    return out


def explain_overdue(r, res: pe.EngineResult, df: pd.DataFrame) -> str:
    """Most likely explanation, phrased as a possibility."""
    s = res.settings
    course = res.courses[res.courses["account_key"] == r.account_key].sort_values("course_no").tail(1)
    med = res.persistence.median_cycles
    if len(course):
        c = course.iloc[0]
        if med is not None and c["cycles"] >= med:
            return (f"The course may have reached a typical length ({int(c['cycles'])} cycles; half of courses stop "
                    f"by cycle {int(med)}).")
        if not s.get("fixed_units_per_cycle") and bool(c["dose_declining"]):
            return f"The dose level was stepping down before the gap ({c['dose_path']})."
    # Volume may have moved to a sibling ship-to under the same parent, via a different wholesaler.
    acc = df[df["account_key"] == r.account_key]
    if len(acc) and "parent_name" in acc:
        parent = acc["parent_name"].iloc[-1]
        main_ws = acc.loc[~acc["is_return"], "Shipper_Name"].mode()
        main_ws = main_ws.iloc[0] if len(main_ws) else None
        sib = df[(df["parent_name"] == parent) & (df["account_key"] != r.account_key) & (~df["is_return"])
                 & (df["Invoice_Date"] > r.last_event)]
        if parent not in (config.UNMAPPED,) and len(sib):
            other = sib[sib["Shipper_Name"] != main_ws]
            if len(other):
                name = other["account_name"].iloc[-1] if "account_name" in other else other["account_key"].iloc[-1]
                return (f"Orders may have moved to {name} under the same parent, through "
                        f"{other['Shipper_Name'].iloc[-1]} instead of {main_ws}.")
    return "No clear pattern."


# =============================================================================
# Bottom-up expected units by day
# =============================================================================
def expected_daily(res: pe.EngineResult, nxt: pd.DataFrame, horizon_days: int,
                   keys: set | None = None) -> pd.DataFrame:
    """Expected units per day for as_of+1 … as_of+horizon_days, by source and confidence.

    Cadence: the next order and later cycles every `interval` days, weighted by the probability of the course
    continuing (Kaplan–Meier). An overdue order is placed 3 days out at half its probability.
    Run-rate: the expected weekly rate spread evenly over days.
    New starts: recent monthly start rate × the persistence curve × typical cycle units.
    """
    s, as_of = res.settings, res.as_of
    days = pd.date_range(as_of + pd.Timedelta(days=1), periods=horizon_days, freq="D")
    rows = []
    n = nxt if keys is None else nxt[nxt["account_key"].isin(keys)]
    upc = float(s["units_per_cycle"])
    for r in n.itertuples():
        if r.regime == pe.RUNRATE:
            if r.weekly_rate and r.weekly_rate > 0:
                for d in days:
                    rows.append((d, r.account_key, r.weekly_rate / 7.0, r.confidence, "Run-rate"))
            continue
        if not (r.probability and r.probability > 0) or pd.isna(r.expected_date):
            continue
        d = r.expected_date
        p = 1.0 if s.get("fixed_units_per_cycle") else float(r.probability)
        if d <= as_of:
            d = as_of + pd.Timedelta(days=3)
            p *= 0.5
        cyc = int(r.current_cycle) if r.current_cycle == r.current_cycle else 1
        while d <= days[-1]:
            rows.append((d, r.account_key, float(r.expected_units) * p, r.confidence, "Cadence"))
            cyc += 1
            p *= res.persistence.p_continue(cyc)
            d = d + pd.Timedelta(days=round(r.interval))
    # new starts
    known = res.courses[~res.courses["left_censored"]]
    if keys is not None:
        known = known[known["account_key"].isin(keys)]
    recent = known[known["start"] > as_of - pd.Timedelta(days=182)]
    rate_per_day = len(recent) / 182.0
    if rate_per_day > 0:
        first_units = float(res.events.merge(known[["account_key", "start"]], on=["account_key", "start"])["net_units"].median())
        first_units = first_units if first_units == first_units else upc
        surv = res.persistence.table.set_index("cycle")["survival"] if len(res.persistence.table) else pd.Series({1: 1.0})
        cyc_days = int(s["cycle_days"])
        for i, d in enumerate(days):
            for j in range(0, (horizon_days - i - 1) // cyc_days + 1):
                sj = float(surv.get(j + 1, surv.iloc[-1]))
                rows.append((d + pd.Timedelta(days=j * cyc_days), None, rate_per_day * first_units * sj, LOW, "New starts"))
    out = pd.DataFrame(rows, columns=["date", "account_key", "units", "confidence", "source"])
    return out[out["date"] <= days[-1]]


def bottom_up_weekly(daily: pd.DataFrame, week_starts) -> pd.Series:
    if daily.empty:
        return pd.Series(0.0, index=pd.DatetimeIndex(week_starts))
    ws = daily["date"] - pd.to_timedelta(daily["date"].dt.weekday, unit="D")
    return daily.groupby(ws)["units"].sum().reindex(pd.DatetimeIndex(week_starts), fill_value=0.0)


def calendar_6w(daily: pd.DataFrame, as_of) -> pd.DataFrame:
    """Expected units per week for the next 6 weeks, stacked by confidence (cadence + run-rate only)."""
    d = daily[daily["source"] != "New starts"]
    first = pd.Timestamp(fc.week_start(fc.to_date(as_of)))
    weeks = pd.date_range(first, periods=7, freq="7D")[:7]
    ws = d["date"] - pd.to_timedelta(d["date"].dt.weekday, unit="D")
    t = d.assign(_w=ws).pivot_table(index="_w", columns="confidence", values="units", aggfunc="sum", fill_value=0.0)
    t = t.reindex(weeks, fill_value=0.0).reindex(columns=CONFIDENCE_ORDER, fill_value=0.0)
    t.index.name = "week_start"
    return t.head(7)


# =============================================================================
# 13-week forecast with a rolling backtest
# =============================================================================
@dataclass
class Forecast:
    history: pd.DataFrame = field(default_factory=pd.DataFrame)      # week_start, units (complete weeks + current)
    table: pd.DataFrame = field(default_factory=pd.DataFrame)        # week_start, bottom_up, ets, snaive, blend, lo, hi
    weights: dict = field(default_factory=dict)
    wape: dict = field(default_factory=dict)
    backtest_weeks: int = 0
    snaive_label: str = "Seasonal naive"
    sentence: str = ""
    notes: list = field(default_factory=list)


def ets_forecast(y: np.ndarray, h: int) -> np.ndarray:
    """Damped-trend exponential smoothing (statsmodels); simple smoothing for short series."""
    y = np.asarray(y, dtype=float)
    if len(y) < 4:
        return np.repeat(y.mean() if len(y) else 0.0, h)
    try:
        from statsmodels.tsa.holtwinters import ExponentialSmoothing, SimpleExpSmoothing

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if len(y) >= 16:
                m = ExponentialSmoothing(y, trend="add", damped_trend=True, initialization_method="estimated").fit()
            else:
                m = SimpleExpSmoothing(y, initialization_method="estimated").fit()
            f = np.asarray(m.forecast(h), dtype=float)
    except Exception:  # noqa: BLE001 - statsmodels missing or failed: fall back to Holt
        lvl, tr = holt(y)
        f = lvl + tr * np.arange(1, h + 1)
    return np.clip(np.nan_to_num(f), 0, None)


def snaive_forecast(y: np.ndarray, h: int) -> tuple[np.ndarray, str]:
    """Same week last year when there are ≥ 65 weeks; otherwise the last-4-week average."""
    y = np.asarray(y, dtype=float)
    if len(y) >= 65:
        return np.array([y[len(y) - 52 + (i % 52)] for i in range(h)]), "Seasonal naive (same week last year)"
    base = y[-4:].mean() if len(y) else 0.0
    return np.repeat(base, h), "Naive (last-4-week average)"


def wape(actual, fcst) -> float | None:
    a, f = np.asarray(actual, dtype=float), np.asarray(fcst, dtype=float)
    den = np.abs(a).sum()
    return float(np.abs(a - f).sum() / den * 100) if den > 0 else None


def forecast_13w(df: pd.DataFrame, res: pe.EngineResult, nxt: pd.DataFrame, keys: set | None = None,
                 backtest_engine=None, backtest_weeks: int = 12, backtest_h: int = 4) -> Forecast:
    """df: product rows for the selection. backtest_engine(cutoff) -> (EngineResult, next_orders) for the
    bottom-up backtest (None skips the bottom-up backtest)."""
    s, as_of = res.settings, res.as_of
    H = int(s["forecast_weeks"])
    cur = pd.Timestamp(fc.week_start(fc.to_date(as_of)))
    wk = pe.full_weekly(df, as_of)
    hist = pd.DataFrame({"week_start": wk.index, "units": wk.values})
    complete = wk[wk.index < cur]                      # train on complete weeks only
    y = complete.values.astype(float)
    weeks = pd.date_range(cur, periods=H + 1, freq="7D")          # current (partial) week + H weeks
    out = Forecast(history=hist)
    if len(y) < 4:
        out.notes.append("Fewer than 4 complete weeks of history, so there is no forecast.")
        return out

    # top-down: forecast from the last complete week; step 1 = current week
    ets = ets_forecast(y, H + 1)
    sn, sn_label = snaive_forecast(y, H + 1)
    out.snaive_label = sn_label
    # bottom-up
    daily = expected_daily(res, nxt, (weeks[-1] + pd.Timedelta(days=6) - as_of).days, keys)
    bu = bottom_up_weekly(daily, weeks).values
    this_week_actual = float(wk.get(cur, 0.0))
    bu[0] += this_week_actual                          # current week = actual so far + expected rest

    # rolling backtest over the last `backtest_weeks` complete weeks
    errs = {"Bottom-up": ([], []), "Smoothing": ([], []), "Seasonal naive": ([], []), "Blend": ([], [])}
    origins = [cur - pd.Timedelta(weeks=k) for k in range(backtest_weeks, 0, -1)]
    pairs = []
    for o in origins:
        train = complete[complete.index < o].values
        if len(train) < 8:
            continue
        test = complete[(complete.index >= o)].head(backtest_h)
        if test.empty:
            continue
        h = len(test)
        f_e = ets_forecast(train, h)
        f_s, _ = snaive_forecast(train, h)
        f_b = None
        if backtest_engine is not None:
            try:
                r_o, n_o = backtest_engine(o - pd.Timedelta(days=1))
                d_o = expected_daily(r_o, n_o, h * 7, keys)
                f_b = bottom_up_weekly(d_o, test.index).values
            except Exception:  # noqa: BLE001 - a failed origin is skipped
                f_b = None
        pairs.append((test.values, f_b, f_e, f_s))
    if pairs:
        for a, f_b, f_e, f_s in pairs:
            if f_b is not None:
                errs["Bottom-up"][0].extend(a)
                errs["Bottom-up"][1].extend(f_b)
            errs["Smoothing"][0].extend(a)
            errs["Smoothing"][1].extend(f_e)
            errs["Seasonal naive"][0].extend(a)
            errs["Seasonal naive"][1].extend(f_s)
        out.wape = {k: wape(*v) for k, v in errs.items() if k != "Blend" and len(v[0])}
        out.backtest_weeks = len(pairs)
    fcs = {"Bottom-up": bu, "Smoothing": ets, "Seasonal naive": sn}
    valid = {k: v for k, v in out.wape.items() if v is not None}
    if valid:
        inv = {k: 1.0 / max(v, 1.0) for k, v in valid.items()}
        tot = sum(inv.values())
        out.weights = {k: inv[k] / tot for k in inv}
    else:
        out.weights = {k: 1 / 3 for k in fcs}
        out.notes.append("Too little history for a backtest, so the three methods are weighted equally.")
    blend = sum(out.weights.get(k, 0) * v for k, v in fcs.items())
    # error band from the blended backtest errors
    resid = []
    for a, f_b, f_e, f_s in pairs:
        parts = {"Bottom-up": f_b, "Smoothing": f_e, "Seasonal naive": f_s}
        wsum = sum(out.weights.get(k, 0) for k, v in parts.items() if v is not None)
        if wsum <= 0:
            continue
        fb = sum(out.weights.get(k, 0) * v for k, v in parts.items() if v is not None) / wsum
        resid.extend(np.asarray(a) - fb)
        errs["Blend"][0].extend(a)
        errs["Blend"][1].extend(fb)
    if errs["Blend"][0]:
        out.wape["Blend"] = wape(*errs["Blend"])
    sd = float(np.std(resid)) if len(resid) >= 4 else float(np.std(y[-13:])) if len(y) >= 4 else 0.0
    z = NormalDist().inv_cdf(0.5 + float(s["forecast_range_pct"]) / 200.0)
    steps = np.arange(1, H + 2)
    spread = z * sd * np.sqrt(steps / max(1.0, (backtest_h + 1) / 2))
    spread[0] = spread[0] * max(0.0, (6 - fc.to_date(as_of).weekday()) / 7)   # current week: only the rest is uncertain
    out.table = pd.DataFrame({"week_start": weeks, "bottom_up": bu, "ets": ets, "snaive": sn, "blend": blend,
                              "lo": np.clip(blend - spread, 0, None), "hi": blend + spread})
    out.table["is_current"] = out.table["week_start"] == cur
    out.sentence = backtest_sentence(out)
    return out


def backtest_sentence(f: Forecast) -> str:
    if not f.wape:
        return "There isn't enough history yet to test the forecast against past weeks."
    names = {"Bottom-up": "account-by-account", "Smoothing": "smoothing", "Seasonal naive": f.snaive_label.split(" (")[0].lower()}
    parts = [f"{names[k]} {v:.0f}%" for k, v in f.wape.items() if k in names and v is not None]
    blend = f.wape.get("Blend")
    s = (f"Tested on the last {f.backtest_weeks} weeks, 1–4-week forecasts were off by "
         + ", ".join(parts) + " of actual units (WAPE)")
    return s + (f"; the blend was off by {blend:.0f}%." if blend is not None else ".")


# =============================================================================
# Quarter landing
# =============================================================================
def quarter_landing(df: pd.DataFrame, f: Forecast, as_of, daily: pd.DataFrame | None = None) -> dict:
    """QTD actual + forecast for the rest of the fiscal quarter, with range, vs the last 3 quarters' average."""
    md = fc.to_date(as_of)
    qs, qe = fc.quarter_start(md), fc.quarter_end(md)
    qtd = float(df[(df["Invoice_Date"] >= pd.Timestamp(qs)) & (df["Invoice_Date"] <= pd.Timestamp(md))][Q].sum())
    past = []
    for k in (1, 2, 3):
        s_ = fc.shift_quarter(qs, -k)
        e_ = fc.quarter_end(s_)
        if df.empty or pd.Timestamp(s_) < df["Invoice_Date"].min() - pd.Timedelta(days=7):
            continue
        past.append(float(df[(df["Invoice_Date"] >= pd.Timestamp(s_)) & (df["Invoice_Date"] <= pd.Timestamp(e_))][Q].sum()))
    rest, var = 0.0, 0.0
    if not f.table.empty:
        a = pd.Timestamp(md)
        for r in f.table.itertuples():
            w0, w1 = r.week_start, r.week_start + pd.Timedelta(days=6)
            lo_d = max(w0, a + pd.Timedelta(days=1))
            hi_d = min(w1, pd.Timestamp(qe))
            if hi_d < lo_d:
                continue
            days_in = (hi_d - lo_d).days + 1
            if r.is_current:
                remaining = max(0.0, r.blend - float(f.history.set_index("week_start")["units"].get(w0, 0.0)))
                rem_days = (w1 - a).days
                share = days_in / rem_days if rem_days > 0 else 0.0
                rest += remaining * share
                var += ((r.hi - r.blend) * share) ** 2
            else:
                share = days_in / 7.0
                rest += r.blend * share
                var += ((r.hi - r.blend) * share) ** 2
    proj = qtd + rest
    half = float(np.sqrt(var))
    avg = float(np.mean(past)) if past else None
    return {"quarter": fc.quarter_label(md), "qtd": qtd, "rest": rest, "projected": proj,
            "lo": max(qtd, proj - half), "hi": proj + half, "avg_last3": avg, "n_past": len(past),
            "vs_avg_pct": (proj - avg) / avg * 100 if avg else None, "quarter_end": qe}
