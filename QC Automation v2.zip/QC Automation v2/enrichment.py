"""Territory alignment and customer-master (parent) enrichment, with conflict logs.

Both joins are LEFT joins done in pandas and must preserve the 867 row count.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

import config
from data_prep import clean_frame, normalize_combo, normalize_upper, normalize_zip

Q = config.QTY_COLUMN  # analysis quantity (Factored_QTY), returns negative


class JoinCheckError(Exception):
    """Raised when a join would change the 867 row count."""

    def __init__(self, message: str, detail: pd.DataFrame | None = None):
        super().__init__(message)
        self.detail = detail if detail is not None else pd.DataFrame()


# =============================================================================
# Territory alignment
# =============================================================================
@dataclass
class AlignmentResult:
    table: pd.DataFrame                    # one row per ZIPCode
    file_id: str | None
    file_ids: list[str]
    warnings: list[str] = field(default_factory=list)
    duplicates: pd.DataFrame = field(default_factory=pd.DataFrame)


def _fileid_sort_key(v: str):
    try:
        return (0, float(v))
    except (TypeError, ValueError):
        return (1, str(v))


def check_alignment_summary(summary: pd.DataFrame, team: str = config.TEAM) -> list[str]:
    """Warnings for the Team/FileID check query result."""
    warns = []
    if summary is None or summary.empty:
        return [f"The territory alignment table is empty."]
    s = summary.copy()
    s["Team"] = s["Team"].astype(str).str.strip()
    t = s[s["Team"].str.upper() == team.upper()]
    if t.empty:
        warns.append(f"Team {team} is missing from the territory alignment. Every zip will be Unaligned.")
        return warns
    if len(t) > 1:
        ids = ", ".join(sorted(t["FileID"].astype(str), key=_fileid_sort_key))
        warns.append(f"Team {team} has several FileIDs ({ids}); the latest is used as the current alignment.")
    dup = t[t["Rows"].astype(int) > t["Zips"].astype(int)]
    for _, r in dup.iterrows():
        warns.append(f"FileID {r['FileID']} has {int(r['Rows']) - int(r['Zips'])} duplicated zip rows for team {team}.")
    return warns


def prepare_alignment(raw: pd.DataFrame, team: str = config.TEAM,
                      file_id: str | None = config.ALIGNMENT_FILE_ID) -> AlignmentResult:
    df = clean_frame(raw)
    df = df[normalize_upper(df["Team"]) == team.upper()].copy()
    warnings: list[str] = []
    file_ids = sorted(df["FileID"].dropna().astype(str).unique().tolist(), key=_fileid_sort_key)
    chosen = None
    if df.empty:
        warnings.append(f"No alignment rows for team {team}. Every zip will be Unaligned.")
    else:
        chosen = str(file_id) if file_id is not None else file_ids[-1] if file_ids else None
        if chosen is not None:
            if chosen not in file_ids:
                raise ValueError(f"FileID {chosen} doesn't exist for team {team}. Available: {', '.join(file_ids)}")
            df = df[df["FileID"].astype(str) == chosen].copy()
        if len(file_ids) > 1:
            warnings.append(f"{len(file_ids)} FileIDs found for team {team}; using {chosen} as the current alignment.")

    df["ZIPCode"] = normalize_zip(df["ZIPCode"])
    df = df[df["ZIPCode"].notna()]
    cols = ["ZIPCode", "Region_ID", "Region_Name", "Territory_ID", "Territory_Name"]
    counts = df.groupby("ZIPCode").size()
    dup_zips = counts[counts > 1].index
    duplicates = df[df["ZIPCode"].isin(dup_zips)][cols + ["FileID"]].sort_values("ZIPCode")
    if len(dup_zips):
        conflicting = df[df["ZIPCode"].isin(dup_zips)].groupby("ZIPCode")["Territory_ID"].nunique()
        n_conf = int((conflicting > 1).sum())
        warnings.append(
            f"{len(dup_zips)} zips appear more than once for team {team}"
            + (f" ({n_conf} with different territories; the first row is kept)" if n_conf else " (identical rows; de-duplicated)")
            + "."
        )
    table = df[cols].drop_duplicates("ZIPCode", keep="first").reset_index(drop=True)
    return AlignmentResult(table, chosen, file_ids, warnings, duplicates)


def apply_alignment(sales: pd.DataFrame, alignment: AlignmentResult) -> pd.DataFrame:
    n = len(sales)
    a = alignment.table
    if a["ZIPCode"].duplicated().any():
        d = a[a["ZIPCode"].duplicated(keep=False)]
        raise JoinCheckError(
            f"Territory matching would double-count sales: {d['ZIPCode'].nunique()} zips appear more than once "
            f"for team {config.TEAM}. See the duplicate list below.", d)
    geo_cols = ["Region_ID", "Region_Name", "Territory_ID", "Territory_Name", "CAM_Territory_Name"]   # CAM dropped if present
    base = sales.drop(columns=[c for c in geo_cols if c in sales.columns])
    out = base.merge(a.rename(columns={"ZIPCode": "zip5"}), on="zip5", how="left")
    if len(out) != n:
        dup = a[a["ZIPCode"].isin(a["ZIPCode"][a["ZIPCode"].duplicated()])]
        raise JoinCheckError(
            f"Territory matching would double-count sales: the row count changed from {n:,} to {len(out):,}.", dup)
    out["aligned"] = out["Territory_ID"].notna()
    for c in ["Region_ID", "Territory_ID"]:
        out[c] = out[c].astype("string").fillna(config.UNALIGNED)
    for c in ["Region_Name", "Territory_Name"]:
        out[c] = out[c].astype("string").fillna(config.UNALIGNED)
    return out


def ptcl_crosscheck(sales: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compare 867 PTCL_BELEODAQ 'Fusion' flag with the zip join. Information only."""
    b = sales[sales["Product"] == "BELEODAQ"]
    if b.empty or "PTCL_BELEODAQ" not in b:
        return pd.DataFrame(), pd.DataFrame()
    flag = b["PTCL_BELEODAQ"].astype("string").str.upper().str.contains(config.TEAM.upper(), na=False)
    aligned = b["aligned"]
    summary = pd.DataFrame({
        "Check": ["Flagged Fusion and aligned", "Flagged Fusion, not aligned", "Not flagged, aligned", "Neither"],
        "Rows": [int((flag & aligned).sum()), int((flag & ~aligned).sum()),
                 int((~flag & aligned).sum()), int((~flag & ~aligned).sum())],
    })
    mm = b[flag != aligned]
    detail = (mm.assign(PTCL_flag=np.where(flag[mm.index], "Fusion", "—"))
              .groupby(["zip5", "Ship_To_State", "PTCL_flag", "Territory_Name"], dropna=False)
              .agg(rows=(Q, "size"), units=(Q, "sum"))
              .reset_index().sort_values("rows", ascending=False))
    return summary, detail


# =============================================================================
# Customer master
# =============================================================================
@dataclass
class ParentMatchResult:
    sales: pd.DataFrame
    shipto_parents: pd.DataFrame      # one row per account_key
    lookup_conflicts: pd.DataFrame    # key -> several parents
    shipto_conflicts: pd.DataFrame    # ship-to rows matched different parents
    method_summary: pd.DataFrame
    unmapped: pd.DataFrame


def prepare_customer_master(raw: pd.DataFrame) -> pd.DataFrame:
    cm = clean_frame(raw, extra_nulls={"SF_External_ID": {"-"}})
    for c in config.REQUIRED_CUSTOMER_MASTER:
        if c not in cm:
            cm[c] = pd.Series(pd.NA, index=cm.index, dtype="string")
    cm["SF_External_ID"] = normalize_upper(cm["SF_External_ID"])
    cm["ED_ID"] = normalize_upper(cm["ED_ID"])
    cm["combo_norm"] = normalize_combo(cm["COMBO"])
    own_type = cm.get("SF_Type", pd.Series(pd.NA, index=cm.index)).astype("string")
    rec = cm["Parent_RecordTypeName"].astype("string")

    no_parent = cm["Parent_SFCD"].isna()
    self_parent = cm["Parent_SFCD"].eq(cm["SFCD_ID"]).fillna(False)
    # A self-parented account is standalone, unless it is itself a corporate account.
    is_corp_self = self_parent & (rec.eq("Corporate_Account").fillna(False) | own_type.eq("Corporate_Account").fillna(False))
    standalone = no_parent | (self_parent & ~is_corp_self)

    cm["parent_key"] = cm["Parent_SFCD"].where(~standalone, cm["SFCD_ID"])
    cm["parent_name"] = cm["Parent_Name"].where(~standalone, cm["SF_Name"].fillna("Unnamed account") + config.STANDALONE_SUFFIX)
    cm["parent_name"] = cm["parent_name"].fillna(cm["SF_Name"])
    cm["is_corporate"] = rec.eq("Corporate_Account").fillna(False) & ~standalone
    cm["is_archived"] = rec.str.startswith("Archived").fillna(False)
    return cm


def build_lookup(cm: pd.DataFrame, key_col: str, method: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """key -> exactly one parent. Tie-break: Corporate_Account, non-archived, most frequent."""
    d = cm[cm[key_col].notna() & cm["parent_key"].notna()]
    if d.empty:
        return (pd.DataFrame(columns=["key", "parent_key", "parent_name", "SFCD_ID"]),
                pd.DataFrame(columns=["method", "key", "candidates", "chosen_parent", "reason"]))
    g = (d.groupby([key_col, "parent_key"])
         .agg(parent_name=("parent_name", "first"), SFCD_ID=("SFCD_ID", "first"),
              corp=("is_corporate", "max"), archived=("is_archived", "min"), n=("parent_key", "size"))
         .reset_index())
    g["non_archived"] = ~g["archived"].astype(bool)
    g = g.sort_values([key_col, "corp", "non_archived", "n", "parent_key"],
                      ascending=[True, False, False, False, True])
    chosen = g.drop_duplicates(key_col).rename(columns={key_col: "key"})
    multi = g.groupby(key_col)["parent_key"].transform("size") > 1
    conflicts = []
    if multi.any():
        for key, grp in g[multi].groupby(key_col, sort=False):
            top = grp.iloc[0]
            second = grp.iloc[1]
            if top["corp"] != second["corp"]:
                reason = "Corporate_Account preferred"
            elif top["non_archived"] != second["non_archived"]:
                reason = "Non-archived record preferred"
            elif top["n"] != second["n"]:
                reason = "Most frequent parent"
            else:
                reason = "Tie; first parent ID alphabetically"
            conflicts.append({
                "method": method, "key": key,
                "candidates": " | ".join(f"{r.parent_name} ({r.parent_key}, {r.n} rows)" for r in grp.itertuples()),
                "chosen_parent": f"{top['parent_name']} ({top['parent_key']})", "reason": reason,
            })
    return (chosen[["key", "parent_key", "parent_name", "SFCD_ID"]].reset_index(drop=True),
            pd.DataFrame(conflicts, columns=["method", "key", "candidates", "chosen_parent", "reason"]))


def match_parents(sales: pd.DataFrame, cm_raw: pd.DataFrame | None) -> ParentMatchResult:
    n = len(sales)
    cm = prepare_customer_master(cm_raw) if cm_raw is not None and len(cm_raw) else None
    lookups, conflicts = {}, []
    if cm is not None:
        for key_col, method in [("combo_norm", "COMBO"), ("ED_ID", "Outlet ID"), ("SF_External_ID", "SPOR")]:
            lk, cf = build_lookup(cm, key_col, method)
            lookups[method] = lk
            conflicts.append(cf)
    lookup_conflicts = pd.concat(conflicts, ignore_index=True) if conflicts else pd.DataFrame(
        columns=["method", "key", "candidates", "chosen_parent", "reason"])

    # Work on distinct identifier combinations, not every row.
    combos = (sales.groupby(["account_key", "combo_norm", "SPORPL"], dropna=False)
              .agg(last_date=("Invoice_Date", "max"), units=(Q, "sum"))
              .reset_index())
    combos["method"] = pd.NA
    combos["parent_key"] = pd.NA
    combos["parent_name"] = pd.NA
    combos["cm_sfcd"] = pd.NA
    source_col = {"COMBO": "combo_norm", "Outlet ID": "account_key", "SPOR": "SPORPL"}
    for method in config.MATCH_METHODS:
        lk = lookups.get(method)
        if lk is None or lk.empty:
            continue
        todo = combos["method"].isna()
        m = combos.loc[todo, [source_col[method]]].merge(
            lk, left_on=source_col[method], right_on="key", how="left")
        m.index = combos.index[todo]
        hit = m["parent_key"].notna()
        idx = m.index[hit]
        combos.loc[idx, "method"] = method
        combos.loc[idx, "parent_key"] = m.loc[hit, "parent_key"].values
        combos.loc[idx, "parent_name"] = m.loc[hit, "parent_name"].values
        combos.loc[idx, "cm_sfcd"] = m.loc[hit, "SFCD_ID"].values

    # Resolve at ship-to level: parent from the most recent matched invoice.
    prio = {m: i for i, m in enumerate(config.MATCH_METHODS)}
    matched = combos[combos["method"].notna()].copy()
    matched["_prio"] = matched["method"].map(prio)
    matched = matched.sort_values(["account_key", "last_date", "_prio"], ascending=[True, False, True])
    resolved = matched.drop_duplicates("account_key")[["account_key", "method", "parent_key", "parent_name", "cm_sfcd"]]

    nparents = matched.groupby("account_key")["parent_key"].nunique()
    split_keys = nparents[nparents > 1].index
    shipto_conflicts = (matched[matched["account_key"].isin(split_keys)]
                        .groupby(["account_key", "parent_key", "parent_name", "method"], dropna=False)
                        .agg(last_matched_invoice=("last_date", "max"), units=("units", "sum"))
                        .reset_index().sort_values(["account_key", "last_matched_invoice"], ascending=[True, False]))
    if not shipto_conflicts.empty:
        chosen = resolved.set_index("account_key")["parent_key"]
        shipto_conflicts["chosen"] = shipto_conflicts["parent_key"].eq(shipto_conflicts["account_key"].map(chosen))

    accounts = sales.groupby("account_key").agg(units=(Q, "sum"), rows=(Q, "size"),
                                                 account_label=("account_label", "first")).reset_index()
    shipto = accounts.merge(resolved, on="account_key", how="left", validate="one_to_one")
    shipto["method"] = shipto["method"].fillna(config.UNMAPPED)
    shipto["parent_key"] = shipto["parent_key"].fillna(config.UNMAPPED)
    shipto["parent_name"] = shipto["parent_name"].fillna(config.UNMAPPED)

    base = sales.drop(columns=[c for c in ["parent_key", "parent_name", "match_method"] if c in sales])
    out = base.merge(shipto[["account_key", "parent_key", "parent_name", "method"]]
                     .rename(columns={"method": "match_method"}),
                     on="account_key", how="left", validate="many_to_one")
    if len(out) != n:
        raise JoinCheckError(f"Parent matching changed the row count from {n:,} to {len(out):,}.")
    for c in ["parent_key", "parent_name", "match_method"]:
        out[c] = out[c].astype("string")

    total_st, total_u = len(shipto), shipto["units"].sum()
    rows = []
    for mth in config.MATCH_METHODS + [config.UNMAPPED]:
        s = shipto[shipto["method"] == mth]
        rows.append({"Method": mth, "Ship-tos": len(s),
                     "% of ship-tos": 100 * len(s) / total_st if total_st else 0.0,
                     "Units": s["units"].sum(),
                     "% of units": 100 * s["units"].sum() / total_u if total_u else 0.0})
    method_summary = pd.DataFrame(rows)
    unmapped = (shipto[shipto["method"] == config.UNMAPPED]
                .sort_values("units", ascending=False)[["account_key", "account_label", "units", "rows"]])
    return ParentMatchResult(out, shipto, lookup_conflicts, shipto_conflicts, method_summary, unmapped)


# =============================================================================
# Full pipeline
# =============================================================================
@dataclass
class EnrichedData:
    sales: pd.DataFrame
    alignment: AlignmentResult
    parents: ParentMatchResult
    prep_info: dict
    ptcl_summary: pd.DataFrame
    ptcl_detail: pd.DataFrame
    people: object = None          # territory_people.TerritoryPeople, or None when not loaded

    def quality(self) -> dict:
        s = self.sales
        by_prod = (s.groupby("Product").agg(first=("Invoice_Date", "min"), last=("Invoice_Date", "max"),
                                            rows=("Product", "size"), units=(Q, "sum"))
                   .reset_index()) if len(s) else pd.DataFrame()
        aligned_units = s.loc[s["aligned"], Q].sum()
        tot_units = s[Q].sum()
        return {
            "rows": len(s),
            "accounts": int(s["account_key"].nunique()),
            "return_rows": int(s["is_return"].sum()),
            "null_key_rows": int(self.prep_info.get("null_dea_rows", 0)),
            "unidentified_rows": int(self.prep_info.get("unidentified_rows", 0)),
            "unaligned_rows": int((~s["aligned"]).sum()),
            "aligned_row_pct": 100 * s["aligned"].mean() if len(s) else 0.0,
            "aligned_unit_pct": 100 * aligned_units / tot_units if tot_units else 0.0,
            "unaligned_zips": s.loc[~s["aligned"], "zip5"].nunique(),
            "unmapped_shiptos": int((self.parents.shipto_parents["method"] == config.UNMAPPED).sum()),
            "by_product": by_prod,
            "lookup_conflicts": len(self.parents.lookup_conflicts),
            "shipto_conflicts": int(self.parents.shipto_conflicts["account_key"].nunique()) if len(self.parents.shipto_conflicts) else 0,
            "qty_column": self.prep_info.get("qty_column", config.QTY_COLUMN),
            "qty_source_counts": self.prep_info.get("qty_source_counts", {}),
            "positive_returns_fixed": int(self.prep_info.get("positive_returns_fixed", 0)),
            "negative_sale_rows": int(self.prep_info.get("negative_sale_rows", 0)),
            "factor_not_one_rows": int(self.prep_info.get("factor_not_one_rows", 0)),
            "factor_mismatch_rows": int(self.prep_info.get("factor_mismatch_rows", 0)),
            "factored_vs_converted_diff_rows": int(self.prep_info.get("factored_vs_converted_diff_rows", 0)),
        }

    def quantity_checks(self) -> pd.DataFrame:
        """Plain-English quantity checks for the data-quality page."""
        q = self.quality()
        fallback = {k: v for k, v in q["qty_source_counts"].items() if k != config.QTY_COLUMN}
        rows = [
            ("Units column", f"{q['qty_column']} (Sold_Qty × Factor), returns negative"),
            ("Rows using a fallback quantity",
             ", ".join(f"{v:,} from {k}" for k, v in fallback.items()) if fallback else "None"),
            ("Return rows with a positive quantity (made negative)", f"{q['positive_returns_fixed']:,}"),
            ("Sales rows with a negative quantity (left as is)", f"{q['negative_sale_rows']:,}"),
            ("Rows with Factor ≠ 1", f"{q['factor_not_one_rows']:,}"),
            ("Rows where Factored_QTY ≠ Sold_Qty × Factor", f"{q['factor_mismatch_rows']:,}"),
            ("Rows where Factored_QTY ≠ Converted_QTY", f"{q['factored_vs_converted_diff_rows']:,}"),
        ]
        return pd.DataFrame(rows, columns=["Check", "Result"])


def enrich(sales_raw: pd.DataFrame, alignment_raw: pd.DataFrame, cm_raw: pd.DataFrame | None,
           team: str = config.TEAM, file_id: str | None = config.ALIGNMENT_FILE_ID,
           products: list[str] | None = None, steps=None) -> EnrichedData:
    """Run cleaning and both joins. `steps` is an optional callback(name) for progress reporting."""
    from data_prep import prepare_sales

    sales, info = prepare_sales(sales_raw, products)
    if steps:
        steps("Matching territories")
    al = prepare_alignment(alignment_raw, team, file_id)
    sales = apply_alignment(sales, al)
    if steps:
        steps("Matching parents")
    pm = match_parents(sales, cm_raw)
    ps, pd_ = ptcl_crosscheck(pm.sales)
    return EnrichedData(pm.sales, al, pm, info, ps, pd_)
