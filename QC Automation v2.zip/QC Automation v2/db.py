"""SQL Server access: connection, read-only guard, parameter binding.

Credentials are passed in from st.session_state and handed straight to pyodbc
through a connection factory, so they never appear in an engine URL, a log line
or on disk.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field

import pandas as pd

import config

try:  # pyodbc is optional at import time so tests run without an ODBC stack
    import pyodbc
except Exception:  # pragma: no cover
    pyodbc = None


# --- Drivers -----------------------------------------------------------------
def available_drivers() -> list[str]:
    if pyodbc is None:
        return []
    try:
        names = [d for d in pyodbc.drivers() if "SQL Server" in d]
    except Exception:
        return []
    ranked = [d for d in config.PREFERRED_DRIVERS if d in names]
    return ranked + sorted(d for d in names if d not in ranked)


# --- Connection ----------------------------------------------------------------
@dataclass
class ConnectionParams:
    server: str
    database: str = config.DEFAULT_DATABASE
    auth: str = "SQL Server login"          # or "Windows"
    username: str = ""
    password: str = field(default="", repr=False)
    driver: str = ""
    trust_server_certificate: bool = True
    encrypt: bool = True

    def describe(self) -> str:
        """Safe, credential-free description for display."""
        return f"{self.server} / {self.database}"

    def odbc_string(self) -> str:
        def esc(v: str) -> str:
            v = str(v)
            return "{" + v.replace("}", "}}") + "}" if any(c in v for c in ";{}= ") else v

        parts = [
            f"DRIVER={{{self.driver}}}",
            f"SERVER={esc(self.server)}",
            f"DATABASE={esc(self.database)}",
            f"Encrypt={'yes' if self.encrypt else 'no'}",
            f"TrustServerCertificate={'yes' if self.trust_server_certificate else 'no'}",
            "Application Name=Acrotech QC Workspace",
        ]
        if self.auth == "Windows":
            parts.append("Trusted_Connection=yes")
        else:
            parts.append(f"UID={esc(self.username)}")
            parts.append(f"PWD={esc(self.password)}")
        return ";".join(parts) + ";"


def create_engine(params: ConnectionParams):
    """SQLAlchemy engine whose URL carries no credentials."""
    from sqlalchemy import create_engine as _ce

    if pyodbc is None:
        raise RuntimeError("pyodbc is not installed.")
    conn_str = params.odbc_string()
    return _ce(
        "mssql+pyodbc://",
        creator=lambda: pyodbc.connect(conn_str, timeout=15),
        pool_pre_ping=True,
        pool_size=2,
        max_overflow=2,
    )


def friendly_error(exc: Exception, params: ConnectionParams | None = None) -> tuple[str, str]:
    """(what happened, how to fix) for a connection or query error. Never echoes a password."""
    raw = str(getattr(exc, "orig", None) or exc)
    if params and params.password:
        raw = raw.replace(params.password, "•••")
    db = params.database if params else config.DEFAULT_DATABASE
    low = raw.lower()
    if "login failed" in low:
        m = re.search(r"login failed for user '([^']*)'", raw, re.I)
        who = f" for user '{m.group(1)}'" if m else ""
        return (f"Couldn't sign in to {db}: login failed{who}.",
                "Check the username and password, or switch to Windows authentication.")
    if "data source name not found" in low or "can't open lib" in low or "driver" in low and "not found" in low:
        return ("The selected ODBC driver couldn't be loaded.",
                "Install ODBC Driver 18 for SQL Server, then reload this page.")
    if "certificate" in low or "ssl" in low:
        return ("The server's encryption certificate wasn't trusted.",
                "Turn on 'Trust server certificate', or ask IT for the server's certificate.")
    if "timeout" in low or "could not open a connection" in low or "network-related" in low or "tcp provider" in low:
        return (f"Couldn't reach the server '{params.server if params else ''}'.",
                "Check the server name, that you're on the corporate network or VPN, and that port 1433 is open.")
    if "cannot open database" in low:
        return (f"The database '{db}' couldn't be opened with these credentials.",
                "Check the database name and that your login has read access to it.")
    first = raw.split("\n")[0][:400]
    return (first, "Check the details above and try again.")


# --- Read-only guard --------------------------------------------------------------
_COMMENT_LINE = re.compile(r"--[^\n]*")
_COMMENT_BLOCK = re.compile(r"/\*.*?\*/", re.S)
_STRING = re.compile(r"N?'(?:[^']|'')*'")
_BRACKET = re.compile(r"\[[^\]]*\]")
_DQUOTE = re.compile(r'"[^"]*"')


def _strip_sql(sql: str) -> str:
    s = _COMMENT_BLOCK.sub(" ", sql)
    s = _COMMENT_LINE.sub(" ", s)
    s = _STRING.sub("''", s)
    s = _BRACKET.sub("[x]", s)
    s = _DQUOTE.sub('"x"', s)
    return s


def check_read_only(sql: str) -> tuple[bool, str]:
    """(ok, reason). Only SELECT / WITH … SELECT statements are allowed."""
    s = _strip_sql(sql or "").strip()
    if not s:
        return False, "The query is empty."
    upper = s.upper()
    for kw in config.READ_ONLY_BLOCKLIST:
        if re.search(rf"\b{kw}\b", upper):
            return False, f"This query changes data ({kw}), so it can't run here. Only SELECT queries are allowed."
    if re.search(r"\b(SP_|XP_)\w+", upper):
        return False, "This query calls a stored procedure, so it can't run here. Only SELECT queries are allowed."
    first = re.match(r"\s*(\w+)", upper)
    if not first or first.group(1) not in ("SELECT", "WITH"):
        return False, "Only SELECT queries are allowed. Start the query with SELECT or WITH."
    return True, ""


_PLACEHOLDER = re.compile(r"\{(start_date|end_date)\}")


def bind_date_placeholders(sql: str, start, end) -> tuple[str, list, bool]:
    """Turn {start_date}/{end_date} into ? markers. Returns (sql, params, had_placeholders).

    Placeholders inside quotes ('{start_date}') are also replaced, quotes included.
    """
    values = {"start_date": pd.Timestamp(start).date(), "end_date": pd.Timestamp(end).date()}
    params: list = []

    def repl(m):
        params.append(values[m.group(1)])
        return "?"

    # remove surrounding quotes first so '{start_date}' becomes ?
    sql2 = re.sub(r"'\{(start_date|end_date)\}'", lambda m: "{" + m.group(1) + "}", sql)
    out = _PLACEHOLDER.sub(repl, sql2)
    return out, params, bool(params)


# --- Execution --------------------------------------------------------------------
@dataclass
class QueryResult:
    name: str
    sql: str
    df: pd.DataFrame | None = None
    seconds: float = 0.0
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None


def run_query(engine, sql: str, params: list | tuple | None = None) -> pd.DataFrame:
    """Execute a read-only statement with qmark parameters and return a DataFrame."""
    ok, why = check_read_only(sql)
    if not ok:
        raise PermissionError(why)
    with engine.connect() as conn:
        res = conn.exec_driver_sql(sql, tuple(params or ()))
        cols = list(res.keys())
        rows = res.fetchall()
    return pd.DataFrame.from_records(rows, columns=cols)


def timed_query(engine, name: str, sql: str, params=None) -> QueryResult:
    t0 = time.perf_counter()
    try:
        df = run_query(engine, sql, params)
        return QueryResult(name, sql, df, time.perf_counter() - t0)
    except Exception as exc:  # each query fails independently
        what, how = friendly_error(exc)
        return QueryResult(name, sql, None, time.perf_counter() - t0, f"{what} {how}".strip())


def read_schema(engine, database: str) -> dict[str, dict[str, str]]:
    df = run_query(engine, config.schema_query(database), [config.SCHEMA, *config.ALL_TABLES, *config.OPTIONAL_TABLES])
    out: dict[str, dict[str, str]] = {t: {} for t in config.ALL_TABLES + config.OPTIONAL_TABLES}
    for t, c, d in df.itertuples(index=False):
        out.setdefault(t, {})[c] = str(d).lower()
    return out


def invoice_date_is_text(schema: dict[str, dict[str, str]]) -> bool:
    t = schema.get(config.TABLE_867, {}).get("Invoice_Date", "date")
    return t in {"char", "varchar", "nchar", "nvarchar", "text", "ntext"}
