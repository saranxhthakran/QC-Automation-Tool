"""Cleaning of raw 867 rows: text hygiene, types, product scope, account key, display names."""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

import config

NULL_TOKENS = {"NULL", "null", "", "-"}


# --- Generic text hygiene ----------------------------------------------------
def clean_text(series: pd.Series, extra_nulls: set[str] | None = None) -> pd.Series:
    """Text dtype, stripped (incl. trailing \\r), with NULL / '' mapped to <NA>."""
    nulls = {"NULL", ""} | (extra_nulls or set())
    s = series.astype("string")
    s = s.str.replace("\r", "", regex=False).str.strip()
    return s.mask(s.isin(nulls))


def clean_frame(df: pd.DataFrame, extra_nulls: dict[str, set[str]] | None = None) -> pd.DataFrame:
    out = df.copy()
    for c in out.columns:
        if out[c].dtype == object or pd.api.types.is_string_dtype(out[c]):
            out[c] = clean_text(out[c], (extra_nulls or {}).get(c))
    return out


def read_headerless_csv(path, columns: list[str]) -> pd.DataFrame:
    """Read a header-less sample export as text. 'NULL' means null."""
    df = pd.read_csv(path, header=None, names=columns, dtype=str, keep_default_na=False,
                     encoding="utf-8-sig")
    return clean_frame(df)


# --- Normalizers ------------------------------------------------------------------
def normalize_zip(series: pd.Series) -> pd.Series:
    """Text, stripped, first 5 digits (ZIP+4 aware), left-padded to 5. Numbers welcome."""
    s = series.astype("string").str.strip()
    s = s.str.replace(r"\.0+$", "", regex=True)       # 5679.0 from numeric columns
    s = s.str.split("-", n=1).str[0]                  # ZIP+4 with dash
    s = s.str.replace(r"\D", "", regex=True)
    s = s.mask(s == "")
    long = s.str.len() > 5
    s = s.where(~long, s.str.zfill(9).str[:5])        # 9-digit (or 6-8 when leading zeros lost)
    return s.str.zfill(5)


def normalize_combo(series: pd.Series) -> pd.Series:
    s = series.astype("string").str.upper().str.strip()
    s = s.str.replace(r"\s+", " ", regex=True)
    return s.mask(s == "")


def normalize_upper(series: pd.Series) -> pd.Series:
    s = series.astype("string").str.strip().str.upper()
    return s.mask(s == "")


# --- 867 preparation ---------------------------------------------------------------
def apply_column_mapping(df: pd.DataFrame, mapping: dict[str, str | None]) -> pd.DataFrame:
    """mapping: app column -> source column (None = not available)."""
    out = pd.DataFrame(index=df.index)
    for target, src in mapping.items():
        out[target] = df[src] if src and src in df.columns else pd.NA
    return out


def guess_mapping(source_cols: list[str], targets: list[str]) -> dict[str, str | None]:
    norm = {re.sub(r"[^a-z0-9]", "", c.lower()): c for c in source_cols}
    return {t: norm.get(re.sub(r"[^a-z0-9]", "", t.lower())) for t in targets}


def prepare_sales(raw: pd.DataFrame, products: list[str] | None = None) -> tuple[pd.DataFrame, dict]:
    """Clean 867 rows and derive the account key. Returns (df, info)."""
    products = [p.upper() for p in (products or config.ACTIVE_PRODUCTS)]
    df = clean_frame(raw)
    for c in config.REQUIRED_867:
        if c not in df.columns:
            df[c] = pd.NA
            df[c] = df[c].astype("string")

    df["Product"] = normalize_upper(df["Product"])
    before = len(df)
    df = df[df["Product"].isin(products)].copy()
    info = {"rows_raw": before, "rows_out_of_scope": before - len(df)}

    df["Invoice_Date"] = pd.to_datetime(df["Invoice_Date"], errors="coerce").dt.normalize()
    bad_dates = int(df["Invoice_Date"].isna().sum())
    df = df[df["Invoice_Date"].notna()].copy()
    info["rows_bad_date"] = bad_dates
    df["Load_Date"] = pd.to_datetime(df["Load_Date"], errors="coerce")
    if "Extended_Amount" in df:
        df["Extended_Amount"] = pd.to_numeric(df["Extended_Amount"], errors="coerce")

    df["is_return"] = normalize_upper(df["Sale_Returns"]).eq("RETURNS").fillna(False).astype(bool)
    df, qinfo = prepare_quantity(df)
    info.update(qinfo)

    dea = df["Ship_To_DEA"].astype("string")
    dgid = df["Detail_Group_ID"].astype("string")
    df["account_key"] = dea.fillna(dgid).fillna(config.UNIDENTIFIED_KEY).str.upper()
    df["key_source"] = np.where(dea.notna(), "DEA", np.where(dgid.notna(), "Detail_Group_ID", "None"))
    df["zip5"] = normalize_zip(df["Ship_To_Zip"])
    df["combo_norm"] = normalize_combo(df["COMBO"]) if "COMBO" in df else pd.NA
    # A COMBO built without an outlet ID can't identify an outlet on its own.
    df.loc[df["key_source"] == "None", "combo_norm"] = pd.NA
    df["SPORPL"] = normalize_upper(df["SPORPL"])
    df["Shipper_Name"] = df["Shipper_Name"].fillna("Unknown wholesaler")

    df = add_account_names(df)
    df = df.reset_index(drop=True)
    info.update({
        "rows": len(df),
        "null_dea_rows": int((df["key_source"] != "DEA").sum()),
        "fallback_key_rows": int((df["key_source"] == "Detail_Group_ID").sum()),
        "unidentified_rows": int((df["key_source"] == "None").sum()),
        "return_rows": int(df["is_return"].sum()),
        "multi_name_keys": int(df.groupby("account_key")["Ship_To_Name"].nunique().gt(1).sum()) if len(df) else 0,
    })
    return df, info


def prepare_quantity(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Numeric analysis quantity (config.QTY_COLUMN = Factored_QTY) with checks.

    - Missing Factored_QTY falls back to Sold_Qty × Factor, then Converted_QTY, then 0.
    - Return rows (Sale_Returns = "Returns") with a positive quantity are made negative.
    - Rows where Factored_QTY ≠ Sold_Qty × Factor, or Factor ≠ 1, are counted (not changed).
    """
    q = config.QTY_COLUMN
    out = df.copy()
    num = {c: pd.to_numeric(out[c], errors="coerce") if c in out else pd.Series(np.nan, index=out.index)
           for c in ["Factored_QTY", "Sold_Qty", "Factor", "Converted_QTY"]}
    for c in ["Sold_Qty", "Factor", "Converted_QTY"]:
        out[c] = num[c].astype(float)
    product = num["Sold_Qty"] * num["Factor"]
    qty = num["Factored_QTY"].copy()
    source = pd.Series("Factored_QTY", index=out.index, dtype="string")
    fill1 = qty.isna() & product.notna()
    qty[fill1] = product[fill1]
    source[fill1] = "Sold_Qty × Factor"
    fill2 = qty.isna() & num["Converted_QTY"].notna()
    qty[fill2] = num["Converted_QTY"][fill2]
    source[fill2] = "Converted_QTY"
    none = qty.isna()
    source[none] = "None (0)"
    qty = qty.fillna(0.0).astype(float)

    pos_ret = out["is_return"] & (qty > 0)
    qty[pos_ret] = -qty[pos_ret]
    out[q] = qty
    out["qty_source"] = source

    both = num["Factored_QTY"].notna() & product.notna()
    info = {
        "qty_column": q,
        "qty_source_counts": source.value_counts().to_dict(),
        "positive_returns_fixed": int(pos_ret.sum()),
        "negative_sale_rows": int(((~out["is_return"]) & (qty < 0)).sum()),
        "factor_not_one_rows": int((num["Factor"].notna() & (num["Factor"] - 1).abs().gt(1e-9)).sum()),
        "factor_mismatch_rows": int((both & (num["Factored_QTY"] - product).abs().gt(1e-6)).sum()),
        "factored_vs_converted_diff_rows": int((num["Factored_QTY"].notna() & num["Converted_QTY"].notna()
                                               & (num["Factored_QTY"] - num["Converted_QTY"]).abs().gt(1e-6)).sum()),
    }
    return out, info


def add_account_names(df: pd.DataFrame) -> pd.DataFrame:
    """Display name/city/state from each key's most recent invoice (ties: most frequent name)."""
    if df.empty:
        for c in ["account_name", "account_city", "account_state", "account_label"]:
            df[c] = pd.Series(dtype="string")
        return df
    named = df[["account_key", "Invoice_Date", "Ship_To_Name", "Ship_To_City", "Ship_To_State"]].copy()
    named["_n"] = named.groupby(["account_key", "Ship_To_Name"], dropna=False)["Invoice_Date"].transform("size")
    named["_has_name"] = named["Ship_To_Name"].notna()
    named = named.sort_values(["account_key", "_has_name", "Invoice_Date", "_n"], ascending=[True, False, False, False])
    latest = named.drop_duplicates("account_key")[["account_key", "Ship_To_Name", "Ship_To_City", "Ship_To_State"]]
    latest = latest.rename(columns={"Ship_To_Name": "account_name", "Ship_To_City": "account_city",
                                    "Ship_To_State": "account_state"})
    out = df.drop(columns=[c for c in ["account_name", "account_city", "account_state", "account_label"] if c in df],
                  errors="ignore").merge(latest, on="account_key", how="left", validate="many_to_one")
    assert len(out) == len(df)
    unid = out["account_key"] == config.UNIDENTIFIED_KEY
    out.loc[unid, "account_name"] = config.UNIDENTIFIED_LABEL
    out["account_name"] = out["account_name"].fillna("Unnamed ship-to")
    out["account_label"] = account_label(out["account_name"], out["account_city"], out["account_state"],
                                         out["account_key"])
    return out


def account_label(name, city, state, key) -> pd.Series:
    """'Name – City, ST (KEY)'."""
    name = pd.Series(name).astype("string").fillna("")
    city = pd.Series(city, index=name.index).astype("string").fillna("")
    state = pd.Series(state, index=name.index).astype("string").fillna("")
    key = pd.Series(key, index=name.index).astype("string").fillna("")
    loc = (city.str.title() + ", " + state).str.strip(", ")
    lbl = name + np.where(loc != "", " – " + loc, "")
    lbl = lbl + np.where((key != "") & (key != config.UNIDENTIFIED_KEY), " (" + key + ")", "")
    return lbl.astype("string")
