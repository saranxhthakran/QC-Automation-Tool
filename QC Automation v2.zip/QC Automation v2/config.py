"""Central configuration: products, team, tables, queries and default thresholds.

Everything that a sales-ops analyst might reasonably need to change lives here.
"""
from __future__ import annotations

import re

APP_NAME = "Acrotech QC Workspace"

# --- Scope -----------------------------------------------------------------
# Only these products may appear anywhere (queries, filters, charts, PDF).
ACTIVE_PRODUCTS: list[str] = ["BELEODAQ", "RYZNEUTA"]
DEFAULT_PRODUCT = "BELEODAQ"

# Territory alignment team used by both products.
TEAM = "Fusion"

# Which alignment FileID to use. None = the latest (highest) FileID for TEAM.
ALIGNMENT_FILE_ID: str | None = None

# Zip-to-territory is pulled once and stored next to the app (LOCAL_STORE_DIR). Loads reuse
# the stored copy; after this many days Connect & load asks you to update it.
LOCAL_STORE_DIR = "data_cache"
ALIGNMENT_STORE_MAX_AGE_DAYS = 7

# --- Database --------------------------------------------------------------
DEFAULT_DATABASE = "ACROTECH_HUB"
SCHEMA = "POWERBI"
TABLE_867 = "POWERBI_867"
TABLE_ALIGNMENT = "POWERBI_ZIPTOTERR"
TABLE_CUSTOMER_MASTER = "POWERBI_CUSTOMER_MASTER"
TABLE_ROSTER = "POWERBI_ROSTER"
TABLE_USER = "POWERBI_USER"          # "Employee" in Power BI
ALL_TABLES = [TABLE_867, TABLE_ALIGNMENT, TABLE_CUSTOMER_MASTER]   # required to connect
OPTIONAL_TABLES = [TABLE_ROSTER, TABLE_USER]                        # pages work without them

PREFERRED_DRIVERS = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "ODBC Driver 13 for SQL Server",
    "SQL Server Native Client 11.0",
    "SQL Server",
]

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_\-$#@ ]{0,127}$")


def safe_identifier(name: str) -> str:
    """Validate a database/schema/table name before it is placed in SQL.

    Identifiers cannot be bound as parameters, so they are validated instead.
    """
    name = (name or "").strip()
    if not _IDENT.match(name) or "]" in name:
        raise ValueError(f"'{name}' is not a valid SQL Server identifier.")
    return name


def table_ref(table: str, database: str = DEFAULT_DATABASE) -> str:
    return f"[{safe_identifier(database)}].[{SCHEMA}].[{safe_identifier(table)}]"


# --- Column orders (CSV samples have no header row) -------------------------
COLUMNS_867 = [
    "SPORPL", "NDC", "NDC_Description", "Product", "Cost_Center", "Shipper_Type", "Sale_Return",
    "Shipper_Name", "Shipper_DEA", "City", "State", "Zip", "Country", "Ship_To_Type", "Ship_To_DEA",
    "Ship_To_Name", "Address1", "Address2", "Ship_To_City", "Ship_To_State", "Ship_To_Zip",
    "Ship_To_Country", "UOM", "Sold_Qty", "Trans_Type", "Invoice_Date", "Invoice_Sales_Date",
    "Wholesaler_Invoice_ID", "Contract", "Unit_Price", "Extended_Amount", "Creation_Date",
    "Sale_Returns", "Detail_Group_ID", "Sales_Program_ID", "Factor", "Factored_QTY",
    "Converted_QTY", "COMBO", "MHZ_BELEODAQ", "PTCL_BELEODAQ", "Load_Date", "Source", "New_Start",
    "Previous_Invoice_Date", "Days_Last_Sale",
]
# Column order of the header-less alignment sample. CAM_Territory_Name is in the table but never pulled or used.
COLUMNS_ALIGNMENT = [
    "Team", "ZIPCode", "City", "State", "Region_ID", "Region_Name", "Territory_ID",
    "Territory_Name", "CAM_Territory_Name", "FileID",
]
COLUMNS_CUSTOMER_MASTER = [
    "SFCD_ID", "SF_External_ID", "SF_External_ID_Type", "SF_Type", "SF_Type1", "SF_Type2",
    "SF_Name", "SF_Address1", "SF_Address2", "SF_City", "SF_State", "SF_Zip", "SF_NPI",
    "SF_Specialty_1", "SF_Specialty_2", "Parent_SFCD", "Parent_Name",
    "Parent_RecordTypeName", "Parent_External_ID", "ED_ID", "ED_ID_Type", "ED_ID_Desc",
    "ED_SC_Flag", "ED_Name", "ED_Address1", "ED_Address2", "ED_City", "ED_State", "ED_Zip",
    "ED_Intrinsiq_ID", "ED_Source_From", "Start_Date", "End_Date", "AC_Type",
    "Hemady_MHZ_HCPs", "Hemady_MHZ_Accounts", "Beleodaq_PTCL_Territory_ID",
    "Beleodaq_PTCL_Territory_Name", "Beleodaq_PTCL_Region_ID",
    "Beleodaq_PTCL_Region_Name", "Beleodaq_MHZ_Territory_ID",
    "Beleodaq_MHZ_Territory_Name", "Beleodaq_MHZ_Region_ID", "Beleodaq_MHZ_Region_Name",
    "COMBO", "OAM_GCSF_Target", "CAM_GCSF_Target", "GCSF_Decile", "Aggregator", "Primary_GPO",
    "Secondary_GPO", "Ryzneuta_Ordering_Status",
]

# --- Quantity ------------------------------------------------------------------
# Every page measures units with this column: Sold_Qty × Factor, normalized across pack sizes
# (BELEODAQ: 500 mg vials; RYZNEUTA: 20 mg prefilled syringes). Returns are negative.
# If a row has no Factored_QTY, data_prep falls back to Sold_Qty × Factor, then Converted_QTY.
QTY_COLUMN = "Factored_QTY"

# Confirmed with INFORMATION_SCHEMA (Oct 21, 2026).
COLUMNS_ROSTER = ["Team", "Region_ID", "Region_Name", "Territory_ID", "Territory_Name", "EMPLOYEE", "EMAIL", "Terr", "Reg"]
COLUMNS_USER = COLUMNS_ROSTER + [
    "SFCD_ID", "NAME", "USERNAME", "User_Email", "Alias", "CommunityNickname", "IsActive",
    "Territory_Number__c", "Territory_Name__c", "Start_Date",
]
NEW_TO_TERRITORY_DAYS = 90   # owner whose Start_Date is within this many days is "New to territory"

# Columns the app needs from each source (also the targets of custom-query column mapping).
REQUIRED_867 = [
    "Product", "NDC", "Invoice_Date", "Factored_QTY", "Sold_Qty", "Factor", "Converted_QTY", "Sale_Returns",
    "Trans_Type", "SPORPL", "Address1", "Unit_Price", "Sales_Program_ID",
    "Ship_To_DEA", "Detail_Group_ID", "Ship_To_Name", "Ship_To_City", "Ship_To_State",
    "Ship_To_Zip", "Shipper_Name", "Contract", "Extended_Amount", "Wholesaler_Invoice_ID",
    "COMBO", "PTCL_BELEODAQ", "New_Start", "Load_Date",
]
# Columns that may be absent in a custom query without breaking anything.
OPTIONAL_867 = {"Sold_Qty", "Factor", "Converted_QTY", "Address1", "Unit_Price", "Sales_Program_ID", "NDC", "Trans_Type", "Contract", "Extended_Amount",
                "PTCL_BELEODAQ", "New_Start", "SPORPL", "COMBO"}
# CAM territory is not used anywhere: alignment is by Region and Territory only.
REQUIRED_ALIGNMENT = [
    "Team", "ZIPCode", "Region_ID", "Region_Name", "Territory_ID", "Territory_Name", "FileID",
]
REQUIRED_CUSTOMER_MASTER = [
    "SFCD_ID", "SF_External_ID", "SF_Name", "SF_Type1", "Parent_SFCD", "Parent_Name",
    "Parent_RecordTypeName", "ED_ID", "ED_ID_Type", "COMBO",
]
OPTIONAL_CUSTOMER_MASTER = {"SF_Type1", "ED_ID_Type"}

# --- Labels used for missing joins -------------------------------------------
UNALIGNED = "Unaligned"
UNMAPPED = "Unmapped"
UNIDENTIFIED_KEY = "UNIDENTIFIED"
UNIDENTIFIED_LABEL = "Unidentified ship-to"
STANDALONE_SUFFIX = " (standalone)"

# Customer-master match methods in priority order.
MATCH_METHODS = ["COMBO", "Outlet ID", "SPOR"]


# --- Queries -----------------------------------------------------------------
def product_placeholders(n: int | None = None) -> str:
    return ", ".join("?" for _ in range(n or len(ACTIVE_PRODUCTS)))


def date_expr(invoice_date_is_text: bool) -> str:
    """SQL expression for Invoice_Date, adapted to the column's real type."""
    return "TRY_CONVERT(date, [Invoice_Date])" if invoice_date_is_text else "CAST([Invoice_Date] AS date)"


def anchor_query(database: str, invoice_date_is_text: bool = False) -> str:
    d = date_expr(invoice_date_is_text)
    return (
        f"SELECT UPPER(LTRIM(RTRIM([Product]))) AS Product, MAX({d}) AS MaxDate, MAX([Load_Date]) AS LoadDate\n"
        f"FROM {table_ref(TABLE_867, database)}\n"
        f"WHERE UPPER(LTRIM(RTRIM([Product]))) IN ({product_placeholders()})\n"
        f"GROUP BY UPPER(LTRIM(RTRIM([Product])))"
    )


def sales_query(database: str, invoice_date_is_text: bool = False) -> str:
    d = date_expr(invoice_date_is_text)
    cols = ",\n       ".join(f"[{c}]" for c in REQUIRED_867)
    return (
        f"SELECT {cols}\n"
        f"FROM {table_ref(TABLE_867, database)}\n"
        f"WHERE {d} >= ? AND {d} <= ?\n"
        f"  AND UPPER(LTRIM(RTRIM([Product]))) IN ({product_placeholders()})"
    )


def alignment_check_query(database: str) -> str:
    return (
        "SELECT Team, FileID, COUNT(*) AS Rows, COUNT(DISTINCT ZIPCode) AS Zips\n"
        f"FROM {table_ref(TABLE_ALIGNMENT, database)}\n"
        "GROUP BY Team, FileID"
    )


def alignment_query(database: str) -> str:
    cols = ", ".join(f"[{c}]" for c in REQUIRED_ALIGNMENT)
    return (
        f"SELECT {cols}\n"
        f"FROM {table_ref(TABLE_ALIGNMENT, database)}\n"
        "WHERE LTRIM(RTRIM([Team])) = ?"
    )


def customer_master_query(database: str) -> str:
    return (
        "SELECT SFCD_ID, SF_External_ID, SF_Name, SF_Type1, Parent_SFCD, Parent_Name,\n"
        "       Parent_RecordTypeName, ED_ID, ED_ID_Type, COMBO\n"
        f"FROM {table_ref(TABLE_CUSTOMER_MASTER, database)}\n"
        "WHERE ED_ID IS NOT NULL OR SF_External_ID LIKE 'SPOR%'"
    )


def roster_query(database: str) -> str:
    cols = ", ".join(f"[{c}]" for c in COLUMNS_ROSTER)
    return f"SELECT {cols}\nFROM {table_ref(TABLE_ROSTER, database)}"


def user_query(database: str) -> str:
    cols = ", ".join(f"[{c}]" for c in COLUMNS_USER)
    return f"SELECT {cols}\nFROM {table_ref(TABLE_USER, database)}"


def schema_query(database: str) -> str:
    return (
        "SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE\n"
        f"FROM [{safe_identifier(database)}].INFORMATION_SCHEMA.COLUMNS\n"
        f"WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ({product_placeholders(len(ALL_TABLES) + len(OPTIONAL_TABLES))})"
    )


# --- Thresholds (all adjustable in the settings panel) -----------------------
DEFAULT_THRESHOLDS: dict[str, float] = {
    "sd_multiplier": 2.0,            # spike / drop: rolling mean ± k·SD
    "rolling_periods": 13,           # weeks in the rolling baseline
    "spike_order_ratio": 2.0,        # spike: single order > 200% of typical order size
    "min_change_pct": 25.0,          # spike / drop must also move at least this % from the mean
    "consecutive_declines": 3,       # drop: N consecutive declining months
    "lapsed_interval_multiple": 2.0, # lapsed: no order in > 2x typical interval
    "lapsed_fallback_days": 90,      # lapsed when an account has only one order
    "new_account_days": 90,          # new: first order less than this many days ago
    "large_return_ratio": 3.0,       # suspicious: a return > 3x typical order size
    "large_order_ratio": 5.0,        # suspicious: a single order > 5x typical order size
    "trend_change_pct": 15.0,        # growing / declining: last 3 vs prior 3 months
    "erratic_cv": 1.0,               # erratic: coefficient of variation of monthly units
    "neutral_pct": 2.0,              # delta pills turn neutral below this |%|
    "concentration_share": 0.6,
    "alert_pct": 25.0,               # Overview alerts: |% vs average| at or above this      # parent decline concentrated if one ship-to > 60% of it
}

TREND_STATUSES = ["Growing", "Stable", "Declining", "Erratic", "New", "Lapsed"]

TIMEFRAME_PRESETS = [
    "Minimum for analysis",
    "Last 12 months",
    "Last 2 years",
    "Full history (2018–today)",
    "Custom range",
]
HISTORY_START_YEAR = 2018

READ_ONLY_BLOCKLIST = [
    "INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "TRUNCATE", "EXEC", "EXECUTE", "MERGE",
    "CREATE", "GRANT", "REVOKE", "DENY", "BULK", "INTO", "OPENROWSET", "OPENDATASOURCE",
    "BACKUP", "RESTORE", "DBCC", "SHUTDOWN", "RECONFIGURE",
]


# =============================================================================
# Product deep dive: product facts and calculation defaults (all adjustable in page settings)
# =============================================================================
# 867 data are account-level shipments, never patient records: every patient, cycle and course
# figure derived from these parameters is an estimate.
PRODUCT_PROFILES: dict[str, dict] = {
    "BELEODAQ": {
        "generic": "belinostat",
        "indication": ("Adults with relapsed or refractory peripheral T-cell lymphoma (PTCL), under accelerated "
                       "approval. Safety and effectiveness in children are not established."),
        "administration": "30-minute IV infusion, in a clinic or hospital.",
        "regimen": ("1,000 mg/m² once daily on days 1–5 of a 21-day cycle, repeated until disease progression or "
                    "unacceptable toxicity (no fixed number of cycles)."),
        "dose_notes": ("750 mg/m²: 25% reduction after a grade 3–4 adverse reaction, or the starting dose for "
                       "UGT1A1*28 homozygous patients. 500 mg/m²: moderate liver or kidney impairment. Treatment "
                       "stops after two dose reductions."),
        "pack": "500 mg single-dose vial",
        "unit": "vial", "units": "vials",
        "defaults": {
            "bsa_m2": 1.9, "unit_mg": 500.0, "days_per_cycle": 5,
            "dose_standard": 1000.0, "dose_reduced": 750.0, "dose_organ": 500.0,
            "dose_tolerance_units": 1.0,           # ± vials around 20 / 15 / 10 per cycle
            "cycle_days": 21, "alt_cycle_days": 0,
            "on_schedule_lo": 18, "on_schedule_hi": 28, "alt_on_schedule_lo": 0, "alt_on_schedule_hi": 0,
            "event_window_days": 7, "max_course_gap_days": 42,
            "fixed_units_per_cycle": 0.0,          # 0 = from dose × BSA ÷ vial size × days
        },
    },
    "RYZNEUTA": {
        "generic": "efbemalenograstim alfa",
        "indication": ("Adults with non-myeloid cancers on myelosuppressive chemotherapy with a clinically "
                       "significant risk of febrile neutropenia, to reduce infection as shown by febrile "
                       "neutropenia. Not for stem-cell mobilization."),
        "administration": "Subcutaneous injection by a healthcare professional.",
        "regimen": ("20 mg once per chemotherapy cycle; not within 14 days before or less than 24 hours after "
                    "chemotherapy, so it fits cycles of 14 days or longer (typically 14 or 21). The number of "
                    "cycles follows the chemotherapy regimen."),
        "dose_notes": "One 20 mg prefilled syringe ≈ one patient cycle.",
        "pack": "20 mg prefilled syringe",
        "unit": "syringe", "units": "syringes",
        "defaults": {
            "bsa_m2": 1.9, "unit_mg": 20.0, "days_per_cycle": 1,
            "dose_standard": 0.0, "dose_reduced": 0.0, "dose_organ": 0.0,
            "dose_tolerance_units": 0.0,
            "cycle_days": 21, "alt_cycle_days": 14,
            "on_schedule_lo": 18, "on_schedule_hi": 28, "alt_on_schedule_lo": 12, "alt_on_schedule_hi": 16,
            "event_window_days": 3, "max_course_gap_days": 35,
            "fixed_units_per_cycle": 1.0,
        },
    },
}

# Contracts that mark 340B purchasing (plus any contract or ship-to name containing "340B").
CONTRACTS_340B = ["ACRYZPHS"]

# Shared deep-dive defaults (both products).
DEEP_DIVE_DEFAULTS: dict[str, float] = {
    # account regime: run-rate if ANY threshold is exceeded
    "regime_max_ce_per_event": 1.5,        # average cycle-equivalents per event
    "regime_max_events_per_21d": 1.6,      # events per 21 days while active
    "regime_max_interval_cv": 0.6,         # variation of within-course gaps (needs ≥ 3 gaps)
    "use_observed": 0,                     # 0 = label values, 1 = observed (calibrated) values
    "overdue_tolerance_days": 7,
    "forecast_weeks": 13,
    "forecast_range_pct": 80,
    "new_start_days": 30,                  # "new start follow-through" window
    "completed_lookback_days": 60,         # courses that ended this recently get "likely completed"
    "lapsed_high_value_pct": 75,           # lapsed accounts at or above this percentile of 12-month units
    "runrate_slowdown_pct": 40,            # last 4 weeks vs 13-week average
    "trade_return_share_pct": 25,          # returns vs purchases in the last 13 weeks
    "trade_stock_multiple": 3.0,           # event > this × the account's typical event
    "trade_no_charge_share_pct": 20,       # no-charge share of units in the last 13 weeks
    "w_units": 1.0, "w_probability": 1.0, "w_urgency": 1.0,
    "min_history_months": 12,              # course / cohort / persistence views need this much history
}
