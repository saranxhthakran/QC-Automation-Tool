"""Headless run of the Product deep dive page: every section, both products, sample data + synthetic data."""
import datetime as dt
from pathlib import Path

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

import config
import data_prep as dp
import enrichment as en
import territory_people as tp
from tests.synthetic import enriched

APP = str(Path(__file__).resolve().parent.parent / "app.py")
PAGE = "app_pages/5_Product_deep_dive.py"
SAMPLES = Path(__file__).resolve().parent / "samples"
SECTIONS = ["Snapshot", "Demand", "Rhythm & persistence", "Accounts", "Forecast", "Field actions"]


def sample_data():
    s1 = dp.read_headerless_csv(SAMPLES / "SQLQuery1.csv", config.COLUMNS_867)
    s2 = dp.read_headerless_csv(SAMPLES / "RYZNEUTA_sample.csv", config.COLUMNS_867)
    al = dp.read_headerless_csv(SAMPLES / "SQLQuery2.csv", config.COLUMNS_ALIGNMENT)
    cm = dp.read_headerless_csv(SAMPLES / "SQLQuery3.csv", config.COLUMNS_CUSTOMER_MASTER)
    data = en.enrich(pd.concat([s1, s2]), al, cm)
    r = dp.read_headerless_csv(SAMPLES / "ROSTER_sample.csv", config.COLUMNS_ROSTER)
    u = dp.read_headerless_csv(SAMPLES / "USER_sample.csv", config.COLUMNS_USER)
    data.people = tp.build_owners(r, u, "2026-10-21", data.alignment.table)
    return data


@pytest.fixture(scope="module", params=["samples", "synthetic"])
def data(request):
    return sample_data() if request.param == "samples" else enriched()


def _app(data):
    at = AppTest.from_file(APP, default_timeout=180)
    at.session_state["data"] = data
    at.session_state["data_meta"] = {"mode": "Default", "start": dt.date(2018, 1, 1), "end": dt.date(2026, 10, 19),
                                     "preset": "Full history (2018–today)", "loaded_at": "2026-10-21T10:00:00",
                                     "sql": [], "file_id": "1500", "full_history": True}
    at.session_state["data_version"] = "test-dd"
    return at


@pytest.mark.parametrize("product", ["BELEODAQ", "RYZNEUTA"])
def test_every_section_renders(data, product):
    at = _app(data)
    at.run()
    at.session_state["product"] = product
    at.switch_page(PAGE).run()
    assert not at.exception, [e.value for e in at.exception]
    assert any("deep dive" in m.value for m in at.markdown)
    for sec in SECTIONS:
        at.session_state["pdd_section"] = sec
        at.run()
        assert not at.exception, (product, sec, [e.value for e in at.exception])
        assert any('class="takeaway"' in m.value for m in at.markdown), sec
    # every patient / cycle figure is marked as an estimate
    at.session_state["pdd_section"] = "Snapshot"
    at.run()
    assert sum('class="est-pill"' in m.value for m in at.markdown) >= 1


def test_filters_and_settings(data):
    at = _app(data)
    at.run()
    at.session_state["product"] = "BELEODAQ"
    at.switch_page(PAGE).run()
    regions = at.multiselect(key="pdd_regions").options
    if regions:
        at.multiselect(key="pdd_regions").set_value([regions[0]]).run()
        assert not at.exception, [e.value for e in at.exception]
    at.toggle(key="pdd_obs_BELEODAQ").set_value(True).run()
    assert not at.exception, [e.value for e in at.exception]
    at.session_state["pdd_section"] = "Field actions"
    at.run()
    assert not at.exception, [e.value for e in at.exception]


def test_page_in_navigation_between_accounts_and_report():
    src = (Path(APP)).read_text(encoding="utf-8")
    i_acc, i_dd, i_rep = src.index("3_Accounts.py"), src.index("5_Product_deep_dive.py"), src.index("4_Report.py")
    assert i_acc < i_dd < i_rep


def test_pdf_includes_deep_dive():
    import pdf_report as P

    d = sample_data()
    pdf, notes = P.build_pdf(d, P.ReportOptions(products=["RYZNEUTA"], include_overview=False, include_accounts=False,
                                                include_deep_dive=True, include_appendix=False,
                                                data_meta={"start": "2025-10-01", "end": "2026-10-19"}))
    assert pdf[:4] == b"%PDF" and len(pdf) > 10_000
