from pathlib import Path

import pandas as pd
import pytest

import config
import data_prep as dp

SAMPLES = Path(__file__).parent / "samples"


def sales_row(**kw):
    base = {c: None for c in config.REQUIRED_867}
    base.update({
        "Product": "BELEODAQ", "NDC": "72893000201", "Invoice_Date": "2026-10-14", "Converted_QTY": "10",
        "Sold_Qty": "10", "Factor": "1.0", "Factored_QTY": "10",
        "Sale_Returns": "Sales", "Trans_Type": "SS", "Ship_To_DEA": "AB1234567",
        "Detail_Group_ID": "AB1234567", "Ship_To_Name": "TEST HOSP", "Ship_To_City": "BOSTON",
        "Ship_To_State": "MA", "Ship_To_Zip": "02134", "Shipper_Name": "CARDINAL",
        "Wholesaler_Invoice_ID": "1", "Load_Date": "2026-10-19",
    })
    base.update(kw)
    return base


def make_sales(rows):
    return pd.DataFrame([sales_row(**r) for r in rows])


def make_alignment(rows):
    cols = config.COLUMNS_ALIGNMENT
    base = {"Team": "Fusion", "City": "X", "State": "MA", "Region_ID": "R1", "Region_Name": "NORTHEAST",
            "Territory_ID": "T1", "Territory_Name": "BOSTON, MA", "FileID": "1500"}
    return pd.DataFrame([{**{c: None for c in cols}, **base, **r} for r in rows])


def make_cm(rows):
    base = {c: None for c in config.COLUMNS_CUSTOMER_MASTER}
    base.update({"SFCD_ID": "SF1", "SF_External_ID": "-", "SF_Name": "ACCOUNT ONE", "SF_Type": "Organization_vod"})
    return pd.DataFrame([{**base, **r} for r in rows])


@pytest.fixture(scope="session")
def samples():
    s = dp.read_headerless_csv(SAMPLES / "SQLQuery1.csv", config.COLUMNS_867)
    a = dp.read_headerless_csv(SAMPLES / "SQLQuery2.csv", config.COLUMNS_ALIGNMENT)
    m = dp.read_headerless_csv(SAMPLES / "SQLQuery3.csv", config.COLUMNS_CUSTOMER_MASTER)
    return s, a, m
