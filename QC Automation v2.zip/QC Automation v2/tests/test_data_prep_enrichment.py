import pandas as pd
import pytest

import config
import data_prep as dp
import db
import enrichment as en
from tests.conftest import make_alignment, make_cm, make_sales


# --- samples ---------------------------------------------------------------------
def test_samples_load_with_spec_columns(samples):
    s, a, m = samples
    assert s.shape == (1000, 46) and a.shape == (1000, 10) and m.shape == (1000, 52)
    assert a["Territory_Name"].isin(["BOSTON, MA", "MANHATTAN, NY"]).all()
    assert s["Ship_To_DEA"].isna().sum() == 14           # "NULL" became null
    assert not s.apply(lambda c: c.astype(str).str.contains("\r").any()).any()


def test_samples_scope_and_row_preservation(samples):
    s, a, m = samples
    e = en.enrich(s, a, m)
    assert set(e.sales["Product"]) <= set(config.ACTIVE_PRODUCTS)
    assert "ADQUEY" not in set(e.sales["Product"])
    assert len(e.sales) == 970
    conf = e.parents.lookup_conflicts
    assert "RA0219798" in set(conf["key"])               # same DEA under two parents in the sample


# --- cleaning ------------------------------------------------------------------------
def test_zip_normalization():
    z = dp.normalize_zip(pd.Series(["5679", "02134-1234", "021341234", 2134, 5679.0, " 10001 ", None, "21341234"]))
    assert z.tolist()[:6] == ["05679", "02134", "02134", "02134", "05679", "10001"]
    assert pd.isna(z.iloc[6])
    assert z.iloc[7] == "02134"   # ZIP+4 stored as a number lost its leading zero


def test_combo_normalization():
    c = dp.normalize_combo(pd.Series(["fd27  dfw wellness   pnl ", "", None]))
    assert c.iloc[0] == "FD27 DFW WELLNESS PNL"
    assert pd.isna(c.iloc[1]) and pd.isna(c.iloc[2])


def test_null_dea_fallback_and_unidentified():
    s, info = dp.prepare_sales(make_sales([
        {"Ship_To_DEA": "NULL", "Detail_Group_ID": "9067M8GF2"},
        {"Ship_To_DEA": None, "Detail_Group_ID": None, "Ship_To_Name": None},
        {},
    ]))
    assert s["account_key"].tolist() == ["9067M8GF2", config.UNIDENTIFIED_KEY, "AB1234567"]
    assert info["unidentified_rows"] == 1
    assert s.loc[1, "account_name"] == config.UNIDENTIFIED_LABEL


def test_multiple_names_use_latest_invoice():
    s, _ = dp.prepare_sales(make_sales([
        {"Ship_To_Name": "OLD NAME", "Invoice_Date": "2026-01-01", "Ship_To_City": "OLDTOWN"},
        {"Ship_To_Name": "NEW NAME", "Invoice_Date": "2026-09-01", "Ship_To_City": "BOSTON"},
        {"Ship_To_Name": "OLD NAME", "Invoice_Date": "2026-02-01"},
    ]))
    assert set(s["account_name"]) == {"NEW NAME"}
    assert s["account_label"].iloc[0] == "NEW NAME – Boston, MA (AB1234567)"


def test_returns_and_out_of_scope():
    s, info = dp.prepare_sales(make_sales([
        {"Factored_QTY": "-5", "Sale_Returns": "Returns", "Trans_Type": "SS"},
        {"Product": "ADQUEY"}, {"Product": " beleodaq "}, {"Product": "RYZNEUTA"},
    ]))
    assert info["rows_out_of_scope"] == 1
    assert s["is_return"].tolist() == [True, False, False]
    assert s[config.QTY_COLUMN].sum() == 15  # -5 + 10 + 10


# --- alignment --------------------------------------------------------------------
def test_alignment_left_join_and_unaligned():
    s, _ = dp.prepare_sales(make_sales([{"Ship_To_Zip": "2134"}, {"Ship_To_Zip": "99999"}]))
    al = en.prepare_alignment(make_alignment([{"ZIPCode": "02134"}]))
    out = en.apply_alignment(s, al)
    assert len(out) == 2
    assert out["Territory_Name"].tolist() == ["BOSTON, MA", config.UNALIGNED]
    assert out["Region_ID"].tolist() == ["R1", config.UNALIGNED]


def test_alignment_filters_team_and_latest_fileid():
    al = en.prepare_alignment(make_alignment([
        {"ZIPCode": "02134", "Territory_ID": "OLD", "FileID": "900"},
        {"ZIPCode": "02134", "Territory_ID": "NEW", "FileID": "1500"},
        {"ZIPCode": "02134", "Territory_ID": "OTHERTEAM", "Team": "Hemady", "FileID": "2000"},
    ]))
    assert al.file_id == "1500" and al.table["Territory_ID"].tolist() == ["NEW"]
    al2 = en.prepare_alignment(make_alignment([
        {"ZIPCode": "02134", "Territory_ID": "OLD", "FileID": "900"},
        {"ZIPCode": "02134", "Territory_ID": "NEW", "FileID": "1500"},
    ]), file_id="900")
    assert al2.table["Territory_ID"].tolist() == ["OLD"]


def test_duplicate_zips_are_deduplicated_and_reported():
    al = en.prepare_alignment(make_alignment([
        {"ZIPCode": "02134", "Territory_ID": "T1"}, {"ZIPCode": "2134", "Territory_ID": "T2"},
        {"ZIPCode": "10001", "Territory_ID": "T3"},
    ]))
    assert len(al.table) == 2
    assert len(al.duplicates) == 2
    assert any("different territories" in w for w in al.warnings)
    s, _ = dp.prepare_sales(make_sales([{"Ship_To_Zip": "02134"}] * 3))
    assert len(en.apply_alignment(s, al)) == 3


def test_duplicate_zip_in_table_stops_join():
    s, _ = dp.prepare_sales(make_sales([{}]))
    al = en.AlignmentResult(pd.DataFrame({"ZIPCode": ["02134", "02134"], "Region_ID": ["a", "b"],
                                          "Region_Name": ["a", "b"], "Territory_ID": ["a", "b"],
                                          "Territory_Name": ["a", "b"], "CAM_Territory_Name": ["a", "b"]}),
                            "1", ["1"])
    with pytest.raises(en.JoinCheckError) as ei:
        en.apply_alignment(s, al)
    assert "double-count" in str(ei.value) and len(ei.value.detail) == 2


def test_alignment_summary_warnings():
    summ = pd.DataFrame({"Team": ["Fusion", "Fusion", "Hemady"], "FileID": ["1400", "1500", "1"],
                         "Rows": [10, 12, 5], "Zips": [10, 11, 5]})
    w = en.check_alignment_summary(summ)
    assert any("several FileIDs" in x for x in w) and any("duplicated" in x for x in w)
    assert any("missing" in x for x in en.check_alignment_summary(summ[summ.Team != "Fusion"]))


# --- customer master ----------------------------------------------------------------
def _sales_with_alignment(rows):
    s, _ = dp.prepare_sales(make_sales(rows))
    return en.apply_alignment(s, en.prepare_alignment(make_alignment([{"ZIPCode": "02134"}])))


def test_match_priority_combo_then_outlet_then_spor():
    s = _sales_with_alignment([
        {"Ship_To_DEA": "AA0000001", "COMBO": "AA0000001HOSP A1 MAIN STBOSTONMA02134"},
        {"Ship_To_DEA": "AA0000002", "COMBO": "nomatch"},
        {"Ship_To_DEA": "AA0000003", "SPORPL": "SPOR0000003"},
        {"Ship_To_DEA": "AA0000004"},
    ])
    cm = make_cm([
        {"SFCD_ID": "A", "ED_ID": "AA0000001", "COMBO": "aa0000001hosp a1  main stbostonma02134",
         "Parent_SFCD": "PCOMBO", "Parent_Name": "CORP - COMBO", "Parent_RecordTypeName": "Corporate_Account"},
        {"SFCD_ID": "B", "ED_ID": "AA0000001", "Parent_SFCD": "POUTLET1", "Parent_Name": "CORP - OUTLET1",
         "Parent_RecordTypeName": "Corporate_Account"},
        {"SFCD_ID": "C", "ED_ID": "AA0000002", "Parent_SFCD": "POUTLET", "Parent_Name": "CORP - OUTLET",
         "Parent_RecordTypeName": "Corporate_Account"},
        {"SFCD_ID": "D", "SF_External_ID": "SPOR0000003", "Parent_SFCD": "PSPOR", "Parent_Name": "CORP - SPOR",
         "Parent_RecordTypeName": "Corporate_Account"},
    ])
    r = en.match_parents(s, cm)
    got = r.sales.set_index("account_key")[["parent_name", "match_method"]].to_dict("index")
    assert got["AA0000001"] == {"parent_name": "CORP - COMBO", "match_method": "COMBO"}
    assert got["AA0000002"] == {"parent_name": "CORP - OUTLET", "match_method": "Outlet ID"}
    assert got["AA0000003"] == {"parent_name": "CORP - SPOR", "match_method": "SPOR"}
    assert got["AA0000004"] == {"parent_name": config.UNMAPPED, "match_method": config.UNMAPPED}
    assert len(r.sales) == 4


def test_key_with_several_parents_prefers_corporate_then_non_archived_then_frequency():
    cm = make_cm([
        {"SFCD_ID": "A", "ED_ID": "K1", "Parent_SFCD": "P1", "Parent_Name": "ARCH", "Parent_RecordTypeName": "Archived_HCO"},
        {"SFCD_ID": "B", "ED_ID": "K1", "Parent_SFCD": "P2", "Parent_Name": "CORP", "Parent_RecordTypeName": "Corporate_Account"},
        {"SFCD_ID": "C", "ED_ID": "K2", "Parent_SFCD": "P3", "Parent_Name": "ARCH", "Parent_RecordTypeName": "Archived_HCO"},
        {"SFCD_ID": "D", "ED_ID": "K2", "Parent_SFCD": "P4", "Parent_Name": "ORG", "Parent_RecordTypeName": "Organization_vod"},
        {"SFCD_ID": "E", "ED_ID": "K3", "Parent_SFCD": "P5", "Parent_Name": "ONE", "Parent_RecordTypeName": "Corporate_Account"},
        {"SFCD_ID": "F", "ED_ID": "K3", "Parent_SFCD": "P6", "Parent_Name": "TWO", "Parent_RecordTypeName": "Corporate_Account"},
        {"SFCD_ID": "G", "ED_ID": "K3", "Parent_SFCD": "P6", "Parent_Name": "TWO", "Parent_RecordTypeName": "Corporate_Account"},
    ])
    lk, conflicts = en.build_lookup(en.prepare_customer_master(cm), "ED_ID", "Outlet ID")
    pick = lk.set_index("key")["parent_key"].to_dict()
    assert pick == {"K1": "P2", "K2": "P4", "K3": "P6"}
    assert set(conflicts["reason"]) == {"Corporate_Account preferred", "Non-archived record preferred",
                                        "Most frequent parent"}


def test_standalone_and_self_parent():
    cm = en.prepare_customer_master(make_cm([
        {"SFCD_ID": "A", "SF_Name": "SOLO CLINIC", "ED_ID": "K1"},
        {"SFCD_ID": "B", "SF_Name": "SELF HOSP", "ED_ID": "K2", "Parent_SFCD": "B", "Parent_Name": "SELF HOSP",
         "Parent_RecordTypeName": "Archived_HCO"},
        {"SFCD_ID": "C", "SF_Name": "CORP - BIG", "SF_Type": "Corporate_Account", "SF_External_ID": "SPOR7",
         "Parent_SFCD": "C", "Parent_Name": "CORP - BIG", "Parent_RecordTypeName": "Corporate_Account"},
    ]))
    assert cm["parent_name"].tolist() == ["SOLO CLINIC (standalone)", "SELF HOSP (standalone)", "CORP - BIG"]
    assert cm["SF_External_ID"].tolist()[0] is pd.NA or pd.isna(cm["SF_External_ID"].iloc[0])


def test_shipto_never_splits_across_parents():
    s = _sales_with_alignment([
        {"Ship_To_DEA": "AA0000001", "COMBO": "OLDCOMBO", "Invoice_Date": "2026-01-05"},
        {"Ship_To_DEA": "AA0000001", "COMBO": "NEWCOMBO", "Invoice_Date": "2026-09-05"},
    ])
    cm = make_cm([
        {"SFCD_ID": "A", "ED_ID": "X1", "COMBO": "OLDCOMBO", "Parent_SFCD": "P_OLD", "Parent_Name": "OLD PARENT"},
        {"SFCD_ID": "B", "ED_ID": "X2", "COMBO": "NEWCOMBO", "Parent_SFCD": "P_NEW", "Parent_Name": "NEW PARENT"},
    ])
    r = en.match_parents(s, cm)
    assert set(r.sales["parent_name"]) == {"NEW PARENT"}
    assert r.shipto_conflicts["account_key"].nunique() == 1
    assert len(r.sales) == 2


def test_unidentified_rows_do_not_match_on_bare_combo():
    s = _sales_with_alignment([{"Ship_To_DEA": None, "Detail_Group_ID": None, "COMBO": "02134"}])
    cm = make_cm([{"SFCD_ID": "A", "ED_ID": "X", "COMBO": "02134", "Parent_SFCD": "P", "Parent_Name": "P"}])
    r = en.match_parents(s, cm)
    assert r.sales["match_method"].iloc[0] == config.UNMAPPED


# --- read-only guard -----------------------------------------------------------------
@pytest.mark.parametrize("sql", [
    "SELECT * FROM t WHERE d >= {start_date}",
    "with x as (select 1 a) select * from x",
    "SELECT [Update_Date], 'DROP TABLE x' AS note FROM t -- delete later",
    "/* INSERT */ SELECT 1",
])
def test_read_only_allows(sql):
    assert db.check_read_only(sql)[0]


@pytest.mark.parametrize("sql", [
    "DELETE FROM t", "SELECT 1; DROP TABLE t", "UPDATE t SET a=1", "EXEC sp_who", "MERGE t USING s ON 1=1",
    "SELECT * INTO #tmp FROM t", "TRUNCATE TABLE t", "ALTER TABLE t ADD c int", "insert into t values (1)",
    "", "sp_help", "DECLARE @a int",
])
def test_read_only_blocks(sql):
    assert not db.check_read_only(sql)[0]


def test_bind_date_placeholders():
    sql, params, had = db.bind_date_placeholders(
        "SELECT * FROM t WHERE d >= '{start_date}' AND d <= {end_date}", "2026-01-01", "2026-10-16")
    assert sql == "SELECT * FROM t WHERE d >= ? AND d <= ?"
    assert [str(p) for p in params] == ["2026-01-01", "2026-10-16"] and had
    assert not db.bind_date_placeholders("SELECT 1", "2026-01-01", "2026-01-02")[2]


def test_default_queries_are_read_only_and_parameterized():
    for q in [config.sales_query("ACROTECH_HUB"), config.sales_query("ACROTECH_HUB", True),
              config.anchor_query("ACROTECH_HUB"), config.alignment_query("ACROTECH_HUB"),
              config.customer_master_query("ACROTECH_HUB"), config.alignment_check_query("ACROTECH_HUB"),
              config.schema_query("ACROTECH_HUB")]:
        assert db.check_read_only(q)[0], q
    assert config.sales_query("ACROTECH_HUB").count("?") == 2 + len(config.ACTIVE_PRODUCTS)
    with pytest.raises(ValueError):
        config.table_ref("POWERBI_867", "bad]; DROP")


def test_connection_string_hides_nothing_in_url():
    p = db.ConnectionParams(server="srv", username="jdoe", password="s3cr;et", driver="ODBC Driver 18 for SQL Server")
    assert "s3cr;et" not in repr(p)
    assert "PWD={s3cr;et}" in p.odbc_string()
    what, how = db.friendly_error(Exception("Login failed for user 'jdoe'. s3cr;et"), p)
    assert "jdoe" in what and "s3cr;et" not in what + how
