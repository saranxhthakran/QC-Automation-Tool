"""Product deep dive engine, forecast and field actions: the Part 4 test list."""
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

import config
import data_prep as dp
import enrichment as en
import field_actions as FA
import forecast as F
import product_engine as pe
from tests.conftest import make_alignment, make_sales

SAMPLES = Path(__file__).resolve().parent / "samples"
Q = config.QTY_COLUMN
BEL = pe.settings_for("BELEODAQ")
RYZ = pe.settings_for("RYZNEUTA")


def rows(spec, product="BELEODAQ", dea="AB1234567", zip_="02134", name="TEST HOSP", **extra):
    """spec: list of (date, qty) or (date, qty, 'Returns'); one row per order."""
    out = []
    for i, s in enumerate(spec):
        d, q = s[0], s[1]
        sr = s[2] if len(s) > 2 else "Sales"
        out.append({"Product": product, "Invoice_Date": str(d), "Factored_QTY": str(q), "Sold_Qty": str(q),
                    "Factor": "1", "Converted_QTY": str(q), "Sale_Returns": sr, "Ship_To_DEA": dea,
                    "Detail_Group_ID": dea, "Ship_To_Name": name, "Ship_To_Zip": zip_,
                    "Wholesaler_Invoice_ID": f"{dea}-{i}", "Extended_Amount": str(float(q) * 4600), **extra})
    return out


def prep(*groups):
    s, _ = dp.prepare_sales(make_sales([r for g in groups for r in g]))
    return s


def enriched(*groups):
    al = make_alignment([{"ZIPCode": "02134"}, {"ZIPCode": "10001", "Territory_ID": "T2", "Territory_Name": "MANHATTAN, NY"}])
    return en.enrich(make_sales([r for g in groups for r in g]), al, None).sales


def d0(n):
    return date(2026, 1, 5) + timedelta(days=n)


# =============================================================================
# Settings and dose levels
# =============================================================================
def test_label_units_per_cycle():
    assert BEL["units_per_day"] == {"Standard": 4, "Reduced": 3, "Liver/kidney": 2}
    assert BEL["dose_level_units"] == {"Standard": 20.0, "Reduced": 15.0, "Liver/kidney": 10.0}
    assert BEL["units_per_cycle"] == 20 and RYZ["units_per_cycle"] == 1
    big = pe.settings_for("BELEODAQ", {"bsa_m2": 2.1})       # 1000 × 2.1 / 500 = 4.2 -> 5 vials a day
    assert big["units_per_cycle"] == 25


@pytest.mark.parametrize("units, level", [(20, "Standard"), (19, "Standard"), (15, "Reduced"), (10, "Liver/kidney"),
                                          (4, pe.PARTIAL), (40, pe.MULTI), (27, pe.MULTI), (-3, pe.RETURNED)])
def test_dose_level_inference(units, level):
    assert pe.dose_level(units, BEL) == level


# =============================================================================
# Events
# =============================================================================
def test_daily_orders_merge_into_one_cycle_event():
    s = prep(rows([(d0(i), 4) for i in range(5)]))
    ev = pe.build_events(s, BEL)
    assert len(ev) == 1
    e = ev.iloc[0]
    assert e["net_units"] == 20 and e["n_orders"] == 5 and e["dose_level"] == "Standard"
    assert e["buying_style"] == "Per day" and e["ce"] == pytest.approx(1.0)


def test_single_cycle_order_stays_one_event():
    s = prep(rows([(d0(0), 20), (d0(21), 20)]))
    ev = pe.build_events(s, BEL)
    assert ev["net_units"].tolist() == [20, 20]
    assert ev["buying_style"].tolist() == ["Per cycle", "Per cycle"]


def test_returns_net_into_the_event_they_fall_in():
    s = prep(rows([(d0(0), 20), (d0(3), -5, "Returns"), (d0(21), 15), (d0(30), -15, "Returns")]))
    ev = pe.build_events(s, BEL)
    assert ev["net_units"].tolist() == [15, 0]           # the second return nets the second event to zero
    assert ev["dose_level"].tolist() == ["Reduced", pe.RETURNED]


def test_positive_return_is_corrected_before_netting():
    s = prep(rows([(d0(0), 20), (d0(2), 5, "Returns")]))
    ev = pe.build_events(s, BEL)
    assert ev["net_units"].tolist() == [15]


def test_ryzneuta_window_is_three_days():
    s = prep(rows([(d0(0), 1), (d0(2), 1), (d0(3), 1)], product="RYZNEUTA"))
    ev = pe.build_events(s, RYZ)
    assert ev["net_units"].tolist() == [2, 1]


def test_no_charge_units():
    r = rows([(d0(0), 20), (d0(21), 20)])
    r[1]["Extended_Amount"] = "0"
    s = prep(r)
    ev = pe.build_events(s, BEL)
    assert ev["no_charge_units"].tolist() == [0, 20]
    nc = pe.no_charge_summary(s)
    assert nc["rows"] == 1 and nc["units"] == 20 and nc["share"] == pytest.approx(0.5)


# =============================================================================
# Regimes (from the RYZNEUTA sample)
# =============================================================================
@pytest.fixture(scope="module")
def ryz_sample():
    raw = dp.read_headerless_csv(SAMPLES / "RYZNEUTA_sample.csv", config.COLUMNS_867)
    s, _ = dp.prepare_sales(raw)
    return s


def test_regimes_on_sample(ryz_sample):
    ev = pe.build_events(ryz_sample, RYZ)
    reg = pe.classify_accounts(ev, RYZ).set_index("account_key")
    assert reg.loc["FS5198470", "regime"] == pe.RUNRATE        # SOUTHWEST CANCER CARE: multi-patient clinic
    assert reg.loc["BN5041520", "regime"] == pe.CADENCE        # SOUTH SOUND ONCOLOGY: single-patient cadence
    assert "Run-rate:" in reg.loc["FS5198470", "reason"]


def test_new_start_agreement_on_sample(ryz_sample):
    res = pe.run_engine(ryz_sample, "RYZNEUTA", ryz_sample["Invoice_Date"].max())
    assert res.new_start["course_starts"] > 0
    assert res.new_start["pct_starts_flagged"] >= 80      # our course starts line up with 867 NEW START
    # South Sound: the 72-day gap starts a new course, as the NEW START flag does
    c = res.courses[res.courses["account_key"] == "BN5041520"]
    assert len(c) == 2 and c["start_flagged"].all()


# =============================================================================
# Courses and persistence
# =============================================================================
def _cadence(events):
    return pd.DataFrame({"account_key": events["account_key"].unique(), "regime": pe.CADENCE})


def test_course_ends_only_when_gap_exceeds_maximum_vs_as_of():
    s = prep(rows([(d0(0), 20), (d0(21), 20), (d0(42), 20)]))
    ev = pe.build_events(s, BEL)
    last = pd.Timestamp(d0(42))
    for days, status in [(30, pe.ONGOING), (42, pe.ONGOING), (43, pe.ENDED)]:
        c = pe.build_courses(ev, _cadence(ev), last + pd.Timedelta(days=days), BEL)
        assert c["status"].iloc[0] == status, days
    c = pe.build_courses(ev, _cadence(ev), last + pd.Timedelta(days=10), BEL)
    assert c["cycles"].iloc[0] == 3


def test_gap_over_maximum_splits_courses_and_dose_path():
    s = prep(rows([(d0(0), 20), (d0(21), 15), (d0(21 + 43), 20)]))
    ev = pe.build_events(s, BEL)
    c = pe.build_courses(ev, _cadence(ev), pd.Timestamp(d0(100)), BEL)
    assert len(c) == 2
    assert c["dose_path"].iloc[0] == "Standard → Reduced" and bool(c["dose_declining"].iloc[0])


def test_kaplan_meier_matches_hand_calculation():
    # courses: ended at 1, 1, 2, 3; ongoing at 2, 4
    p = pe.kaplan_meier([1, 1, 2, 3, 2, 4], [True, True, True, True, False, False])
    t = p.table.set_index("cycle")
    # S(1)=1; S(2)=1·(1-2/6)=4/6; S(3)=4/6·(1-1/4)=0.5; S(4)=0.5·(1-1/2)=0.25; S(5)=0.25·(1-0/1)=0.25
    assert t.loc[1, "survival"] == 1
    assert t.loc[2, "survival"] == pytest.approx(4 / 6)
    assert t.loc[3, "survival"] == pytest.approx(0.5)
    assert t.loc[4, "survival"] == pytest.approx(0.25)
    assert t.loc[5, "survival"] == pytest.approx(0.25)
    assert p.p_continue(1) == pytest.approx(4 / 6)      # P(reach 2 | reached 1)
    assert p.p_continue(2) == pytest.approx(0.75)       # 1 - 1/4
    assert p.drop_after_1 == pytest.approx(1 / 3)
    assert p.drop_after_2 == pytest.approx(0.25)
    assert p.median_cycles == 2.0                       # S(3) = 0.5: half have ended by cycle 2
    assert p.censored_cycles == [2, 4]


# =============================================================================
# Active patients
# =============================================================================
def test_ryzneuta_active_patient_range_q14_vs_q21():
    s = prep(rows([(d0(i * 2), 1) for i in range(9)], product="RYZNEUTA"))   # 9 syringes in 17 days
    ap = pe.active_patients(s, pd.Timestamp(d0(20)), RYZ)
    assert ap["units_21d"] == 9
    assert ap["low"] == pytest.approx(6.0) and ap["high"] == pytest.approx(9.0)    # ÷1.5 (q14) to ÷1 (q21)


def test_beleodaq_active_patients_are_cycle_equivalents():
    s = prep(rows([(d0(0), 20), (d0(5), 15)]))
    ap = pe.active_patients(s, pd.Timestamp(d0(10)), BEL)
    assert ap["low"] == ap["high"] == pytest.approx(1.75)


# =============================================================================
# Next order, overdue, forecast
# =============================================================================
def _engine(df, product="BELEODAQ", as_of=None, **ov):
    as_of = pd.Timestamp(as_of) if as_of is not None else df["Invoice_Date"].max()
    r = pe.run_engine(df[df["Product"] == product], product, as_of, ov or None)
    return r, F.next_orders(r, df[df["Product"] == product])


def test_next_order_cadence_account():
    s = enriched(rows([(d0(21 * i), 20) for i in range(6)]))
    r, n = _engine(s, as_of=d0(105 + 5))
    row = n.iloc[0]
    assert row["regime"] == pe.CADENCE and row["basis"] == "Own ordering rhythm"
    assert row["expected_date"] == pd.Timestamp(d0(105 + 21))
    assert row["expected_units"] == 20 and row["confidence"] == F.HIGH
    assert not row["is_overdue"]


def test_interval_is_kept_inside_the_label_band():
    s = enriched(rows([(d0(15 * i), 20) for i in range(5)]))      # every 15 days: clamped to the 18-day band edge
    r, n = _engine(s, as_of=d0(61))
    assert n.iloc[0]["regime"] == pe.CADENCE and n.iloc[0]["interval"] == 18
    s2 = enriched(rows([(d0(10 * i), 20) for i in range(5)]))     # every 10 days: several patients → run-rate
    r2, n2 = _engine(s2, as_of=d0(41))
    assert n2.iloc[0]["regime"] == pe.RUNRATE


def test_next_order_run_rate_account():
    spec = [(d0(i * 3), 3) for i in range(40)]
    s = enriched(rows(spec, product="RYZNEUTA"))
    r, n = _engine(s, "RYZNEUTA")
    row = n.iloc[0]
    assert row["regime"] == pe.RUNRATE and np.isnan(row["interval"])
    assert row["weekly_rate"] == pytest.approx(7.0, rel=0.25)       # 3 syringes every 3 days


def test_fewer_than_three_events_falls_back_with_low_confidence():
    s = enriched(rows([(d0(0), 20), (d0(21), 20)]), rows([(d0(21 * i), 20) for i in range(8)], dea="BB7654321"))
    r, n = _engine(s, as_of=d0(30))
    row = n.set_index("account_key").loc["AB1234567"]
    assert row["basis"].startswith("Product-level fallback") and row["confidence"] == F.LOW


def test_overdue_after_expected_date_plus_tolerance():
    s = enriched(rows([(d0(21 * i), 20) for i in range(4)]))      # last order d0(63), next expected d0(84)
    for as_of, overdue in [(d0(91), False), (d0(92), True)]:
        r, n = _engine(s, as_of=as_of)
        assert bool(n.iloc[0]["is_overdue"]) == overdue, as_of
    r, n = _engine(s, as_of=d0(63 + 43))                          # past the course gap: ended, not overdue
    assert n.iloc[0]["course_status"] == pe.ENDED and not n.iloc[0]["is_overdue"]


def test_quarter_landing_adds_forecast_to_qtd():
    s = enriched(rows([(d0(7 * i), 10) for i in range(60)], product="RYZNEUTA"))
    as_of = pd.Timestamp(s["Invoice_Date"].max())
    r, n = _engine(s, "RYZNEUTA")
    f = F.forecast_13w(s, r, n)
    land = F.quarter_landing(s, f, as_of)
    assert land["projected"] == pytest.approx(land["qtd"] + land["rest"])
    assert land["lo"] <= land["projected"] <= land["hi"]
    assert land["avg_last3"] == pytest.approx(130, rel=0.1)      # 13 weekly orders of 10 per quarter
    assert land["projected"] == pytest.approx(130, rel=0.2)


def test_forecast_blend_weights_sum_to_one():
    s = enriched(rows([(d0(7 * i), 10 + (i % 3)) for i in range(60)], product="RYZNEUTA"))
    r, n = _engine(s, "RYZNEUTA")
    f = F.forecast_13w(s, r, n)
    assert sum(f.weights.values()) == pytest.approx(1.0)
    assert len(f.table) == 14 and (f.table["lo"] <= f.table["blend"]).all() and (f.table["blend"] <= f.table["hi"]).all()


# =============================================================================
# Field actions
# =============================================================================
def test_priority_score_ordering():
    s = dict(BEL)
    p = FA.priority([20, 20, 5], [0.9, 0.5, 0.9], [2, 2, 2], s)
    assert list(np.argsort(-p)) == [0, 1, 2]
    s.update(w_units=0.0)                                      # weights change the order
    p2 = FA.priority([20, 5], [0.5, 0.9], [1, 1], s)
    assert p2[1] > p2[0]


def test_continuation_check_for_overdue_course():
    s = enriched(rows([(d0(21 * i), 20) for i in range(4)]))
    r, n = _engine(s, as_of=d0(95))
    acts, trade = FA.build_actions(r, n, s)
    a = acts[acts["action"] == "Continuation check"]
    assert len(a) == 1
    assert "Cycle 5 expected" in a["evidence"].iloc[0] and "usually orders every 21 days" in a["evidence"].iloc[0]
    assert a["Territory_Name"].iloc[0] == "BOSTON, MA"


def test_trade_items_go_to_operations():
    r_ = rows([(d0(21 * i), 20) for i in range(10)])
    for x in r_[-3:]:
        x["Extended_Amount"] = "0"                             # no-charge spike in the last 13 weeks
    s = enriched(r_)
    r, n = _engine(s, as_of=d0(200))
    _, trade = FA.build_actions(r, n, s)
    assert "No-charge units" in set(trade["issue"])
    assert set(trade["route_to"]) == {"Trade / operations"}


# =============================================================================
# Data quality and scope
# =============================================================================
def test_likely_duplicate_accounts():
    a = rows([(d0(0), 20)], dea=None, name="SITE ONE")
    for x in a:
        x["Ship_To_DEA"], x["Detail_Group_ID"], x["Address1"] = None, "HIN000123", "1 Main St."
    b = rows([(d0(30), 20)], dea="AB7777777", name="Site One")
    for x in b:
        x["Address1"] = "1 MAIN ST"
    s = prep(a, b)
    d = pe.likely_duplicates(s)
    assert len(d) == 1 and d["keys"].iloc[0] == "AB7777777, HIN000123"


def test_only_active_products(ryz_sample):
    raw = dp.read_headerless_csv(SAMPLES / "SQLQuery1.csv", config.COLUMNS_867)
    s, info = dp.prepare_sales(pd.concat([raw, dp.read_headerless_csv(SAMPLES / "RYZNEUTA_sample.csv",
                                                                       config.COLUMNS_867)]))
    assert set(s["Product"]) == {"BELEODAQ", "RYZNEUTA"} and info["rows_out_of_scope"] == 30
    with pytest.raises(KeyError):
        pe.settings_for("ADQUEY")
