"""Deterministic synthetic raw data for tests and smoke runs (no database needed)."""
from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import pandas as pd

import config

ZIPS = [
    ("02134", "R11", "NORTHEAST", "T1101", "BOSTON, MA", "Northeast"),
    ("10001", "R11", "NORTHEAST", "T1102", "MANHATTAN, NY", "Northeast"),
    ("19104", "R12", "MID-ATLANTIC", "T1201", "PHILADELPHIA, PA", "Mid-Atlantic"),
    ("44106", "R13", "GREAT LAKES", "T1301", "CLEVELAND, OH", "Central"),
    ("60611", "R13", "GREAT LAKES", "T1302", "CHICAGO, IL", "Central"),
]
WHOLESALERS = ["CARDINAL", "McKesson Specialty", "ASD", "Oncology Supply"]


def raw_data(seed: int = 7, max_dates=None):
    rng = np.random.default_rng(seed)
    max_dates = max_dates or {"BELEODAQ": date(2026, 10, 16), "RYZNEUTA": date(2026, 10, 14)}
    start = date(2025, 1, 6)
    rows = []
    inv = 100000
    accounts = []
    for i in range(40):
        z = ZIPS[i % len(ZIPS)] if i < 38 else ("99999", None, None, None, None, None)
        dea = f"A{chr(65 + i % 26)}{1000000 + i:07d}" if i not in (5, 6) else None
        hin = f"9{i:03d}HIN{i % 9}"
        accounts.append({"i": i, "dea": dea, "hin": hin, "zip": z[0], "name": f"ONCOLOGY CENTER {i:02d}",
                         "city": ["BOSTON", "NEW YORK", "PHILADELPHIA", "CLEVELAND", "CHICAGO"][i % 5],
                         "state": ["MA", "NY", "PA", "OH", "IL"][i % 5],
                         "ws": WHOLESALERS[i % len(WHOLESALERS)], "spor": f"SPOR{70000 + i:07d}"})
    for prod, md in max_dates.items():
        for a in accounts:
            i = a["i"]
            if prod == "RYZNEUTA" and i % 3 == 0:
                continue
            cadence = 7 + (i % 4) * 7
            base = 4 + (i % 7) * 2
            first = start + timedelta(days=int(rng.integers(0, 20)))
            if i == 11:   # new account
                first = md - timedelta(days=40)
            d = first
            while d <= md:
                stop = (i == 12 and d > md - timedelta(days=120))      # lapsed
                if not stop:
                    trend = 1.0
                    if i == 13:
                        trend = 1 + 2.5 * max(0, (d - date(2026, 4, 1)).days) / 200   # growing
                    if i == 14:
                        trend = max(0.15, 1 - 1.2 * max(0, (d - date(2026, 4, 1)).days) / 200)  # declining
                    qty = max(1, int(round(base * trend * rng.uniform(0.7, 1.3))))
                    if i == 15 and d >= md - timedelta(days=21) and d < md - timedelta(days=14):
                        qty *= 6       # spike
                    ws = a["ws"]
                    if i == 16 and d > md - timedelta(days=60):
                        ws = "ABC"     # wholesaler switch
                    inv += 1
                    rows.append(_row(prod, a, d, qty, "Sales", ws, inv))
                    if i == 17 and d > md - timedelta(days=30):
                        rows.append(_row(prod, a, d, qty, "Sales", ws, inv))     # duplicate
                    if rng.random() < 0.04:
                        inv += 1
                        rows.append(_row(prod, a, d + timedelta(days=3), -max(1, qty // 2), "Returns", ws, inv))
                d += timedelta(days=cadence + int(rng.integers(-2, 3)))
        # current-week sales on max date so MaxDate is exact
        rows.append(_row(prod, accounts[1], md, 5, "Sales", "CARDINAL", inv + 1))
        inv += 2
    # out of scope product
    rows.append(_row("ADQUEY", accounts[0], date(2026, 10, 15), 9, "Sales", "ABC", 1))
    sales = pd.DataFrame(rows)[config.REQUIRED_867].astype("string")

    al = pd.DataFrame([{"Team": "Fusion", "ZIPCode": z[0].lstrip("0"), "Region_ID": z[1], "Region_Name": z[2],
                        "Territory_ID": z[3], "Territory_Name": z[4], "FileID": "1500"}
                       for z in ZIPS]
                      + [{"Team": "Hemady", "ZIPCode": "02134", "Region_ID": "X", "Region_Name": "X",
                          "Territory_ID": "X", "Territory_Name": "OTHER TEAM", "FileID": "9"}])
    cm_rows = []
    for a in accounts:
        i = a["i"]
        parent = ("P1", "CORP - NORTHEAST HEALTH") if i % 5 in (0, 1) else ("P2", "CORP - MIDWEST ONCOLOGY") if i % 5 in (3, 4) else (None, None)
        if i % 4 == 0 and a["dea"]:
            combo = f"{a['dea']}{a['name']}1 MAIN ST{a['city']}{a['state']}{a['zip']}"
            cm_rows.append(_cm(f"SF{i}", a["name"], parent, a["dea"], "DEA", combo, "-"))
        elif i % 4 == 1:
            cm_rows.append(_cm(f"SF{i}", a["name"], parent, a["dea"] or a["hin"], "DEA", "", "-"))
        elif i % 4 == 2:
            cm_rows.append(_cm(f"SF{i}", a["name"], parent, None, None, "", a["spor"]))
    cm = pd.DataFrame(cm_rows)
    return sales, al, cm


def _row(prod, a, d, qty, sr, ws, inv):
    combo = f"{a['dea'] or ''}{a['name']}1 MAIN ST{a['city']}{a['state']}{a['zip']}"
    return {
        "Product": prod, "NDC": "72893000201", "Invoice_Date": d.isoformat(), "Converted_QTY": f"{qty:.6f}",
        "Sold_Qty": f"{qty:.6f}", "Factor": "1.0", "Factored_QTY": f"{qty:.3f}",
        "Sale_Returns": sr, "Trans_Type": "SS", "SPORPL": a["spor"], "Ship_To_DEA": a["dea"] or "NULL",
        "Detail_Group_ID": a["dea"] or a["hin"], "Ship_To_Name": a["name"], "Ship_To_City": a["city"],
        "Ship_To_State": a["state"], "Ship_To_Zip": a["zip"], "Shipper_Name": ws, "Contract": "NULL",
        "Extended_Amount": f"{qty * 4600:.2f}", "Wholesaler_Invoice_ID": str(inv), "COMBO": combo,
        "Address1": "1 MAIN ST", "Unit_Price": "4600.00", "Sales_Program_ID": "NULL",
        "PTCL_BELEODAQ": "Fusion" if a["zip"] != "99999" else "NULL", "New_Start": "NULL",
        "Load_Date": "2026-10-19",
    }


def _cm(sfcd, name, parent, ed_id, ed_type, combo, ext):
    return {"SFCD_ID": sfcd, "SF_External_ID": ext, "SF_Name": name, "SF_Type1": "Hospital",
            "Parent_SFCD": parent[0], "Parent_Name": parent[1],
            "Parent_RecordTypeName": "Corporate_Account" if parent[0] else None,
            "ED_ID": ed_id, "ED_ID_Type": ed_type, "COMBO": combo}


def enriched(seed: int = 7):
    import enrichment as en

    s, a, m = raw_data(seed)
    return en.enrich(s, a, m)
