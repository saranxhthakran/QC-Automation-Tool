from datetime import date, timedelta

import numpy as np
import pandas as pd
import pytest

import anomalies as A
import config
import metrics as M


def frame(rows):
    """rows: (date, qty[, account, product, is_return, extra dict])"""
    out = []
    for r in rows:
        d, q = r[0], r[1]
        acct = r[2] if len(r) > 2 else "A1"
        prod = r[3] if len(r) > 3 else "BELEODAQ"
        ret = r[4] if len(r) > 4 else q < 0
        extra = r[5] if len(r) > 5 else {}
        out.append({"Invoice_Date": pd.Timestamp(d), config.QTY_COLUMN: float(q), "account_key": acct,
                    "Product": prod, "is_return": ret, "Wholesaler_Invoice_ID": extra.get("wiid", f"{d}{acct}{q}"),
                    "Shipper_Name": extra.get("ws", "CARDINAL"), "Region_Name": extra.get("region", "NE"),
                    "Territory_Name": extra.get("terr", "BOSTON, MA"),
                    "parent_key": extra.get("parent", "P1"), "parent_name": extra.get("parent", "P1"),
                    "account_label": acct, "account_name": acct, "account_city": "", "account_state": "",
                    "match_method": "COMBO", "Load_Date": pd.Timestamp("2026-10-19")})
    return pd.DataFrame(out)


def test_period_kpis_hand_calculation():
    md = date(2026, 10, 14)   # Wednesday
    rows = [(md, 10), (date(2026, 10, 12), 5)]                    # current week Mon..Wed = 15
    rows += [(date(2026, 10, 7), 13)]                             # prior Wed: counts (same weekdays)
    rows += [(date(2026, 10, 9), 100)]                            # prior Fri: excluded when same weekdays
    rows += [(date(2026, 9, 14), -4)]                             # a return, Monday 4 weeks back
    rows += [(date(2026, 9, 30), 7), (date(2026, 8, 10), 20), (date(2026, 7, 2), 3)]
    df = frame(rows)
    k = {p.key: p for p in M.period_kpis(df, md, same_weekdays=True)}
    w = k["week"]
    assert w.current == 15
    assert w.average == pytest.approx((13 + 7 - 4 + 20) / 13)    # Sep 30 is a Wed; Aug 10 a Monday
    assert w.diff == pytest.approx(15 - w.average)
    k2 = {p.key: p for p in M.period_kpis(df, md, same_weekdays=False)}
    assert k2["week"].average == pytest.approx((13 + 100 + 7 - 4 + 20) / 13)
    mth = k["month"]   # Oct 1-14 = 15 + 13 + 100 = 128 ; Sep 1-14: -4 ; Aug 1-14: 20 ; Jul 1-14: 3
    assert mth.current == 128
    assert mth.average == pytest.approx((-4 + 20 + 3) / 3)
    q = k["quarter"]   # Q3 FY27 to date: Oct 1-14 = 128; Q2: Jul 1-14 = 3; Q1: Apr 1-14 = 0; Q4: Jan 1-14 = 0
    assert q.current == 128 and q.average == pytest.approx(1.0)
    assert q.title == "Q3 FY 2026-27 to date"


def test_zero_sales_weeks_count_as_zero_and_pct_none_when_no_history():
    md = date(2026, 10, 16)
    df = frame([(md, 10)])
    w = M.period_kpis(df, md)[0]
    assert w.average == 0 and w.pct is None
    ws = M.weekly_series(df, md, 26)
    assert len(ws) == 26 and ws["units"].sum() == 10 and ws["is_current"].iloc[-1]


def test_net_negative_period_from_returns():
    md = date(2026, 10, 16)
    df = frame([(date(2026, 10, 13), 5), (date(2026, 10, 14), -12)])
    assert M.period_kpis(df, md)[0].current == -7


def test_products_have_own_max_dates():
    df = frame([(date(2026, 10, 16), 1, "A", "BELEODAQ"), (date(2026, 10, 9), 1, "B", "RYZNEUTA")])
    assert M.product_max_date(df, "BELEODAQ") == date(2026, 10, 16)
    assert M.product_max_date(df, "RYZNEUTA") == date(2026, 10, 9)


def test_geo_change_sorted_by_pct():
    md = date(2026, 10, 16)
    rows = []
    for i in range(1, 14):
        d = md - timedelta(weeks=i)
        rows += [(d, 10, "A", "BELEODAQ", False, {"terr": "UP"}), (d, 10, "B", "BELEODAQ", False, {"terr": "DOWN"})]
    rows += [(md, 20, "A", "BELEODAQ", False, {"terr": "UP"}), (md, 2, "B", "BELEODAQ", False, {"terr": "DOWN"})]
    g = M.geo_change(frame(rows), "Territory", md, "week")
    assert g["name"].tolist() == ["DOWN", "UP"]
    assert g["pct"].tolist() == pytest.approx([-80.0, 100.0])


def _steady(acct, start, end, every, qty, **extra):
    rows, d = [], start
    while d <= end:
        rows.append((d, qty(d) if callable(qty) else qty, acct, "BELEODAQ", False, extra))
        d += timedelta(days=every)
    return rows


def test_trend_statuses():
    md = date(2026, 10, 16)
    s = date(2025, 10, 1)
    rows = []
    rows += _steady("STABLE", s, md, 7, 10)
    rows += _steady("GROW", s, md, 7, lambda d: 5 + max(0, (d - date(2026, 4, 16)).days) / 10)
    rows += _steady("DECL", s, md, 7, lambda d: max(1, 30 - max(0, (d - date(2026, 4, 16)).days) / 7))
    rows += _steady("LAPSED", s, md - timedelta(days=60), 7, 10)
    rows += _steady("NEW", md - timedelta(days=30), md, 7, 10)
    rows += _steady("ERRATIC", s, md, 7, 1)
    rows += [(date(2026, 4, 25), 150, "ERRATIC"), (date(2026, 7, 25), 150, "ERRATIC")]
    m = M.account_metrics(frame(rows), md, (date(2026, 10, 1), md)).set_index("account_key")
    st = m["status"].to_dict()
    assert st["STABLE"] == "Stable"
    assert st["GROW"] == "Growing" and m.loc["GROW", "slope_6m"] > 0
    assert st["DECL"] == "Declining"
    assert st["LAPSED"] == "Lapsed"
    assert st["NEW"] == "New"
    assert st["ERRATIC"] == "Erratic"
    assert m.loc["STABLE", "typical_interval"] == 7
    assert m.loc["STABLE", "avg_order_size"] == 10
    assert len(m.loc["STABLE", "spark"]) == 26


def test_parent_rollup_and_concentration():
    md = date(2026, 10, 16)
    s = date(2025, 10, 1)
    rows = _steady("A", s, md, 7, lambda d: 30 if d < date(2026, 7, 16) else 3, parent="P")
    rows += _steady("B", s, md, 7, 10, parent="P")
    df = frame(rows)
    am = M.account_metrics(df, md, (s, md))
    pm = M.parent_metrics(df, am, md, (s, md))
    assert pm.loc[0, "decline_pattern"].startswith("Concentrated in A")
    assert pm.loc[0, "shiptos"] == 2


def test_account_flags_reasons():
    md = date(2026, 10, 16)
    s = date(2025, 10, 1)
    rows = _steady("A", s, md, 7, 10)
    rows += [(date(2026, 10, 5), 60, "A", "BELEODAQ", False, {})]                   # big order
    rows += [(date(2026, 10, 6), -40, "A", "BELEODAQ", True, {})]                   # large return
    rows += [(date(2026, 10, 7), 8, "A", "BELEODAQ", False, {"wiid": "DUP"})] * 2   # duplicate
    rows += _steady("SW", s, date(2026, 8, 1), 7, 10, ws="CARDINAL")
    rows += _steady("SW", date(2026, 8, 8), md, 7, 10, ws="ABC")                    # wholesaler switch
    df = frame(rows)
    am = M.account_metrics(df, md, (date(2026, 7, 1), md))
    fl = A.account_flags(df, am, md, (date(2026, 7, 1), md))
    reasons = " | ".join(fl["reason"])
    assert "Unusually large order" in reasons
    assert "Large return" in reasons
    assert "Likely duplicate: invoice DUP" in reasons
    assert "Switched wholesaler" in reasons and "via ABC" in reasons
    assert (fl["reason"].str.len() > 10).all()


def test_returns_exceed_purchases():
    md = date(2026, 10, 16)
    rows = _steady("A", date(2026, 1, 1), date(2026, 8, 31), 7, 10)
    rows += [(date(2026, 9, 10), 5, "A"), (date(2026, 9, 12), -20, "A", "BELEODAQ", True)]
    df = frame(rows)
    am = M.account_metrics(df, md, (date(2026, 9, 1), md))
    fl = A.account_flags(df, am, md, (date(2026, 9, 1), md))
    assert fl["reason"].str.contains("Returns exceeded purchases in Sep 2026").any()


def test_series_anomalies_spike_and_drop():
    weeks = pd.date_range("2026-01-05", periods=20, freq="7D")
    vals = [10, 11, 9, 10, 10, 11, 9, 10, 0, 11, 9, 10, 10, 40, 10, 11, 9, 10, 10, 10]
    an = A.series_anomalies(pd.DataFrame({"week_start": weeks, "units": vals}))
    kinds = dict(zip(an["date"], an["kind"]))
    assert kinds[weeks[13]] == "spike"
    assert kinds[weeks[8]] == "drop"


def test_heatmap_and_top_movers():
    md = date(2026, 10, 16)
    s = date(2025, 10, 1)
    rows = _steady("UP", s, md, 7, lambda d: 5 if d < date(2026, 7, 16) else 15)
    rows += _steady("DOWN", s, md, 7, lambda d: 15 if d < date(2026, 7, 16) else 5)
    df = frame(rows)
    am = M.account_metrics(df, md, (s, md))
    g, d = M.top_movers(am, "account_key")
    assert g["account_key"].tolist() == ["UP"] and d["account_key"].tolist() == ["DOWN"]
    h = M.month_heatmap(df, "account_key", pd.Series(dtype=str), (date(2026, 5, 1), md))
    assert list(h.columns)[0] == "May 2026" and list(h.columns)[-1] == "Oct 2026"
