"""Connect & load with a fake database: stored territory tables, weekly prompt, Update, roster/users."""
import datetime as dt
from pathlib import Path

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

import config
import data_prep as dp
import db
import local_store as ls
from tests.synthetic import raw_data

APP = str(Path(__file__).resolve().parent.parent / "app.py")
SAMPLES = Path(__file__).resolve().parent / "samples"


@pytest.fixture()
def fake_db(tmp_path, monkeypatch):
    sales, al, cm = raw_data()
    roster = dp.read_headerless_csv(SAMPLES / "ROSTER_sample.csv", config.COLUMNS_ROSTER)
    users = dp.read_headerless_csv(SAMPLES / "USER_sample.csv", config.COLUMNS_USER)
    calls = []

    def run_query(engine, sql, params=None):
        calls.append(sql)
        if config.TABLE_ALIGNMENT in sql:
            return al.copy()
        if config.TABLE_ROSTER in sql:
            return roster.copy()
        if config.TABLE_USER in sql:
            return users.copy()
        if config.TABLE_CUSTOMER_MASTER in sql:
            return cm.copy()
        if "MAX(" in sql:
            return pd.DataFrame({"Product": ["BELEODAQ", "RYZNEUTA"],
                                 "MaxDate": pd.to_datetime(["2026-10-16", "2026-10-14"]),
                                 "LoadDate": pd.to_datetime(["2026-10-19", "2026-10-19"])})
        return sales.copy()

    monkeypatch.setattr(db, "run_query", run_query)
    monkeypatch.setattr(config, "LOCAL_STORE_DIR", str(tmp_path))
    return calls, tmp_path


def _connected_app():
    at = AppTest.from_file(APP, default_timeout=90)
    at.session_state["connected"] = True
    at.session_state["conn_params"] = db.ConnectionParams(server="sql-prod-02", database="ACROTECH_HUB",
                                                          username="u", password="p", driver="ODBC Driver 18 for SQL Server")
    at.session_state["engine"] = object()
    at.session_state["schema"] = {t: {"x": "nvarchar"} for t in config.ALL_TABLES + config.OPTIONAL_TABLES}
    at.session_state["anchors"] = pd.DataFrame({"Product": ["BELEODAQ", "RYZNEUTA"],
                                                "MaxDate": pd.to_datetime(["2026-10-16", "2026-10-14"]),
                                                "LoadDate": pd.to_datetime(["2026-10-19", "2026-10-19"])})
    at.session_state["tf_preset"] = "Last 12 months"
    return at


def _ref_calls(calls):
    return [c for c in calls if any(t in c for t in (config.TABLE_ALIGNMENT, config.TABLE_CUSTOMER_MASTER,
                                                     config.TABLE_ROSTER, config.TABLE_USER))]

STORED = ("ziptoterr", "customer_master", "roster", "user")


def test_first_load_pulls_and_stores_then_reuses(fake_db):
    calls, store = fake_db
    from ui.compute import cached_query

    cached_query.clear()
    at = _connected_app()
    at.run()
    at.switch_page("app_pages/1_Connect_and_load.py").run()
    assert not at.exception, [e.value for e in at.exception]
    assert any("not stored yet" in m.value for m in at.markdown)
    at.button(key="btn-load").click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert len(_ref_calls(calls)) == 4
    for n in STORED:
        assert (store / f"{n}.parquet").exists()
    data = at.session_state["data"]
    assert data.people is not None and len(data.people.owners) == 22
    assert data.sales["aligned"].any()
    assert (data.parents.shipto_parents["method"] != config.UNMAPPED).any()     # parents matched from the stored copy

    # Second load in the same week: no reference-table queries.
    n_before = len(_ref_calls(calls))
    at.button(key="btn-load").click().run()
    assert not at.exception
    assert len(_ref_calls(calls)) == n_before


def test_stale_prompt_and_update(fake_db):
    calls, store = fake_db
    src = ls.source_id("sql-prod-02", "ACROTECH_HUB")
    old = dt.datetime.now() - dt.timedelta(days=9)
    sales, al, cm = raw_data()
    for name, df in [(ls.ALIGNMENT, al), (ls.CUSTOMER_MASTER, cm), (ls.ROSTER, dp.read_headerless_csv(SAMPLES / "ROSTER_sample.csv",
                                                                             config.COLUMNS_ROSTER)),
                     (ls.USER, dp.read_headerless_csv(SAMPLES / "USER_sample.csv", config.COLUMNS_USER))]:
        ls.save(name, df, src, ls.table_meta(name, df), now=old)
    at = _connected_app()
    at.session_state["ref_store_meta"] = {n: ls.read_meta(n) for n in ls.REFERENCE_TABLES}
    at.run()
    at.switch_page("app_pages/1_Connect_and_load.py").run()
    assert not at.exception, [e.value for e in at.exception]
    assert any("9 days ago. Update the stored tables" in m.value for m in at.markdown)
    assert any("Stored tables 9 days old" in m.value for m in at.sidebar.markdown)

    at.button(key="btn-align-update").click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert len(_ref_calls(calls)) == 4
    for n in STORED:
        assert (store / f"{n}.prev.parquet").exists()
        assert ls.age_days(ls.read_meta(n)) < 0.01
    assert not any("days ago. Update the stored tables" in m.value for m in at.markdown)
