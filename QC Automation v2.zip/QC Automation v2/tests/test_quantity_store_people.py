"""Factored_QTY, returns sign check, the local territory-table store, and roster/user owners."""
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import pytest

import config
import data_prep as dp
import enrichment as en
import local_store as ls
import territory_people as tp
from tests.conftest import make_alignment, make_sales

SAMPLES = Path(__file__).resolve().parent / "samples"
Q = config.QTY_COLUMN


# =============================================================================
# Quantity
# =============================================================================
def test_qty_column_is_factored_qty():
    assert Q == "Factored_QTY"
    for c in ("Factored_QTY", "Sold_Qty", "Factor"):
        assert c in config.REQUIRED_867          # pulled by the default query
    assert "[Factored_QTY]" in config.sales_query("ACROTECH_HUB")


def test_qty_fallbacks_and_factor_checks():
    s, info = dp.prepare_sales(make_sales([
        {"Factored_QTY": "20", "Sold_Qty": "20", "Factor": "1"},           # normal
        {"Factored_QTY": None, "Sold_Qty": "2", "Factor": "10"},           # Sold_Qty × Factor
        {"Factored_QTY": None, "Sold_Qty": None, "Factor": None, "Converted_QTY": "7"},   # Converted_QTY
        {"Factored_QTY": "30", "Sold_Qty": "3", "Factor": "10"},           # Factor ≠ 1, consistent
        {"Factored_QTY": "5", "Sold_Qty": "3", "Factor": "1"},             # mismatch
    ]))
    assert s[Q].tolist() == [20, 20, 7, 30, 5]
    assert info["qty_source_counts"] == {"Factored_QTY": 3, "Sold_Qty × Factor": 1, "Converted_QTY": 1}
    assert info["factor_not_one_rows"] == 2
    assert info["factor_mismatch_rows"] == 1


def test_positive_returns_are_made_negative_and_counted():
    s, info = dp.prepare_sales(make_sales([
        {"Factored_QTY": "4", "Sale_Returns": "Returns"},     # wrong sign
        {"Factored_QTY": "-3", "Sale_Returns": "Returns"},    # already negative
        {"Factored_QTY": "10"},
    ]))
    assert s[Q].tolist() == [-4, -3, 10]
    assert info["positive_returns_fixed"] == 1
    assert info["negative_sale_rows"] == 0


@pytest.mark.parametrize("sample", ["SQLQuery1.csv", "RYZNEUTA_sample.csv"])
def test_samples_returns_negative_and_factor_one(sample):
    raw = dp.read_headerless_csv(SAMPLES / sample, config.COLUMNS_867)
    s, info = dp.prepare_sales(raw)
    assert info["positive_returns_fixed"] == 0
    assert info["factor_not_one_rows"] == 0
    assert (s.loc[s["is_return"], Q] < 0).all()
    assert (s.loc[~s["is_return"], Q] > 0).all()


def test_ryzneuta_sample_shape():
    raw = dp.read_headerless_csv(SAMPLES / "RYZNEUTA_sample.csv", config.COLUMNS_867)
    s, _ = dp.prepare_sales(raw)
    assert set(s["Product"]) == {"RYZNEUTA"}
    assert set(s["NDC"]) == {"72893001602"}
    assert s["Invoice_Date"].min() >= pd.Timestamp("2025-10-01")


def test_quantity_checks_table(samples):
    sales, al, cm = samples
    data = en.enrich(sales, al, cm)
    t = data.quantity_checks()
    assert t.iloc[0]["Result"].startswith("Factored_QTY")
    assert data.quality()["positive_returns_fixed"] == 0


# =============================================================================
# Local store
# =============================================================================
def _align(file_id="1500", n=3):
    return make_alignment([{"ZIPCode": f"0{2130 + i}", "Territory_ID": f"OAM110{i}", "FileID": file_id}
                           for i in range(n)])


SRC = ls.source_id("SQL-PROD-02", "ACROTECH_HUB")


def test_save_and_load_round_trip(tmp_path):
    df = _align()
    df["FileID"] = 1500.0     # numeric FileID from ODBC
    ls.save(ls.ALIGNMENT, df, SRC, ls.table_meta(ls.ALIGNMENT, df), lambda d: ls.validate(ls.ALIGNMENT, d),
            base=tmp_path)
    got = ls.load(ls.ALIGNMENT, SRC, base=tmp_path)
    assert got is not None and len(got.df) == 3
    assert set(got.df["FileID"]) == {"1500"}
    assert got.meta["latest_file_id"] == "1500" and got.meta["zips"] == 3
    # stored copy feeds the alignment step unchanged
    al = en.prepare_alignment(got.df)
    assert al.file_id == "1500" and len(al.table) == 3


def test_source_is_case_insensitive_and_other_source_ignored(tmp_path):
    ls.save(ls.ALIGNMENT, _align(), SRC, base=tmp_path)
    assert ls.load(ls.ALIGNMENT, ls.source_id("sql-prod-02 ", "acrotech_hub"), base=tmp_path) is not None
    assert ls.load(ls.ALIGNMENT, ls.source_id("other-server", "ACROTECH_HUB"), base=tmp_path) is None
    assert ls.load(ls.ROSTER, SRC, base=tmp_path) is None


def test_staleness_after_seven_days(tmp_path):
    now = datetime(2026, 10, 21, 9, 0)
    st_ = ls.save(ls.ALIGNMENT, _align(), SRC, base=tmp_path, now=now - timedelta(days=6, hours=23))
    assert not st_.is_stale(config.ALIGNMENT_STORE_MAX_AGE_DAYS, now)
    st_ = ls.save(ls.ALIGNMENT, _align(), SRC, base=tmp_path, now=now - timedelta(days=7))
    assert st_.is_stale(config.ALIGNMENT_STORE_MAX_AGE_DAYS, now)
    assert "7 days ago" in ls.describe(st_.meta, now)


def test_update_replaces_and_keeps_backup(tmp_path):
    ls.save(ls.ALIGNMENT, _align("1500"), SRC, ls.table_meta(ls.ALIGNMENT, _align("1500")), base=tmp_path)
    new = pd.concat([_align("1500"), _align("1600", 4)])
    ls.save(ls.ALIGNMENT, new, SRC, ls.table_meta(ls.ALIGNMENT, new), base=tmp_path)
    got = ls.load(ls.ALIGNMENT, SRC, base=tmp_path)
    assert got.meta["latest_file_id"] == "1600" and len(got.df) == 7
    assert (tmp_path / "ziptoterr.prev.parquet").exists()
    assert not list(tmp_path.glob("*.tmp.*"))


@pytest.mark.parametrize("bad, reason", [
    (pd.DataFrame(columns=config.REQUIRED_ALIGNMENT), "no rows"),
    (_align().drop(columns=["Territory_ID"]), "missing"),
    (_align().assign(Team="Hemady"), "Fusion"),
])
def test_failed_update_leaves_stored_copy_untouched(tmp_path, bad, reason):
    ls.save(ls.ALIGNMENT, _align(), SRC, base=tmp_path)
    before = (tmp_path / "ziptoterr.parquet").read_bytes()
    with pytest.raises(ls.StoreError, match=reason):
        ls.save(ls.ALIGNMENT, bad, SRC, validate=lambda d: ls.validate(ls.ALIGNMENT, d), base=tmp_path)
    assert (tmp_path / "ziptoterr.parquet").read_bytes() == before
    assert not (tmp_path / "ziptoterr.prev.parquet").exists()


def test_write_failure_restores_previous(tmp_path, monkeypatch):
    ls.save(ls.ALIGNMENT, _align(), SRC, base=tmp_path)
    real = ls.os.replace
    calls = {"n": 0}

    def flaky(a, b):
        calls["n"] += 1
        if calls["n"] == 3:       # after moving the old copy aside, fail swapping in the new one
            raise OSError("disk full")
        return real(a, b)

    monkeypatch.setattr(ls.os, "replace", flaky)
    with pytest.raises(ls.StoreError):
        ls.save(ls.ALIGNMENT, _align("1600"), SRC, base=tmp_path)
    monkeypatch.setattr(ls.os, "replace", real)
    got = ls.load(ls.ALIGNMENT, SRC, base=tmp_path)
    assert got is not None and set(got.df["FileID"]) == {"1500"}


def test_damaged_file_behaves_like_no_copy(tmp_path):
    ls.save(ls.ALIGNMENT, _align(), SRC, base=tmp_path)
    (tmp_path / "ziptoterr.parquet").write_bytes(b"not parquet")
    assert ls.load(ls.ALIGNMENT, SRC, base=tmp_path) is None


def test_oldest_copy_drives_the_prompt():
    metas = {ls.ALIGNMENT: {"pulled_at": "2026-10-20T09:00:00"}, ls.ROSTER: {"pulled_at": "2026-10-10T09:00:00"},
             ls.USER: None}
    name, meta = ls.oldest(metas)
    assert name == ls.ROSTER
    assert ls.is_stale(meta, 7, datetime(2026, 10, 21))


def test_reference_queries_are_read_only():
    import db

    for name in ls.REFERENCE_TABLES:
        sql, _ = ls.reference_query(name, "ACROTECH_HUB")
        assert db.check_read_only(sql)[0]


# =============================================================================
# Roster and users
# =============================================================================
@pytest.fixture(scope="module")
def people_raw():
    r = dp.read_headerless_csv(SAMPLES / "ROSTER_sample.csv", config.COLUMNS_ROSTER)
    u = dp.read_headerless_csv(SAMPLES / "USER_sample.csv", config.COLUMNS_USER)
    return r, u


def test_owner_join_preserves_roster_rows(people_raw):
    r, u = people_raw
    p = tp.build_owners(r, u, "2026-10-21")
    assert len(p.owners) == len(r) == 22
    assert p.owners["Territory_ID"].is_unique
    assert p.owners["owner_name"].notna().all()
    own = p.owner_map()
    assert own["OAM1104"] == "Joseph Dawson"
    assert own["OAM1101"] == "OAM Vacant_OAM1101"        # shown as given; no vacancy handling
    assert p.owners.set_index("Territory_ID").loc["OAM1102", "region_manager_login"].startswith("OAM1100@")


def test_new_to_territory(people_raw):
    r, u = people_raw
    p = tp.build_owners(r, u, "2026-10-21")
    new = set(p.owners.loc[p.owners["new_to_territory"], "owner_name"])
    assert new == {"Robbie Avlonitis", "Samuel Berry", "Philip Hess"}   # started Aug 31 / Sep 14; Vandell (May 5) not


def test_duplicate_users_pick_active_latest(people_raw):
    r, u = people_raw
    extra = u[u["Territory_ID"] == "OAM1104"].copy()
    extra["NAME"], extra["Start_Date"], extra["IsActive"] = "Old Rep", "2015-01-01", "0"
    p = tp.build_owners(r, pd.concat([u, extra]), "2026-10-21")
    assert len(p.owners) == 22
    assert p.owner_map()["OAM1104"] == "Joseph Dawson"
    assert any("more than one user" in w for w in p.warnings)


def test_roster_vs_alignment(people_raw, samples):
    r, u = people_raw
    al = en.prepare_alignment(samples[1])
    p = tp.build_owners(r, u, "2026-10-21", al.table)
    chk = p.roster_vs_alignment.set_index("Territory_ID")["Issue"]
    assert chk["OAM1101"] == "OK" and chk["OAM1102"] == "OK"
    assert chk["OAM1301"] == "In roster, not in alignment"   # the alignment sample only covers two territories
    renamed = al.table.assign(Territory_Name=al.table["Territory_Name"].str.replace("BOSTON", "BOSTON NORTH"))
    chk2 = tp.roster_vs_alignment(p.owners, renamed).set_index("Territory_ID")["Issue"]
    assert chk2["OAM1101"] == "Different name"


def test_missing_tables_hide_owners(people_raw):
    r, _ = people_raw
    p = tp.build_owners(None, None, "2026-10-21")
    assert not p.available and p.owners.empty
    p2 = tp.build_owners(r, None, "2026-10-21")
    assert len(p2.owners) == 22 and p2.owners["owner_name"].isna().all()
    assert any("user table" in w for w in p2.warnings)


# =============================================================================
# CAM territory is not used
# =============================================================================
def test_cam_territory_is_not_pulled_or_used(samples):
    import inspect

    import metrics as M

    assert "CAM_Territory_Name" not in config.REQUIRED_ALIGNMENT
    assert "CAM_Territory_Name" not in config.alignment_query("ACROTECH_HUB")
    assert "cams" not in inspect.signature(M.filter_data).parameters
    data = en.enrich(*samples)
    assert "CAM_Territory_Name" not in data.sales.columns
    assert "CAM_Territory_Name" not in data.alignment.table.columns


def test_customer_master_store_round_trip(tmp_path, samples):
    cm = samples[2]
    st_ = ls.save(ls.CUSTOMER_MASTER, cm, SRC, ls.table_meta(ls.CUSTOMER_MASTER, cm),
                  lambda d: ls.validate(ls.CUSTOMER_MASTER, d), base=tmp_path)
    assert st_.meta["accounts"] == cm["SFCD_ID"].nunique()
    got = ls.load(ls.CUSTOMER_MASTER, SRC, base=tmp_path)
    # parent matching gives the same result from the stored (all-text) copy as from the pull
    a = en.enrich(samples[0], samples[1], cm).parents.method_summary
    b = en.enrich(samples[0], samples[1], got.df).parents.method_summary
    pd.testing.assert_frame_equal(a, b)
    assert ls.validate(ls.CUSTOMER_MASTER, cm.assign(SFCD_ID=None))
    assert ls.validate(ls.CUSTOMER_MASTER, cm.drop(columns=["Parent_Name"]))
    sql, _ = ls.reference_query(ls.CUSTOMER_MASTER, "ACROTECH_HUB")
    assert config.TABLE_CUSTOMER_MASTER in sql
