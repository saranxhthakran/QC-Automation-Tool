"""Headless smoke test of every page with synthetic data (no database needed)."""
import datetime as dt
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from tests.synthetic import enriched

APP = str(Path(__file__).resolve().parent.parent / "app.py")


@pytest.fixture(scope="module")
def data():
    return enriched()


def _app(data):
    at = AppTest.from_file(APP, default_timeout=90)
    at.session_state["data"] = data
    at.session_state["data_meta"] = {"mode": "Default", "start": dt.date(2025, 1, 1), "end": dt.date(2026, 10, 16),
                                     "preset": "Last 2 years", "loaded_at": "2026-10-20T10:00:00", "sql": [],
                                     "file_id": "1500", "full_history": False}
    at.session_state["data_version"] = "test"
    return at


def test_pages_render_without_errors(data):
    at = _app(data)
    at.run()
    assert not at.exception
    assert sum('class="kpi' in m.value for m in at.markdown) == 3
    for page in ["app_pages/3_Accounts.py", "app_pages/4_Report.py", "app_pages/1_Connect_and_load.py"]:
        at.switch_page(page).run()
        assert not at.exception, (page, [e.value for e in at.exception])


def test_product_switch_and_filters(data):
    at = _app(data)
    at.run()
    at.session_state["product"] = "RYZNEUTA"
    at.run()
    assert "--accent:#0E8C7F" in at.markdown[0].value or any("--accent:#0E8C7F" in m.value for m in at.markdown)
    at.multiselect(key="ov_regions").set_value(["NORTHEAST"]).run()
    assert not at.exception
    assert set(at.multiselect(key="ov_territories").options) == {"BOSTON, MA", "MANHATTAN, NY"}


def test_only_active_products_reach_the_app(data):
    assert set(data.sales["Product"]) == {"BELEODAQ", "RYZNEUTA"}


def test_no_data_state():
    at = AppTest.from_file(APP, default_timeout=60)
    at.run()
    assert not at.exception
    assert any("No data loaded yet" in m.value for m in at.markdown)
