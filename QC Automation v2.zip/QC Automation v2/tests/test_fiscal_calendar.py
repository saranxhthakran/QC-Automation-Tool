from datetime import date

import pytest

import fiscal_calendar as fc


@pytest.mark.parametrize(
    "d,q,label,qs,qe",
    [
        (date(2026, 3, 31), 4, "Q4 FY 2025-26", date(2026, 1, 1), date(2026, 3, 31)),
        (date(2026, 4, 1), 1, "Q1 FY 2026-27", date(2026, 4, 1), date(2026, 6, 30)),
        (date(2026, 10, 16), 3, "Q3 FY 2026-27", date(2026, 10, 1), date(2026, 12, 31)),
        (date(2026, 12, 31), 3, "Q3 FY 2026-27", date(2026, 10, 1), date(2026, 12, 31)),
        (date(2027, 1, 1), 4, "Q4 FY 2026-27", date(2027, 1, 1), date(2027, 3, 31)),
        (date(2026, 7, 15), 2, "Q2 FY 2026-27", date(2026, 7, 1), date(2026, 9, 30)),
    ],
)
def test_fiscal_quarter_boundaries(d, q, label, qs, qe):
    assert fc.fiscal_quarter(d) == q
    assert fc.quarter_label(d) == label
    assert fc.quarter_start(d) == qs
    assert fc.quarter_end(d) == qe


def test_fiscal_year_label_and_end_year():
    assert fc.fiscal_year_label(date(2026, 4, 1)) == "FY 2026-27"
    assert fc.fiscal_year_label(date(2027, 3, 31)) == "FY 2026-27"
    assert fc.fiscal_year_end_year(date(2026, 10, 1)) == 2027
    assert fc.fiscal_year_label(date(2099, 12, 1)) == "FY 2099-00"


def test_shift_quarter_crosses_fiscal_year():
    assert fc.shift_quarter(date(2026, 5, 10), -1) == date(2026, 1, 1)   # Q1 FY27 -> Q4 FY26
    assert fc.shift_quarter(date(2026, 5, 10), -2) == date(2025, 10, 1)
    assert fc.shift_quarter(date(2026, 5, 10), -3) == date(2025, 7, 1)


def test_week_partial_same_weekdays():
    w = fc.week_windows(date(2026, 10, 14), same_weekdays=True)   # Wednesday
    assert w.current == (date(2026, 10, 12), date(2026, 10, 14))
    assert len(w.comparisons) == 13
    assert w.comparisons[0] == (date(2026, 10, 5), date(2026, 10, 7))
    assert all((e - s).days == 2 for s, e in w.comparisons)
    assert "Mon–Wed" in w.comparison_note


def test_week_partial_full_weeks():
    w = fc.week_windows(date(2026, 10, 14), same_weekdays=False)
    assert w.comparisons[0] == (date(2026, 10, 5), date(2026, 10, 11))
    assert all((e - s).days == 6 for s, e in w.comparisons)


def test_week_complete_sunday_is_full_either_way():
    w = fc.week_windows(date(2026, 10, 18), same_weekdays=True)  # Sunday
    assert w.current == (date(2026, 10, 12), date(2026, 10, 18))
    assert all((e - s).days == 6 for s, e in w.comparisons)


def test_weeks_spanning_dec_jan():
    assert fc.week_start(date(2027, 1, 1)) == date(2026, 12, 28)   # Friday -> Monday in prior year
    w = fc.week_windows(date(2027, 1, 1))
    assert w.current == (date(2026, 12, 28), date(2027, 1, 1))
    assert w.comparisons[0] == (date(2026, 12, 21), date(2026, 12, 25))


def test_month_end_capping():
    m = fc.month_windows(date(2026, 3, 31))
    assert m.current == (date(2026, 3, 1), date(2026, 3, 31))
    assert m.comparisons == [
        (date(2026, 2, 1), date(2026, 2, 28)),
        (date(2026, 1, 1), date(2026, 1, 31)),
        (date(2025, 12, 1), date(2025, 12, 31)),
    ]


def test_month_example_from_spec():
    m = fc.month_windows(date(2026, 10, 17))
    assert m.comparisons == [
        (date(2026, 9, 1), date(2026, 9, 17)),
        (date(2026, 8, 1), date(2026, 8, 17)),
        (date(2026, 7, 1), date(2026, 7, 17)),
    ]


def test_quarter_windows_cap_and_cross_year():
    q = fc.quarter_windows(date(2026, 4, 1))  # day 1 of Q1 FY27
    assert q.current == (date(2026, 4, 1), date(2026, 4, 1))
    assert q.comparisons[0] == (date(2026, 1, 1), date(2026, 1, 1))
    q = fc.quarter_windows(date(2026, 12, 31))  # 92 days into Q3
    assert q.current == (date(2026, 10, 1), date(2026, 12, 31))
    # Q2 (Jul-Sep) has 92 days, Q1 (Apr-Jun) 91 days: capped at quarter end
    assert q.comparisons[0] == (date(2026, 7, 1), date(2026, 9, 30))
    assert q.comparisons[1] == (date(2026, 4, 1), date(2026, 6, 30))
    assert q.comparisons[2] == (date(2026, 1, 1), date(2026, 3, 31))
    assert q.title == "Q3 FY 2026-27 to date"


def test_minimum_analysis_start():
    assert fc.minimum_analysis_start(date(2026, 10, 16)) == date(2026, 1, 1)
    assert fc.minimum_analysis_start(date(2026, 5, 2)) == date(2025, 7, 1)
    # the minimum preset covers everything the Overview needs
    for d in [date(2026, 10, 16), date(2026, 4, 1), date(2026, 12, 31), date(2027, 3, 31)]:
        assert fc.minimum_analysis_start(d) <= fc.required_start(d)


def test_presets_and_warnings():
    a = date(2026, 10, 16)
    assert fc.preset_range("Last 12 months", a) == (date(2025, 10, 17), a)
    assert fc.preset_range("Full history (2018–today)", a, today=date(2026, 10, 20))[0] == date(2018, 1, 1)
    assert fc.range_warnings(date(2018, 1, 1), a, a) == []
    w = fc.range_warnings(date(2026, 9, 1), a, a)
    assert any("13 weeks" in x for x in w) and any("fiscal quarters" in x for x in w)


def test_formatting():
    assert fc.fmt_date(date(2026, 10, 14)) == "Oct 14, 2026"
    assert fc.fmt_range((date(2026, 10, 12), date(2026, 10, 14))) == "Oct 12–14, 2026"
