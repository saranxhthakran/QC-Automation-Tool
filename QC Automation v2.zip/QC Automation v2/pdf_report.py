"""PDF summary of the Overview and Accounts pages (reportlab + kaleido chart images)."""
from __future__ import annotations

import io
import os
import warnings
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import (CondPageBreak, Image, KeepTogether, LongTable, PageBreak, Paragraph,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

import charts as C
import config
import fiscal_calendar as fc
import metrics as M
from ui.components import fmt_pct, fmt_units
from ui.compute import AccountsBundle, OverviewBundle, build_accounts, build_overview
from ui.theme import Theme

ROOT = Path(__file__).resolve().parent
PAGE = landscape(letter)
MARGIN = 0.6 * inch
CONTENT_W = PAGE[0] - 2 * MARGIN

# --- Fonts ----------------------------------------------------------------------------
_FONTS = {"Plex": "IBMPlexSans-Regular.ttf", "Plex-Medium": "IBMPlexSans-Medium.ttf", "Plex-SemiBold": "IBMPlexSans-SemiBold.ttf"}


def _register_fonts() -> tuple[str, str, str]:
    try:
        for name, f in _FONTS.items():
            if name not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(TTFont(name, str(ROOT / "static" / f)))
        return "Plex", "Plex-Medium", "Plex-SemiBold"
    except Exception:  # fonts missing: fall back to Helvetica
        return "Helvetica", "Helvetica", "Helvetica-Bold"


@dataclass
class ReportOptions:
    products: list[str]
    include_overview: bool = True
    include_accounts: bool = True
    include_appendix: bool = True
    include_deep_dive: bool = False
    deep_dive_filters: dict = field(default_factory=dict)  # regions, territories, parents, accounts, history_start
    deep_dive_settings: dict = field(default_factory=dict)  # product -> setting overrides
    overview_filters: dict = field(default_factory=dict)   # regions, territories, same_weekdays
    account_filters: dict = field(default_factory=dict)    # regions, territories, parents, accounts, window
    thresholds: dict = field(default_factory=dict)
    data_meta: dict = field(default_factory=dict)


# --- Styles ----------------------------------------------------------------------------------
class Styles:
    def __init__(self, th: Theme):
        reg, med, semi = _register_fonts()
        self.reg, self.med, self.semi = reg, med, semi
        ink, muted = colors.HexColor(th["ink"]), colors.HexColor(th["ink-muted"])
        self.title = ParagraphStyle("title", fontName=semi, fontSize=28, leading=35, textColor=ink, spaceAfter=6)
        self.h1 = ParagraphStyle("h1", fontName=semi, fontSize=20, leading=26, textColor=ink, spaceBefore=4, spaceAfter=8)
        self.h2 = ParagraphStyle("h2", fontName=semi, fontSize=14, leading=19, textColor=ink, spaceBefore=10, spaceAfter=6)
        self.body = ParagraphStyle("body", fontName=reg, fontSize=11, leading=16, textColor=ink, alignment=TA_LEFT)
        self.small = ParagraphStyle("small", fontName=reg, fontSize=9.5, leading=13.5, textColor=ink)
        self.caption = ParagraphStyle("caption", fontName=med, fontSize=8.5, leading=12, textColor=muted)
        self.cell = ParagraphStyle("cell", fontName=reg, fontSize=8.5, leading=11.5, textColor=ink)
        self.cell_head = ParagraphStyle("cellh", fontName=semi, fontSize=8.5, leading=11.5, textColor=muted)


def _esc(s) -> str:
    return (str(s) if s is not None else "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _table(rows: list[list], col_widths, st: Styles, th: Theme, num_cols=(), color_cells=None) -> LongTable:
    head = [Paragraph(_esc(h), st.cell_head) for h in rows[0]]
    body = [[Paragraph(_esc(c), st.cell) if not isinstance(c, Paragraph) else c for c in r] for r in rows[1:]]
    t = LongTable([head] + body, colWidths=col_widths, repeatRows=1, splitByRow=1)
    style = [
        ("FONTNAME", (0, 0), (-1, -1), st.reg),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.HexColor(th["border"])),
        ("LINEBELOW", (0, 1), (-1, -1), 0.4, colors.HexColor(th["border"])),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(th["surface-sunken"])),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]
    for ci in num_cols:
        style.append(("ALIGN", (ci, 0), (ci, -1), "RIGHT"))
    for (r, c_, col) in (color_cells or []):
        style.append(("TEXTCOLOR", (c_, r), (c_, r), colors.HexColor(col)))
    t.setStyle(TableStyle(style))
    return t


def _num_para(text: str, st: Styles, color: str | None = None) -> Paragraph:
    style = ParagraphStyle("n", parent=st.cell, alignment=2, textColor=colors.HexColor(color) if color else st.cell.textColor)
    return Paragraph(_esc(text), style)


# --- Chart rendering ------------------------------------------------------------------------------
class ChartRenderer:
    """Renders Plotly figures to PNG with kaleido.

    A tiny probe render runs first: without Chrome it fails fast (instead of the sync
    server hanging), and the report falls back to tables. With Chrome, one browser is
    kept alive for the whole report, and every render has a timeout.
    """

    TIMEOUT_S = 90

    def __init__(self):
        self.ok = True
        self.error = ""
        self._server = False
        self._pool = None

    def __enter__(self):
        import concurrent.futures as cf

        import plotly.graph_objects as go
        import plotly.io as pio

        self._pool = cf.ThreadPoolExecutor(max_workers=1)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                fut = self._pool.submit(pio.to_image, go.Figure(), format="png", width=20, height=20)
                fut.result(timeout=self.TIMEOUT_S)
        except Exception as exc:  # noqa: BLE001 - e.g. Chrome not installed
            self.ok = False
            msg = str(exc).split("\n")[0][:300]
            self.error = msg if msg and "Chrome" not in msg else "Google Chrome wasn't found or didn't start"
            return self
        try:
            import kaleido

            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                kaleido.start_sync_server(silence_warnings=True)
            self._server = True
        except Exception:  # noqa: BLE001 - renders still work without the shared browser
            self._server = False
        return self

    def __exit__(self, *a):
        if self._server:
            try:
                import kaleido

                kaleido.stop_sync_server(silence_warnings=True)
            except Exception:
                pass
        if self._pool:
            self._pool.shutdown(wait=False, cancel_futures=True)

    def image(self, fig, width_pt: float, height_pt: float) -> Image | None:
        if not self.ok:
            return None
        try:
            import plotly.io as pio

            px_w, px_h = int(width_pt * 1.5), int(height_pt * 1.5)
            fig.update_layout(width=px_w, height=px_h, margin=dict(l=10, r=30, t=10, b=10))

            def render():
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    return pio.to_image(fig, format="png", width=px_w, height=px_h, scale=2)

            png = self._pool.submit(render).result(timeout=self.TIMEOUT_S)
            return Image(io.BytesIO(png), width=width_pt, height=height_pt)
        except Exception as exc:  # noqa: BLE001
            self.ok = False
            self.error = (str(exc).split("\n")[0][:300] or "chart rendering timed out")
            return None


# --- Summary sentences ---------------------------------------------------------------------------
def summary_sentences(ob: OverviewBundle, ab: AccountsBundle | None, quality: dict) -> list[str]:
    out = []
    if not ob.kpis:
        return [f"No {ob.product} sales in the selected geography."]
    w, m, q = ob.kpis

    def phrase(k, avg_name):
        if k.pct is None:
            return f"{fmt_units(k.current)} units with no sales in the comparison period"
        direction = "above" if k.pct > 0 else "below"
        if abs(k.pct) < 2:
            return f"in line with its {avg_name} ({fmt_units(k.current)} units)"
        return f"{abs(k.pct):.0f}% {direction} its {avg_name} ({fmt_units(k.current)} vs {k.average:,.0f} units)"

    s = f"{ob.product} week to date is {phrase(w, '13-week average')}"
    rc = ob.region_change.get("week")
    if rc is not None and len(rc) > 1 and w.diff != 0:
        same = rc[(rc["diff"] * w.diff) > 0]
        if len(same):
            top = same.reindex(same["diff"].abs().sort_values(ascending=False).index).iloc[0]
            if abs(top["diff"]) >= 0.3 * abs(w.diff):
                s += f", driven by the {str(top['name']).title()} region"
    out.append(s + ".")
    out.append(f"Month to date is {phrase(m, '3-month average')}, and {q.title.replace(' to date', '')} to date is "
               f"{phrase(q, '3-quarter average')}.")
    tc = ob.territory_change.get("week")
    if tc is not None and len(tc.dropna(subset=['pct'])):
        t = tc.dropna(subset=["pct"])
        t = t[(t["average"] >= 3) & (t["name"] != config.UNALIGNED)]
        if len(t):
            lo, hi = t.iloc[0], t.iloc[-1]
            if lo["pct"] < -10:
                out.append(f"The largest weekly drop is in {lo['name']} ({fmt_pct(lo['pct'])} vs its 13-week average)"
                           + (f", while {hi['name']} leads growth ({fmt_pct(hi['pct'])})." if hi["pct"] > 10 else "."))
            elif hi["pct"] > 10:
                out.append(f"{hi['name']} leads growth this week ({fmt_pct(hi['pct'])} vs its 13-week average).")
    if ab is not None and len(ab.accounts):
        c = M.status_counts(ab.accounts)
        out.append(f"Of {len(ab.accounts):,} accounts, {c['Growing']:,} are growing, {c['Declining']:,} declining, "
                   f"{c['Lapsed']:,} lapsed and {c['New']:,} new.")
        if len(ab.flags):
            top_flag = ab.flags["flag"].value_counts().index[0]
            out.append(f"{ab.flags['account_key'].nunique():,} accounts carry flags in the selected dates; "
                       f"the most common is {top_flag.lower()}.")
    if quality:
        out.append(f"{quality['aligned_unit_pct']:.0f}% of units are aligned to a territory.")
    return out[:5]


# --- Page decoration ---------------------------------------------------------------------------------
class NumberedCanvas(rl_canvas.Canvas):
    def __init__(self, *args, footer_text="", font="Helvetica", ink="#5B6880", **kwargs):
        super().__init__(*args, **kwargs)
        self._saved = []
        self._footer_text, self._font, self._ink = footer_text, font, ink

    def showPage(self):
        self._saved.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        n = len(self._saved)
        for state in self._saved:
            self.__dict__.update(state)
            self.setFont(self._font, 8.5)
            self.setFillColor(colors.HexColor(self._ink))
            self.drawString(MARGIN, 0.38 * inch, self._footer_text)
            self.drawRightString(PAGE[0] - MARGIN, 0.38 * inch, f"Page {self._pageNumber} of {n}")
            super().showPage()
        super().save()


# --- Build ---------------------------------------------------------------------------------------
def build_pdf(data, opts: ReportOptions, progress=None) -> tuple[bytes, list[str]]:
    """Returns (pdf bytes, notes). `progress(step_index)` is called as steps start."""
    notes: list[str] = []
    th0 = Theme.for_product(opts.products[0], "light")
    st = Styles(th0)
    df = data.sales
    quality = data.quality()
    of, af = opts.overview_filters, opts.account_filters

    def step(i):
        if progress:
            progress(i)

    # 1. Building summary -------------------------------------------------------------------
    step(0)
    bundles = []
    for p in opts.products:
        ob = build_overview(df, p, of.get("regions", ()), of.get("territories", ()),
                            of.get("same_weekdays", True), opts.thresholds)
        md = ob.max_date
        win = af.get("window")
        if md and (not win or win[0] is None):
            win = (fc.quarter_start(md), md)
        ab = build_accounts(df, p, af.get("regions", ()), af.get("territories", ()),
                            af.get("parents", ()), af.get("accounts", ()), win, opts.thresholds) if md else None
        bundles.append((p, ob, ab))

    story = []
    meta = opts.data_meta

    # Cover --------------------------------------------------------------------------------------
    story.append(Spacer(1, 0.6 * inch))
    story.append(Paragraph(_esc(config.APP_NAME), st.title))
    story.append(Paragraph(" and ".join(opts.products) + " sell-through summary", st.h2))
    story.append(Spacer(1, 0.2 * inch))
    loads = [M.product_load_date(df, p) for p in opts.products]
    loads = [l for l in loads if l]
    lines = [
        ("Generated", datetime.now().strftime("%b %d, %Y at %H:%M")),
        ("Data timeframe", f"{fc.fmt_date(meta.get('start'))} – {fc.fmt_date(meta.get('end'))}"
                           + (f" ({meta.get('preset')})" if meta.get("preset") else "")),
        ("Data mode", meta.get("mode", "Default")),
        ("Latest load date", fc.fmt_date(max(loads)) if loads else "Unknown"),
        ("Latest invoice", "; ".join(f"{p}: {fc.fmt_date(ob.max_date)}" for p, ob, _ in bundles if ob.max_date)),
        ("Overview filters", _filters_text(of) + (", same weekdays" if of.get("same_weekdays", True) else ", full weeks")),
        ("Accounts filters", _filters_text(af) + (f", dates {fc.fmt_range(tuple(fc.to_date(x) for x in af['window']))}"
                                                  if af.get("window") and af["window"][0] else "")),
        ("Territory alignment", f"Team {config.TEAM}, FileID {data.alignment.file_id}, applied to all history"),
    ]
    rows = [["Item", "Value"]] + [[a, b] for a, b in lines]
    story.append(_table(rows, [1.8 * inch, CONTENT_W - 1.8 * inch], st, th0))
    story.append(PageBreak())

    # Summary --------------------------------------------------------------------------------------
    story.append(Paragraph("Summary", st.h1))
    for p, ob, ab in bundles:
        if len(bundles) > 1:
            story.append(Paragraph(p, st.h2))
        for s in summary_sentences(ob, ab, quality):
            story.append(Paragraph(_esc(s), st.body))
            story.append(Spacer(1, 4))

    # 2. Rendering charts ------------------------------------------------------------------------------
    step(1)
    with ChartRenderer() as cr:
        for p, ob, ab in bundles:
            th = Theme.for_product(p, "light")
            if opts.include_overview:
                story.append(PageBreak())
                story += _overview_section(p, ob, th, st, cr)
            if opts.include_accounts and ab is not None:
                story.append(PageBreak())
                story += _accounts_section(p, ab, th, st, cr)
            if opts.include_deep_dive and ob.max_date:
                story.append(PageBreak())
                story += _deep_dive_section(p, data, opts, th, st, cr)
        if not cr.ok:
            notes.append("Charts were left out because the chart renderer couldn't start: " + cr.error
                         + ". Install Google Chrome, or run `plotly_get_chrome`, then generate again.")

    # Appendix ---------------------------------------------------------------------------------------
    if opts.include_appendix:
        story.append(PageBreak())
        story += _appendix(data, quality, th0, st)
    if notes:
        story.append(Spacer(1, 12))
        for n in notes:
            story.append(Paragraph(_esc(n), st.caption))

    # 3. Laying out pages ---------------------------------------------------------------------------------
    step(2)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=PAGE, leftMargin=MARGIN, rightMargin=MARGIN, topMargin=MARGIN,
                            bottomMargin=0.7 * inch, title=f"{config.APP_NAME} report", author=config.APP_NAME)
    footer = f"{config.APP_NAME}  |  {' and '.join(opts.products)}  |  generated {datetime.now():%b %d, %Y}"
    doc.build(story, canvasmaker=lambda *a, **k: NumberedCanvas(*a, footer_text=footer, font=st.reg,
                                                                 ink=th0["ink-muted"], **k))
    # 4. Finishing
    step(3)
    return buf.getvalue(), notes


def _filters_text(f: dict) -> str:
    parts = []
    for k, lbl in [("regions", "Region"), ("territories", "Territory"), ("parents", "Parent")]:
        v = list(f.get(k) or [])
        if v:
            parts.append(f"{lbl}: {', '.join(map(str, v[:6]))}" + (f" and {len(v) - 6} more" if len(v) > 6 else ""))
    if f.get("accounts"):
        parts.append(f"{len(f['accounts'])} selected accounts")
    return "; ".join(parts) if parts else "None (all geographies)"


def _overview_section(p, ob: OverviewBundle, th: Theme, st: Styles, cr: ChartRenderer) -> list:
    out = [Paragraph(f"{p} overview", st.h1)]
    if not ob.kpis:
        return out + [Paragraph("No sales for this selection.", st.body)]
    out.append(Paragraph(f"Latest invoice {fc.fmt_date(ob.max_date)}. Net units; returns are netted in.", st.caption))
    out.append(Spacer(1, 6))
    rows = [["Period", "Dates", "Current", "Comparison average", "Difference", "% difference", "Comparison"]]
    col = []
    for i, k in enumerate(ob.kpis, start=1):
        clr = th["up-ink"] if (k.pct or 0) >= 2 else th["down-ink"] if (k.pct or 0) <= -2 else None
        arrow = "↑ " if (k.pct or 0) >= 2 else "↓ " if (k.pct or 0) <= -2 else ""
        rows.append([k.title, k.date_range, _num_para(fmt_units(k.current), st), _num_para(f"{k.average:,.1f}", st),
                     _num_para(fmt_units(k.diff, True), st, clr),
                     _num_para(arrow + fmt_pct(k.pct), st, clr), k.comparison_note])
    out.append(_table(rows, [1.4 * inch, 1.3 * inch, 0.8 * inch, 1.1 * inch, 0.85 * inch, 0.95 * inch,
                             CONTENT_W - 6.4 * inch], st, th, num_cols=(2, 3, 4, 5)))
    out.append(Spacer(1, 10))
    img = cr.image(C.weekly_trend(ob.weekly, ob.kpis[0].average, ob.weekly_anomalies, th), CONTENT_W, 2.5 * inch)
    if img:
        out.append(KeepTogether([Paragraph("Weekly trend, last 26 weeks", st.h2), img]))
    out.append(CondPageBreak(3.2 * inch))
    half = (CONTENT_W - 0.3 * inch) / 2
    rc, tc = ob.region_change["week"], ob.territory_change["week"]
    i1 = cr.image(C.change_bars(rc, th, height=max(180, 34 * len(rc) + 40)), half, min(3.4 * inch, max(1.6 * inch, 0.32 * inch * len(rc) + 0.5 * inch)))
    i2 = cr.image(C.change_bars(tc, th, height=max(180, 34 * min(len(tc), 20) + 40)), half,
                  min(4.6 * inch, max(1.6 * inch, 0.3 * inch * min(len(tc), 20) + 0.5 * inch)))
    if i1 and i2:
        t = Table([[Paragraph("Change by region, week to date", st.h2), Paragraph("Change by territory, week to date", st.h2)],
                   [i1, i2]], colWidths=[half + 0.15 * inch, half + 0.15 * inch])
        t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
        out.append(t)
    else:
        out.append(Paragraph("Change by territory, week to date", st.h2))
        rows = [["Territory", "Current", "13-week average", "% change"]] + [
            [r.name, _num_para(fmt_units(r.current), st), _num_para(f"{r.average:,.1f}", st), _num_para(fmt_pct(r.pct), st)]
            for r in tc.itertuples()]
        out.append(_table(rows, [3 * inch, 1.2 * inch, 1.4 * inch, 1.2 * inch], st, th, num_cols=(1, 2, 3)))
    out.append(CondPageBreak(1.5 * inch))
    out.append(Paragraph("Alerts", st.h2))
    if not ob.alerts:
        out.append(Paragraph("Nothing unusual against the recent averages.", st.body))
    else:
        rows = [["", "Alert", "Scope"]]
        cc = []
        for i, a in enumerate(ob.alerts[:25], start=1):
            sym = {"up": "↑", "down": "↓"}.get(a.severity, "!")
            clr = {"up": th["up-ink"], "down": th["down-ink"]}.get(a.severity, th["watch-ink"])
            rows.append([sym, a.sentence, a.scope])
            cc.append((i, 0, clr))
        out.append(_table(rows, [0.3 * inch, CONTENT_W - 2.6 * inch, 2.3 * inch], st, th, color_cells=cc))
    return out


def _accounts_section(p, ab: AccountsBundle, th: Theme, st: Styles, cr: ChartRenderer) -> list:
    out = [Paragraph(f"{p} accounts", st.h1)]
    if ab.accounts.empty:
        return out + [Paragraph("No accounts for this selection.", st.body)]
    w0, w1 = ab.window
    out.append(Paragraph(f"Selected dates {fc.fmt_range((fc.to_date(w0), fc.to_date(w1)))}. Status and trends use the full "
                         "pulled history.", st.caption))
    c = M.status_counts(ab.accounts)
    rows = [["Status"] + list(c.keys()), ["Accounts"] + [_num_para(f"{v:,}", st) for v in c.values()]]
    out.append(_table(rows, [1.2 * inch] + [(CONTENT_W - 1.2 * inch) / 6] * 6, st, th, num_cols=range(1, 7)))
    out.append(Spacer(1, 8))

    half = (CONTENT_W - 0.3 * inch) / 2
    for kind_label, m, label_col in [("accounts", ab.accounts, "account_label"), ("parents", ab.parents, "parent_name")]:
        g, d = M.top_movers(m, label_col, 10)
        ig = cr.image(C.movers(g, label_col, th, "up"), half, max(1.2, 0.27 * len(g) + 0.4) * inch) if len(g) else None
        idd = cr.image(C.movers(d, label_col, th, "down"), half, max(1.2, 0.27 * len(d) + 0.4) * inch) if len(d) else None
        out.append(CondPageBreak(3.6 * inch))
        if ig or idd:
            t = Table([[Paragraph(f"Top 10 growing {kind_label}", st.h2), Paragraph(f"Top 10 declining {kind_label}", st.h2)],
                       [ig or Paragraph("None", st.small), idd or Paragraph("None", st.small)]],
                      colWidths=[half + 0.15 * inch] * 2)
            t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
            out.append(t)
        else:
            for title, frame in [(f"Top 10 growing {kind_label}", g), (f"Top 10 declining {kind_label}", d)]:
                out.append(Paragraph(title, st.h2))
                rows = [["Name", "Last 3 months", "Prior 3 months", "Change", "% change", "Status"]] + [
                    [r[label_col], _num_para(fmt_units(r["last3"]), st), _num_para(fmt_units(r["prior3"]), st),
                     _num_para(fmt_units(r["delta_3v3"], True), st), _num_para(fmt_pct(r["pct_3v3"]), st), r["status"]]
                    for _, r in frame.iterrows()]
                out.append(_table(rows, [CONTENT_W - 5.0 * inch, 1 * inch, 1 * inch, 0.9 * inch, 0.9 * inch, 1.2 * inch],
                                  st, th, num_cols=(1, 2, 3, 4)))

    out.append(CondPageBreak(2 * inch))
    out.append(Paragraph("Flagged accounts", st.h2))
    if ab.flags.empty:
        out.append(Paragraph("No flags in the selected dates.", st.body))
    else:
        names = ab.accounts.set_index("account_key")["account_label"]
        rows = [["Account", "Flag", "Reason"]]
        cc = []
        fl = ab.flags.copy()
        fl["order"] = fl["flag"].map({"Drop": 0, "Lapsed": 1, "Suspicious": 2, "Spike": 3})
        fl = fl.sort_values(["order", "account_key", "date"], ascending=[True, True, False])
        for i, r in enumerate(fl.itertuples(), start=1):
            rows.append([names.get(r.account_key, r.account_key), r.flag, r.reason])
            cc.append((i, 1, {"up": th["up-ink"], "down": th["down-ink"]}.get(r.severity, th["watch-ink"])))
        out.append(_table(rows, [3.3 * inch, 0.9 * inch, CONTENT_W - 4.2 * inch], st, th, color_cells=cc))
    return out


def _deep_dive_section(p, data, opts: ReportOptions, th: Theme, st: Styles, cr: ChartRenderer) -> list:
    """Product deep dive: narrative, snapshot, forecast, persistence and the top field actions."""
    import deep_dive as DD
    import product_engine as pe

    f = opts.deep_dive_filters or {}
    unit = config.PRODUCT_PROFILES[p]["units"]
    ov = (opts.deep_dive_settings or {}).get(p, {})
    dd = DD.build(data.sales, p, ov, f.get("history_start"),
                  f.get("regions", ()), f.get("territories", ()), f.get("parents", ()),
                  f.get("accounts", ()), getattr(data, "people", None),
                  backtest_engine=DD.make_backtest_engine(data.sales, p, ov, f.get("history_start")))
    out = [Paragraph(f"{p} deep dive", st.h1),
           Paragraph(f"As of {fc.fmt_date(dd.as_of)}. Filters: {_esc(_filters_text(f))}. Units are "
                     f"{config.QTY_COLUMN}, net of returns. Patient, cycle and course figures are estimates from "
                     "account-level shipments, not patient records.", st.caption), Spacer(1, 6)]
    for n in dd.notices:
        out.append(Paragraph(_esc(n), st.caption))
    out.append(Paragraph("This week", st.h2))
    for line in dd.actions["narrative"]:
        out.append(Paragraph("• " + _esc(line), st.body))
    sn = dd.snapshot
    k, pts, land = sn["qtd_kpi"], sn["patients"], sn["landing"]
    rows = [["Measure", "Value", "Note"]]
    if k is not None:
        rows.append([f"{unit.capitalize()} quarter to date", _num_para(fmt_units(k.current), st),
                     f"{fmt_pct(k.pct)} vs the same days of the last 3 quarters"])
    rows += [["Estimated cycles QTD", _num_para(f"{sn['cycles_qtd']:,.1f}", st), "Estimate"],
             ["Estimated active patients", _num_para(pe.fmt_patients(pts["low"], pts["high"]), st),
              f"Estimate from {pts['units_21d']:,.0f} {unit} in the last 21 days"],
             ["Active accounts / parents", _num_para(f"{sn['active_children']} / {sn['active_parents']}", st),
              "Ordered in the last 90 days"],
             ["New course starts this quarter", _num_para(f"{sn['starts_qtd']}", st),
              f"Estimate; {sn['starts_prev']} in the same days last quarter"],
             [f"Projected {sn['quarter']} landing", _num_para(f"{land['projected']:,.0f}", st),
              f"Range {land['lo']:,.0f}–{land['hi']:,.0f}"
              + (f"; last {land['n_past']} quarters averaged {land['avg_last3']:,.0f}" if land.get("avg_last3") else "")]]
    out.append(Spacer(1, 6))
    out.append(_table(rows, [2.4 * inch, 1.2 * inch, CONTENT_W - 3.6 * inch], st, th, num_cols=(1,)))
    half = (CONTENT_W - 0.3 * inch) / 2
    fo = dd.forecast["fc"]
    i1 = cr.image(C.dd_forecast(fo.history, fo.table, unit, int(dd.settings["forecast_range_pct"]), th), half,
                  2.6 * inch) if len(fo.table) else None
    pers = dd.rhythm["persistence"]
    i2 = cr.image(C.dd_persistence(pers, th), half, 2.6 * inch) if pers.n_courses else None
    out.append(CondPageBreak(3.4 * inch))
    if i1 or i2:
        t = Table([[Paragraph(f"{int(dd.settings['forecast_weeks'])}-week forecast", st.h2),
                    Paragraph("Persistence (estimate)", st.h2)],
                   [i1 or Paragraph("Not enough history.", st.small), i2 or Paragraph("No courses yet.", st.small)],
                   [Paragraph(_esc(fo.sentence), st.caption), Paragraph(_esc(dd.takeaways.get("rhythm", "")), st.caption)]],
                  colWidths=[half + 0.15 * inch] * 2)
        t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
        out.append(t)
    else:
        out.append(Paragraph(_esc(fo.sentence), st.caption))
        out.append(Paragraph(_esc(dd.takeaways.get("rhythm", "")), st.caption))
    acts = dd.actions["actions"]
    out.append(CondPageBreak(2 * inch))
    out.append(Paragraph(f"Top field actions ({len(acts)} in total)", st.h2))
    if acts.empty:
        out.append(Paragraph("No field actions for this selection.", st.body))
    else:
        rows = [["Territory / owner", "Account", "Action", "Evidence", unit.capitalize() + " at stake", "Due by"]]
        for r in acts.head(20).itertuples():
            own = r.owner if isinstance(r.owner, str) else "—"
            terr_own = Paragraph(_esc(r.Territory_Name) + "<br/>" + _esc(own)
                                 + (" (new to territory)" if r.new_to_territory else ""), st.cell)
            rows.append([terr_own, r.account_name,
                         r.action, r.evidence, _num_para(f"{r.units_at_stake:,.1f}", st), fc.fmt_date(r.due_by)])
        out.append(_table(rows, [1.5 * inch, 1.7 * inch, 1.2 * inch, CONTENT_W - 6.0 * inch, 0.8 * inch, 0.8 * inch],
                          st, th, num_cols=(4,)))
    tr = dd.actions["trade"]
    if len(tr):
        out.append(CondPageBreak(1.5 * inch))
        out.append(Paragraph(f"For trade or operations ({len(tr)})", st.h2))
        rows = [["Account", "Issue", "Evidence"]] + [[r.account_name, r.issue, r.evidence] for r in tr.head(15).itertuples()]
        out.append(_table(rows, [2.4 * inch, 1.3 * inch, CONTENT_W - 3.7 * inch], st, th))
    return out


def _appendix(data, q: dict, th: Theme, st: Styles) -> list:
    out = [Paragraph("Appendix: data quality", st.h1)]
    rows = [["Measure", "Value"],
            ["Rows", f"{q['rows']:,}"], ["Accounts (ship-tos)", f"{q['accounts']:,}"],
            ["Return rows", f"{q['return_rows']:,}"], ["Rows without a DEA (fallback key used)", f"{q['null_key_rows']:,}"],
            ["Unidentified ship-to rows", f"{q['unidentified_rows']:,}"],
            ["Territory alignment, units matched", f"{q['aligned_unit_pct']:.1f}%"],
            ["Unaligned rows / zips", f"{q['unaligned_rows']:,} / {q['unaligned_zips']:,}"],
            ["Alignment", f"Team {config.TEAM}, FileID {data.alignment.file_id}, applied to all history"],
            ["Unmapped ship-tos", f"{q['unmapped_shiptos']:,}"],
            ["Parent key conflicts / ship-tos with several parents", f"{q['lookup_conflicts']:,} / {q['shipto_conflicts']:,}"]]
    out.append(_table(rows, [3.6 * inch, CONTENT_W - 3.6 * inch], st, th))
    out.append(Paragraph("Customer master match by method", st.h2))
    ms = data.parents.method_summary
    rows = [list(ms.columns)] + [[r["Method"], _num_para(f"{int(r['Ship-tos']):,}", st),
                                  _num_para(f"{r['% of ship-tos']:.1f}%", st), _num_para(f"{r['Units']:,.0f}", st),
                                  _num_para(f"{r['% of units']:.1f}%", st)] for _, r in ms.iterrows()]
    out.append(_table(rows, [2.2 * inch, 1.3 * inch, 1.3 * inch, 1.3 * inch, 1.3 * inch], st, th, num_cols=(1, 2, 3, 4)))
    for w in data.alignment.warnings:
        out.append(Paragraph(_esc(w), st.caption))
    return out
