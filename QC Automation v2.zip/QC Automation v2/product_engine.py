"""Product deep dive engine: 867 shipments → cycle events, account regimes, courses, persistence,
estimated active patients, and the tables behind each page section.

Everything works at the account (ship-to, "child") level and rolls up to parent, territory and region.
All patient, cycle and course numbers are ESTIMATES from account-level shipments; nothing here
identifies or tracks an individual patient.

Pure functions, no Streamlit; unit-tested in tests/test_product_engine.py.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

import config
import fiscal_calendar as fc

Q = config.QTY_COLUMN

DOSE_LABELS = {
    "Standard": "Standard (1,000 mg/m²)",
    "Reduced": "Reduced (750 mg/m²)",
    "Liver/kidney": "Liver/kidney (500 mg/m²)",
}
PARTIAL = "Partial cycle"
MULTI = "Multiple patients or stock"
RETURNED = "Returned"
STYLES = ["Per day", "Per cycle", "Multi-unit or stock"]
CADENCE, RUNRATE = "Cadence", "Run-rate"
ONGOING, ENDED = "Ongoing", "Ended"


# =============================================================================
# Settings
# =============================================================================
def settings_for(product: str, overrides: dict | None = None) -> dict:
    """Product defaults + shared defaults + user overrides, plus derived per-cycle units."""
    prof = config.PRODUCT_PROFILES[product]
    s = {**prof["defaults"], **config.DEEP_DIVE_DEFAULTS, **(overrides or {})}
    s["product"] = product
    s.update(derived_units(s))
    return s


def derived_units(s: dict) -> dict:
    """Units per cycle at each dose level. Beleodaq: ceil(dose × BSA ÷ vial mg) per day × days per cycle."""
    if s.get("fixed_units_per_cycle", 0) and s["fixed_units_per_cycle"] > 0:
        upc = float(s["fixed_units_per_cycle"])
        return {"units_per_cycle_label": upc, "units_per_cycle": upc, "units_per_day": {"Standard": upc},
                "dose_level_units": {"Standard": upc}}
    per_day, levels = {}, {}
    for name, key in [("Standard", "dose_standard"), ("Reduced", "dose_reduced"), ("Liver/kidney", "dose_organ")]:
        mg = float(s.get(key, 0) or 0)
        if mg <= 0:
            continue
        per_day[name] = math.ceil(mg * float(s["bsa_m2"]) / float(s["unit_mg"]) - 1e-9)
        levels[name] = float(per_day[name] * int(s["days_per_cycle"]))
    upc = levels.get("Standard", 1.0)
    return {"units_per_cycle_label": upc, "units_per_cycle": upc, "units_per_day": per_day, "dose_level_units": levels}


def settings_key(s: dict) -> tuple:
    """Hashable key for caches."""
    out = []
    for k, v in sorted(s.items()):
        out.append((k, tuple(sorted(v.items())) if isinstance(v, dict) else v))
    return tuple(out)


def ratio_q14(s: dict) -> float:
    """Syringes per 21-day window for the shorter cycle (q14 → 1.5)."""
    alt = s.get("alt_cycle_days") or 0
    return float(s["cycle_days"]) / float(alt) if alt else 1.0


# =============================================================================
# Cycle events
# =============================================================================
EVENT_COLUMNS = ["account_key", "event_no", "start", "end", "n_orders", "gross_units", "return_units", "net_units",
                 "no_charge_units", "ce", "dose_level", "pack_band", "buying_style", "shipper", "contract",
                 "new_start_flag"]


def dose_level(units: float, s: dict) -> str:
    """Inferred dose level of one event (Beleodaq) from its net units."""
    if units <= 0:
        return RETURNED
    levels = s["dose_level_units"]
    tol = float(s.get("dose_tolerance_units", 1.0))
    if s.get("fixed_units_per_cycle", 0):
        return "n/a"
    for name, u in levels.items():
        if abs(units - u) <= tol:
            return name
    if units < min(levels.values()) - tol:
        return PARTIAL
    return MULTI


def pack_band(units: float, s: dict) -> str:
    """Order-size band: dose bands for Beleodaq, pack multiples for Ryzneuta."""
    if units <= 0:
        return RETURNED
    if not s.get("fixed_units_per_cycle", 0):
        lvl = dose_level(units, s)
        return DOSE_LABELS.get(lvl, lvl)
    n = int(round(units))
    if n <= 1:
        return "1 syringe"
    if n == 2:
        return "2 syringes"
    if n <= 5:
        return "3–5 syringes"
    return "6+ syringes"


def buying_style(units: float, n_orders: int, s: dict) -> str:
    if units <= 0:
        return RETURNED
    if s.get("fixed_units_per_cycle", 0):
        return "Per cycle" if units <= 1.5 * s["units_per_cycle"] else "Multi-unit or stock"
    lvl = dose_level(units, s)
    if lvl == MULTI:
        return "Multi-unit or stock"
    if n_orders >= 2 or lvl == PARTIAL:
        return "Per day"
    return "Per cycle"


def build_events(df: pd.DataFrame, s: dict) -> pd.DataFrame:
    """Group each account's orders into cycle events.

    A sale more than `event_window_days` after the current event's first order starts a new event
    (Beleodaq 7 days merges daily 4-vial orders into one 20-vial cycle; Ryzneuta 3 days). Returns never
    start an event: they net into the event they fall in (the latest one started on or before them).
    """
    if df.empty:
        return pd.DataFrame(columns=EVENT_COLUMNS).astype(
            {"start": "datetime64[ns]", "end": "datetime64[ns]", "net_units": float, "gross_units": float,
             "return_units": float, "no_charge_units": float, "ce": float, "new_start_flag": bool, "n_orders": int,
             "event_no": int})
    window = int(s["event_window_days"])
    cols = ["account_key", "Invoice_Date", Q, "is_return", "Shipper_Name", "Contract", "Extended_Amount",
            "New_Start", "Wholesaler_Invoice_ID"]
    d = df[[c for c in cols if c in df.columns]].copy()
    for c in cols:
        if c not in d:
            d[c] = pd.NA
    d = d.sort_values(["account_key", "Invoice_Date", "is_return"], kind="mergesort").reset_index(drop=True)
    keys = d["account_key"].to_numpy()
    days = (d["Invoice_Date"].values.astype("datetime64[D]").astype(np.int64))
    ret = d["is_return"].to_numpy(dtype=bool)
    ev = np.zeros(len(d), dtype=np.int64)
    eid, prev_key, start = -1, None, None
    for i in range(len(d)):
        if keys[i] != prev_key:
            prev_key, start = keys[i], None
        if start is None or (not ret[i] and days[i] - start >= window):
            eid += 1
            start = days[i]
        ev[i] = eid
    d["_ev"] = ev
    d["_sale_units"] = np.where(ret, 0.0, d[Q].to_numpy(dtype=float))
    d["_ret_units"] = np.where(ret, d[Q].to_numpy(dtype=float), 0.0)
    amt = pd.to_numeric(d["Extended_Amount"], errors="coerce")
    d["_nc_units"] = np.where((~ret) & amt.eq(0).fillna(False).to_numpy(), d["_sale_units"], 0.0)
    d["_order"] = np.where(ret, None, d["Invoice_Date"].astype(str) + "|" + d["Wholesaler_Invoice_ID"].astype(str))
    d["_ns"] = (~ret) & d["New_Start"].astype("string").str.upper().str.contains("NEW", na=False).to_numpy()

    g = d.groupby("_ev", sort=True)
    sales_dates = d["Invoice_Date"].where(~d["is_return"])
    out = pd.DataFrame({
        "account_key": g["account_key"].first(),
        "start": sales_dates.groupby(d["_ev"]).min().fillna(g["Invoice_Date"].min()),
        "end": g["Invoice_Date"].max(),
        "n_orders": g["_order"].nunique(),
        "gross_units": g["_sale_units"].sum(),
        "return_units": g["_ret_units"].sum(),
        "no_charge_units": g["_nc_units"].sum(),
        "new_start_flag": g["_ns"].any(),
    })
    out["net_units"] = out["gross_units"] + out["return_units"]
    sales = d[~d["is_return"]]
    out["shipper"] = _mode_by_units(sales, "_ev", "Shipper_Name").reindex(out.index)
    out["contract"] = _mode_by_units(sales, "_ev", "Contract").reindex(out.index)
    out = out.reset_index(drop=True)
    out["event_no"] = out.groupby("account_key").cumcount() + 1
    return annotate_events(out, s)[EVENT_COLUMNS]


def annotate_events(ev: pd.DataFrame, s: dict) -> pd.DataFrame:
    """(Re)compute cycle-equivalents, dose level, pack band and buying style for the current settings."""
    ev = ev.copy()
    upc = float(s["units_per_cycle"])
    ev["ce"] = ev["net_units"] / upc
    ev["dose_level"] = [dose_level(u, s) for u in ev["net_units"]]
    ev["pack_band"] = [pack_band(u, s) for u in ev["net_units"]]
    ev["buying_style"] = [buying_style(u, n, s) for u, n in zip(ev["net_units"], ev["n_orders"])]
    return ev


def _mode_by_units(d: pd.DataFrame, key: str, col: str) -> pd.Series:
    if d.empty:
        return pd.Series(dtype="string")
    t = d.assign(_v=d[col].astype("string").fillna("—")).groupby([key, "_v"])["_sale_units"].sum().reset_index()
    t = t.sort_values([key, "_sale_units"], ascending=[True, False]).drop_duplicates(key)
    return t.set_index(key)["_v"]


# =============================================================================
# Account regime
# =============================================================================
REGIME_COLUMNS = ["account_key", "n_events", "mean_ce", "events_per_21d", "interval_cv", "median_gap",
                  "regime", "reason"]


def course_gaps(starts: pd.Series, max_gap: int) -> np.ndarray:
    g = np.diff(pd.to_datetime(starts).values.astype("datetime64[D]").astype(np.int64))
    return g[g <= max_gap]


def classify_accounts(events: pd.DataFrame, s: dict) -> pd.DataFrame:
    """Cadence (course logic applies) vs run-rate (several overlapping patients: volume only)."""
    ev = events[events["net_units"] > 0]
    rows = []
    max_gap = int(s["max_course_gap_days"])
    for key, g in ev.groupby("account_key", sort=False):
        g = g.sort_values("start")
        n = len(g)
        mean_ce = float(g["ce"].mean())
        gaps = course_gaps(g["start"], max_gap)
        active = float(gaps.sum()) + float(s["cycle_days"])
        per21 = n * 21.0 / active if n >= 2 else np.nan
        cv = float(np.std(gaps) / np.mean(gaps)) if len(gaps) >= 3 and np.mean(gaps) > 0 else np.nan
        reasons = []
        if mean_ce > s["regime_max_ce_per_event"]:
            reasons.append(f"averages {mean_ce:.1f} cycle-equivalents per order event")
        if per21 == per21 and per21 > s["regime_max_events_per_21d"]:
            reasons.append(f"orders {per21:.1f} times per 21 days")
        if cv == cv and cv > s["regime_max_interval_cv"]:
            reasons.append(f"gaps between orders vary a lot (CV {cv:.2f})")
        med = float(np.median(gaps)) if len(gaps) else np.nan
        if reasons:
            regime, reason = RUNRATE, "Run-rate: " + "; ".join(reasons) + "."
        elif n < 3:
            regime, reason = CADENCE, f"Cadence: only {n} order event{'s' if n > 1 else ''} so far, about " \
                                      f"{mean_ce:.1f} cycle-equivalents each."
        else:
            regime, reason = CADENCE, (f"Cadence: about {mean_ce:.1f} cycle-equivalents per event, usually every "
                                       f"{med:.0f} days.")
        rows.append({"account_key": key, "n_events": n, "mean_ce": mean_ce, "events_per_21d": per21,
                     "interval_cv": cv, "median_gap": med, "regime": regime, "reason": reason})
    return pd.DataFrame(rows, columns=REGIME_COLUMNS).astype({"n_events": int, "mean_ce": float,
                                                               "events_per_21d": float, "interval_cv": float,
                                                               "median_gap": float})


# =============================================================================
# Calibration
# =============================================================================
def calibrate(events: pd.DataFrame, regimes: pd.DataFrame, s: dict, min_n: int = 5) -> dict:
    """Observed median cycle size and interval from cadence accounts, next to the label values."""
    cad = set(regimes.loc[regimes["regime"] == CADENCE, "account_key"])
    ev = events[events["account_key"].isin(cad) & (events["net_units"] > 0)]
    one = ev[(ev["ce"] >= 0.5) & (ev["ce"] <= 1.5)]
    gaps = []
    for _, g in ev.groupby("account_key"):
        gaps.extend(course_gaps(g.sort_values("start")["start"], int(s["max_course_gap_days"])).tolist())
    obs_units = float(one["net_units"].median()) if len(one) >= min_n else None
    obs_gap = float(np.median(gaps)) if len(gaps) >= min_n else None
    return {"label_units": float(s["units_per_cycle_label"]), "observed_units": obs_units, "n_events": int(len(one)),
            "label_interval": float(s["cycle_days"]), "observed_interval": obs_gap, "n_gaps": len(gaps)}


def effective_settings(s: dict, calib: dict) -> dict:
    """Switch to observed values when the setting asks for it and there is enough data."""
    if not s.get("use_observed"):
        return s
    s2 = dict(s)
    if calib.get("observed_units"):
        s2["units_per_cycle"] = calib["observed_units"]
    if calib.get("observed_interval"):
        s2["cycle_days"] = int(round(calib["observed_interval"]))
    return s2


# =============================================================================
# Courses (cadence accounts only)
# =============================================================================
COURSE_COLUMNS = ["account_key", "course_no", "start", "last_event", "n_events", "cycles", "units", "status",
                  "days_since_last", "dose_path", "dose_declining", "start_flagged", "left_censored"]


def build_courses(events: pd.DataFrame, regimes: pd.DataFrame, as_of, s: dict, history_start=None) -> pd.DataFrame:
    """Runs of events with gaps ≤ the maximum course gap. Ended = gap since the last event exceeds the
    maximum, measured against `as_of` (the product's latest invoice date); otherwise ongoing."""
    as_of = pd.Timestamp(as_of)
    max_gap = int(s["max_course_gap_days"])
    hs = pd.Timestamp(history_start) if history_start is not None else None
    cad = set(regimes.loc[regimes["regime"] == CADENCE, "account_key"])
    ev = events[events["account_key"].isin(cad) & (events["net_units"] > 0)].sort_values(["account_key", "start"])
    rows = []
    for key, g in ev.groupby("account_key", sort=False):
        gap = g["start"].diff().dt.days.fillna(10 ** 6)
        cno = (gap > max_gap).cumsum()
        for c, cg in g.groupby(cno.values, sort=True):
            levels = [lv for lv in cg["dose_level"] if lv in DOSE_LABELS]
            path = _compress(levels)
            last = cg["start"].max()
            since = int((as_of - last).days)
            rows.append({
                "account_key": key, "course_no": int(c), "start": cg["start"].min(), "last_event": last,
                "n_events": len(cg), "cycles": max(1, int(round(cg["ce"].sum()))), "units": float(cg["net_units"].sum()),
                "status": ENDED if since > max_gap else ONGOING, "days_since_last": since,
                "dose_path": " → ".join(path) if path else ("—" if not s.get("fixed_units_per_cycle") else "n/a"),
                "dose_declining": _declining(path),
                "start_flagged": bool(cg["new_start_flag"].iloc[0]),
                "left_censored": bool(hs is not None and (cg["start"].min() - hs).days < max_gap),
            })
    out = pd.DataFrame(rows, columns=COURSE_COLUMNS)
    return out.astype({"left_censored": bool, "start_flagged": bool, "dose_declining": bool, "cycles": int,
                       "n_events": int, "course_no": int, "days_since_last": int, "units": float,
                       "start": "datetime64[ns]", "last_event": "datetime64[ns]"})


def _compress(seq: list[str]) -> list[str]:
    out = []
    for x in seq:
        if not out or out[-1] != x:
            out.append(x)
    return out


_RANK = {"Standard": 3, "Reduced": 2, "Liver/kidney": 1}


def _declining(path: list[str]) -> bool:
    return len(path) >= 2 and _RANK.get(path[-1], 0) < _RANK.get(path[-2], 0)


def new_start_agreement(courses: pd.DataFrame, events: pd.DataFrame, regimes: pd.DataFrame) -> dict:
    """How our course starts line up with the 867 New_Start flag (cadence accounts only)."""
    known = courses[~courses["left_censored"]]
    cad = set(regimes.loc[regimes["regime"] == CADENCE, "account_key"])
    ev = events[events["account_key"].isin(cad) & (events["net_units"] > 0)]
    flagged = ev[ev["new_start_flag"]]
    starts = set(zip(courses["account_key"], courses["start"]))
    flagged_at_start = sum((k, d) in starts for k, d in zip(flagged["account_key"], flagged["start"]))
    return {
        "course_starts": int(len(known)),
        "starts_flagged": int(known["start_flagged"].sum()),
        "pct_starts_flagged": 100 * known["start_flagged"].mean() if len(known) else None,
        "flagged_events": int(len(flagged)),
        "flagged_at_course_start": int(flagged_at_start),
        "pct_flags_at_start": 100 * flagged_at_start / len(flagged) if len(flagged) else None,
    }


# =============================================================================
# Persistence (Kaplan–Meier on cycles per course, ongoing courses censored)
# =============================================================================
@dataclass
class Persistence:
    table: pd.DataFrame = field(default_factory=pd.DataFrame)   # cycle, at_risk, ended, censored, survival, p_continue
    n_courses: int = 0
    n_ended: int = 0
    n_excluded: int = 0                                         # courses already running when the data starts
    median_cycles: float | None = None
    drop_after_1: float | None = None
    drop_after_2: float | None = None
    censored_cycles: list = field(default_factory=list)

    def p_continue(self, current_cycle: int, default: float = 0.8) -> float:
        """P(reaching cycle k+1 | reached cycle k)."""
        t = self.table
        if t.empty:
            return default
        row = t[t["cycle"] == int(current_cycle)]
        if row.empty or pd.isna(row["p_continue"].iloc[0]):
            valid = t["p_continue"].dropna()
            return float(valid.iloc[-1]) if len(valid) else default
        return float(row["p_continue"].iloc[0])

    def survival_at(self, k: int) -> float | None:
        r = self.table[self.table["cycle"] == k]
        return None if r.empty else float(r["survival"].iloc[0])


def kaplan_meier(cycles, ended) -> Persistence:
    """S(k) = P(course reaches cycle k). Ended courses are events at their last cycle; ongoing are censored."""
    T = np.asarray(cycles, dtype=int)
    E = np.asarray(ended, dtype=bool)
    if len(T) == 0:
        return Persistence()
    rows, S = [], 1.0
    for k in range(1, int(T.max()) + 1):
        n_k = int((T >= k).sum())
        d_k = int(((T == k) & E).sum())
        c_k = int(((T == k) & ~E).sum())
        p = 1 - d_k / n_k if n_k else np.nan
        rows.append({"cycle": k, "at_risk": n_k, "ended": d_k, "censored": c_k, "survival": S, "p_continue": p})
        if n_k:
            S = S * (1 - d_k / n_k)
    rows.append({"cycle": int(T.max()) + 1, "at_risk": 0, "ended": 0, "censored": 0, "survival": S, "p_continue": np.nan})
    t = pd.DataFrame(rows)
    med = None
    below = t[t["survival"] <= 0.5]
    if len(below):
        med = float(below["cycle"].iloc[0] - 1)          # last cycle reached by at least half the courses
    s2 = t.loc[t["cycle"] == 2, "survival"]
    s3 = t.loc[t["cycle"] == 3, "survival"]
    drop1 = float(1 - s2.iloc[0]) if len(s2) else None
    drop2 = float(1 - s3.iloc[0] / s2.iloc[0]) if len(s2) and len(s3) and s2.iloc[0] > 0 else None
    return Persistence(t, int(len(T)), int(E.sum()), 0, med, drop1, drop2, sorted(T[~E].tolist()))


def persistence(courses: pd.DataFrame) -> Persistence:
    known = courses[~courses["left_censored"]]
    p = kaplan_meier(known["cycles"], known["status"] == ENDED)
    p.n_excluded = int(courses["left_censored"].sum())
    return p


# =============================================================================
# Active patients (volume-based; includes run-rate accounts)
# =============================================================================
def active_patients(df: pd.DataFrame, as_of, s: dict) -> dict:
    """Beleodaq: cycle-equivalents in the last 21 days. Ryzneuta: syringes ÷ 1.5 (all q14) to ÷ 1 (all q21)."""
    a = pd.Timestamp(as_of)
    w = df[(df["Invoice_Date"] > a - pd.Timedelta(days=21)) & (df["Invoice_Date"] <= a)]
    units = max(0.0, float(w[Q].sum()))
    ce = units / float(s["units_per_cycle"])
    if s.get("alt_cycle_days"):
        return {"units_21d": units, "low": ce / ratio_q14(s), "high": ce, "point": (ce / ratio_q14(s) + ce) / 2}
    return {"units_21d": units, "low": ce, "high": ce, "point": ce}


def account_active_patients(df: pd.DataFrame, as_of, s: dict) -> pd.DataFrame:
    a = pd.Timestamp(as_of)
    w = df[(df["Invoice_Date"] > a - pd.Timedelta(days=21)) & (df["Invoice_Date"] <= a)]
    u = w.groupby("account_key")[Q].sum().clip(lower=0)
    ce = u / float(s["units_per_cycle"])
    low = ce / ratio_q14(s) if s.get("alt_cycle_days") else ce
    return pd.DataFrame({"units_21d": u, "patients_low": low, "patients_high": ce})


def fmt_patients(low: float, high: float) -> str:
    if abs(high - low) < 0.05:
        return f"{high:,.1f}"
    return f"{low:,.1f}–{high:,.1f}"


# =============================================================================
# Section helpers
# =============================================================================
def weekly_units_cycles(df: pd.DataFrame, as_of, s: dict, n_weeks: int = 52) -> pd.DataFrame:
    cur = fc.week_start(fc.to_date(as_of))
    weeks = pd.to_datetime([cur - pd.Timedelta(weeks=i) for i in range(n_weeks - 1, -1, -1)])
    if df.empty:
        u = pd.Series(0.0, index=weeks)
    else:
        ws = df["Invoice_Date"] - pd.to_timedelta(df["Invoice_Date"].dt.weekday, unit="D")
        u = df.groupby(ws)[Q].sum().reindex(weeks, fill_value=0.0)
    out = pd.DataFrame({"week_start": weeks, "units": u.values.astype(float)})
    out["cycles"] = out["units"] / float(s["units_per_cycle"])
    out["partial"] = (out["week_start"] == pd.Timestamp(cur)) & (fc.to_date(as_of).weekday() < 6)
    return out


def full_weekly(df: pd.DataFrame, as_of, start=None) -> pd.Series:
    """Weekly net units (Mon start) from `start` (or the first invoice) to the week of `as_of`, zero-filled."""
    end = pd.Timestamp(fc.week_start(fc.to_date(as_of)))
    if df.empty:
        return pd.Series(dtype=float)
    first = pd.Timestamp(fc.week_start(fc.to_date(start if start is not None else df["Invoice_Date"].min())))
    weeks = pd.date_range(first, end, freq="7D")
    ws = df["Invoice_Date"] - pd.to_timedelta(df["Invoice_Date"].dt.weekday, unit="D")
    return df.groupby(ws)[Q].sum().reindex(weeks, fill_value=0.0).astype(float)


def order_size_hist(events: pd.DataFrame, s: dict) -> pd.DataFrame:
    ev = events[events["net_units"] > 0]
    if ev.empty:
        return pd.DataFrame(columns=["units", "events", "band"])
    h = ev.groupby(ev["net_units"].round().astype(int)).size().rename("events").reset_index()
    h = h.rename(columns={"net_units": "units"})
    h["band"] = [pack_band(u, s) for u in h["units"]]
    return h


def monthly_mix(events: pd.DataFrame, col: str, months: int = 12, as_of=None) -> pd.DataFrame:
    """month × category share of net units (events with positive net units)."""
    ev = events[events["net_units"] > 0]
    if ev.empty:
        return pd.DataFrame()
    m = ev.assign(_m=ev["start"].dt.to_period("M").dt.to_timestamp())
    p = m.pivot_table(index="_m", columns=col, values="net_units", aggfunc="sum", fill_value=0.0)
    if as_of is not None:
        last = pd.Timestamp(fc.month_start(fc.to_date(as_of)))
        p = p.reindex(pd.date_range(last - pd.DateOffset(months=months - 1), last, freq="MS"), fill_value=0.0)
    else:
        p = p.tail(months)
    share = p.div(p.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
    share.index.name = "month"
    return share


def no_charge_summary(df: pd.DataFrame) -> dict:
    sales = df[~df["is_return"]]
    amt = pd.to_numeric(sales.get("Extended_Amount"), errors="coerce") if len(sales) else pd.Series(dtype=float)
    nc = sales[amt.eq(0).fillna(False)] if len(sales) else sales
    tot = float(sales[Q].sum()) if len(sales) else 0.0
    by_ws = nc.groupby("Shipper_Name")[Q].sum().sort_values(ascending=False) if len(nc) else pd.Series(dtype=float)
    return {"rows": int(len(nc)), "units": float(nc[Q].sum()) if len(nc) else 0.0,
            "share": float(nc[Q].sum()) / tot if tot else 0.0, "by_wholesaler": by_ws}


def interval_table(events: pd.DataFrame, regimes: pd.DataFrame, s: dict) -> pd.DataFrame:
    """Days between consecutive events within a course (cadence accounts), with an on-schedule flag."""
    cad = set(regimes.loc[regimes["regime"] == CADENCE, "account_key"])
    ev = events[events["account_key"].isin(cad) & (events["net_units"] > 0)].sort_values(["account_key", "start"])
    if ev.empty:
        return pd.DataFrame(columns=["account_key", "start", "gap", "on_schedule"])
    ev = ev.assign(gap=ev.groupby("account_key")["start"].diff().dt.days)
    ev = ev[ev["gap"].notna() & (ev["gap"] <= int(s["max_course_gap_days"]))]
    ev["on_schedule"] = on_schedule(ev["gap"], s)
    return ev[["account_key", "start", "gap", "on_schedule"]].reset_index(drop=True)


def schedule_bands(s: dict) -> list[tuple[int, int, str]]:
    bands = [(int(s["on_schedule_lo"]), int(s["on_schedule_hi"]), f"{int(s['cycle_days'])}-day cycle")]
    if s.get("alt_cycle_days") and s.get("alt_on_schedule_hi"):
        bands.append((int(s["alt_on_schedule_lo"]), int(s["alt_on_schedule_hi"]), f"{int(s['alt_cycle_days'])}-day cycle"))
    return bands


def on_schedule(gaps: pd.Series, s: dict) -> pd.Series:
    m = pd.Series(False, index=gaps.index)
    for lo, hi, _ in schedule_bands(s):
        m |= gaps.between(lo, hi)
    return m


def starts_by_month(courses: pd.DataFrame, as_of, s: dict, months: int = 18) -> pd.DataFrame:
    """New course starts per month (courses already running when the data starts are left out) and the
    number of courses running at each month end (start ≤ month end ≤ last event + one cycle; ongoing
    courses run to the latest invoice)."""
    last = pd.Timestamp(fc.month_start(fc.to_date(as_of)))
    idx = pd.date_range(last - pd.DateOffset(months=months - 1), last, freq="MS")
    if courses.empty:
        return pd.DataFrame({"month": idx, "starts": 0, "ongoing": 0})
    known = courses[~courses["left_censored"]]
    st_ = known.groupby(known["start"].dt.to_period("M").dt.to_timestamp()).size().reindex(idx, fill_value=0)
    end = courses["last_event"] + pd.Timedelta(days=int(s["cycle_days"]))
    end = end.where(courses["status"] == ENDED, pd.Timestamp(as_of) + pd.Timedelta(days=1))
    ongoing = []
    for m in idx:
        me = min(m + pd.offsets.MonthEnd(0), pd.Timestamp(as_of))
        ongoing.append(int(((courses["start"] <= me) & (end >= me)).sum()))
    return pd.DataFrame({"month": idx, "starts": st_.values, "ongoing": ongoing})


def likely_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Same normalized name + address + zip under different account keys. Listed, never merged."""
    if df.empty or "Address1" not in df:
        return pd.DataFrame(columns=["name", "address", "zip", "keys", "units"])

    def norm(s):
        return (s.astype("string").str.upper().str.replace(r"[^A-Z0-9 ]", " ", regex=True)
                .str.replace(r"\s+", " ", regex=True).str.strip())

    d = df.assign(_n=norm(df["Ship_To_Name"]), _a=norm(df["Address1"]))
    d = d[d["_n"].notna() & d["_a"].notna()]
    g = d.groupby(["_n", "_a", "zip5"]).agg(keys=("account_key", lambda x: sorted(set(x))), units=(Q, "sum"))
    g = g[g["keys"].str.len() > 1].reset_index()
    g["keys"] = g["keys"].str.join(", ")
    return g.rename(columns={"_n": "name", "_a": "address", "zip5": "zip"}).sort_values("units", ascending=False)


def contract_split(df: pd.DataFrame) -> pd.DataFrame:
    s = df[~df["is_return"]]
    if s.empty:
        return pd.DataFrame(columns=["Contract", "Ship-to name", "Units", "Share"])
    t = (s.assign(Contract=s["Contract"].astype("string").fillna("—"))
         .groupby(["Contract", "Ship_To_Name"], dropna=False)[Q].sum().reset_index()
         .rename(columns={"Ship_To_Name": "Ship-to name", Q: "Units"}).sort_values("Units", ascending=False))
    t["Share"] = t["Units"] / t["Units"].sum()
    return t


def cohorts(events: pd.DataFrame, as_of, s: dict, max_cohorts: int = 8, max_quarters: int = 8) -> dict:
    """By first-order fiscal quarter: % reordering within 2 cycles, median days to 2nd order, retention."""
    ev = events[events["net_units"] > 0].sort_values(["account_key", "start"])
    if ev.empty:
        return {"summary": pd.DataFrame(), "retention": pd.DataFrame()}
    first = ev.groupby("account_key")["start"].min()
    second = ev.groupby("account_key")["start"].apply(lambda x: x.iloc[1] if len(x) > 1 else pd.NaT)
    qs = first.map(lambda d: fc.quarter_start(d))
    lab = first.map(fc.quarter_label)
    as_of = pd.Timestamp(as_of)
    two_cycles = 2 * int(s["cycle_days"])
    days2 = (second - first).dt.days
    mature = (as_of - first).dt.days >= two_cycles
    base = pd.DataFrame({"cohort": lab, "qs": qs, "days2": days2, "re2": days2 <= two_cycles, "mature": mature})
    summ = (base.groupby(["qs", "cohort"]).agg(accounts=("days2", "size"), median_days_to_2nd=("days2", "median"))
            .reset_index())
    # % reordering within 2 cycles, among accounts whose first order is at least 2 cycles old
    pct = base[base["mature"]].groupby("qs")["re2"].mean() * 100
    summ["reorder_2_cycles"] = summ["qs"].map(pct)
    # retention: share of cohort accounts with an order in quarter +k
    ev = ev.assign(_qs=ev["start"].map(lambda d: fc.quarter_start(d)), _c=ev["account_key"].map(qs))
    ev["_k"] = [(_qidx(a) - _qidx(b)) for a, b in zip(ev["_qs"], ev["_c"])]
    act = ev.drop_duplicates(["account_key", "_k"]).groupby(["_c", "_k"]).size().unstack(fill_value=0)
    act = act.reindex(columns=range(0, max_quarters + 1), fill_value=0).sort_index().tail(max_cohorts)
    size = qs.value_counts()
    ret = act.div(size.reindex(act.index), axis=0) * 100
    cur_q = _qidx(fc.quarter_start(as_of))
    for c in ret.index:                                  # quarters that haven't happened yet are blank
        for k in ret.columns:
            if _qidx(c) + k > cur_q:
                ret.loc[c, k] = np.nan
    ret.index = [fc.quarter_label(c) for c in ret.index]
    ret.columns = [f"Q+{k}" for k in ret.columns]
    return {"summary": summ.drop(columns=["qs"]).tail(max_cohorts).reset_index(drop=True), "retention": ret}


def _qidx(d) -> int:
    d = fc.to_date(d)
    return fc.fiscal_year_start(d).year * 4 + fc.fiscal_quarter(d) - 1


def growth_bridge(df: pd.DataFrame, as_of):
    """QTD vs the same span of last quarter, by account: new, reactivated, growth, decline, lost.
    Returns (steps, per-account table, (prior start, prior end))."""
    md = fc.to_date(as_of)
    qs = fc.quarter_start(md)
    n_days = (md - qs).days
    ps = fc.shift_quarter(qs, -1)
    pe = min(ps + pd.Timedelta(days=n_days).to_pytimedelta(), fc.quarter_end(ps))
    ps, pe = fc.to_date(ps), fc.to_date(pe)
    cur = df[(df["Invoice_Date"] >= pd.Timestamp(qs)) & (df["Invoice_Date"] <= pd.Timestamp(md))].groupby("account_key")[Q].sum()
    prev = df[(df["Invoice_Date"] >= pd.Timestamp(ps)) & (df["Invoice_Date"] <= pd.Timestamp(pe))].groupby("account_key")[Q].sum()
    before = set(df.loc[df["Invoice_Date"] < pd.Timestamp(ps), "account_key"])
    keys = sorted(set(cur.index) | set(prev.index))
    c = cur.reindex(keys, fill_value=0.0)
    p = prev.reindex(keys, fill_value=0.0)
    cat = []
    for k in keys:
        if p[k] <= 0 < c[k]:
            cat.append("Reactivated" if k in before else "New")
        elif c[k] <= 0 < p[k]:
            cat.append("Lost")
        elif c[k] > p[k]:
            cat.append("Growth")
        elif c[k] < p[k]:
            cat.append("Decline")
        else:
            cat.append("Flat")
    t = pd.DataFrame({"account_key": keys, "prior": p.values, "current": c.values, "change": (c - p).values,
                      "category": cat})
    steps = [("Last quarter, same days", float(p.sum()))]
    for name in ["New", "Reactivated", "Growth", "Decline", "Lost"]:
        steps.append((name, float(t.loc[t["category"] == name, "change"].sum())))
    steps.append(("This quarter to date", float(c.sum())))
    return pd.DataFrame(steps, columns=["step", "value"]), t, (ps, pe)


def concentration(df: pd.DataFrame, as_of) -> pd.DataFrame:
    """Top 5 / 10 / 20 parent share of units, QTD vs the same span of last quarter."""
    md = fc.to_date(as_of)
    qs = fc.quarter_start(md)
    ps = fc.shift_quarter(qs, -1)
    pe = min(ps + (md - qs), fc.quarter_end(ps))
    out = []
    for lab, a, b in [("This quarter to date", qs, md), ("Last quarter, same days", ps, pe)]:
        u = df[(df["Invoice_Date"] >= pd.Timestamp(a)) & (df["Invoice_Date"] <= pd.Timestamp(b))].groupby("parent_name")[Q].sum()
        u = u[u > 0].sort_values(ascending=False)
        tot = u.sum()
        out.append({"period": lab, **{f"top{n}": (u.head(n).sum() / tot * 100 if tot else np.nan) for n in (5, 10, 20)},
                    "parents": int(len(u))})
    return pd.DataFrame(out)


def returns_rate_monthly(df: pd.DataFrame, as_of, months: int = 12) -> pd.DataFrame:
    last = pd.Timestamp(fc.month_start(fc.to_date(as_of)))
    idx = pd.date_range(last - pd.DateOffset(months=months - 1), last, freq="MS")
    m = df.assign(_m=df["Invoice_Date"].dt.to_period("M").dt.to_timestamp())
    sales = m[~m["is_return"]].groupby("_m")[Q].sum().reindex(idx, fill_value=0.0)
    rets = -m[m["is_return"]].groupby("_m")[Q].sum().reindex(idx, fill_value=0.0)
    return pd.DataFrame({"month": idx, "sales": sales.values, "returns": rets.values,
                         "rate": np.where(sales.values > 0, rets.values / np.maximum(sales.values, 1e-9) * 100, 0.0)})


def is_340b(contract: pd.Series, name: pd.Series | None = None) -> pd.Series:
    c = contract.astype("string").str.upper().fillna("")
    m = c.str.contains("340B") | c.isin([x.upper() for x in config.CONTRACTS_340B])
    if name is not None:
        m |= name.astype("string").str.upper().fillna("").str.contains("340B")
    return m


# =============================================================================
# One-call engine (cached by the page)
# =============================================================================
@dataclass
class EngineResult:
    product: str
    as_of: pd.Timestamp
    history_start: pd.Timestamp
    settings: dict
    calibration: dict
    events: pd.DataFrame
    regimes: pd.DataFrame
    courses: pd.DataFrame
    persistence: Persistence
    new_start: dict
    history_months: float


def run_engine(df: pd.DataFrame, product: str, as_of, overrides: dict | None = None, history_start=None,
               steps=None) -> EngineResult:
    """df: all pulled rows for the product (history window applied). `steps(name)` reports progress."""
    s = settings_for(product, overrides)
    step = steps or (lambda name: None)
    as_of = pd.Timestamp(as_of)
    hs = pd.Timestamp(history_start) if history_start is not None else (df["Invoice_Date"].min() if len(df) else as_of)
    step("Building cycle events")
    ev = build_events(df, s)
    step("Classifying accounts")
    reg = classify_accounts(ev, s)
    calib = calibrate(ev, reg, s)
    s_eff = effective_settings(s, calib)
    if s_eff is not s:
        ev = annotate_events(ev, s_eff)
        reg = classify_accounts(ev, s_eff)
    step("Finding treatment courses")
    courses = build_courses(ev, reg, as_of, s_eff, hs)
    step("Calculating persistence")
    pers = persistence(courses)
    ns = new_start_agreement(courses, ev, reg)
    months = (as_of - hs).days / 30.44
    return EngineResult(product, as_of, hs, s_eff, calib, ev, reg, courses, pers, ns, months)
